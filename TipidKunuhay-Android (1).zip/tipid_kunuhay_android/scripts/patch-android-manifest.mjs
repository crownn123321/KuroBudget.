// Adds the notification permission to the generated Android manifest (needed on Android 13+).
import { existsSync, readFileSync, writeFileSync } from 'node:fs';

const manifestPath = 'android/app/src/main/AndroidManifest.xml';
if (!existsSync(manifestPath)) {
  console.log('AndroidManifest.xml not found yet, skipping patch.');
  process.exit(0);
}

let xml = readFileSync(manifestPath, 'utf8');
const permissions = ['android.permission.POST_NOTIFICATIONS'];
let changed = false;

for (const perm of permissions) {
  if (!xml.includes(perm)) {
    xml = xml.replace('</manifest>', `    <uses-permission android:name="${perm}" />\n</manifest>`);
    changed = true;
  }
}

if (changed) {
  writeFileSync(manifestPath, xml);
  console.log('Patched AndroidManifest.xml with notification permission.');
} else {
  console.log('AndroidManifest.xml already has the required permissions.');
}
