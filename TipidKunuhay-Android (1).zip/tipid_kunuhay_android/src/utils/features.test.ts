import test from 'node:test';
import assert from 'node:assert/strict';
import type { Debt, Expense, RecurringSchedule, AllowanceConfig } from '../types/budget';
import { getWeeklySummary, getDailySeries, getBiggestLeaks, getDailyMeter } from './insights';
import { parseTransactions } from './importParser';
import { buildReminderItems } from './reminders';

const exp = (id: string, amount: number, category: Expense['category'], d: Date): Expense => ({
  id, title: id, amount, category, date: d.toISOString(),
});

const now = new Date(2026, 10, 13, 15, 0); // Fri Nov 13 2026
const day = (offset: number) => new Date(2026, 10, 13 + offset, 12, 0);

test('weekly summary compares last 7 days with the 7 before', () => {
  const list = [
    exp('a', 100, 'Food & Dining', day(0)),
    exp('b', 50, 'Food & Dining', day(-6)),
    exp('c', 70, 'Food & Dining', day(-7)), // last week
    exp('d', 30, 'Transportation', day(-10)), // last week
    exp('e', 999, 'Shopping', day(-20)), // out of range
  ];
  const w = getWeeklySummary(list, now);
  assert.equal(w.thisWeekTotal, 150);
  assert.equal(w.lastWeekTotal, 100);
  assert.equal(w.delta, 50);
  assert.equal(w.rows[0].category, 'Food & Dining');
  assert.equal(w.rows[0].delta, 80);
});

test('daily series has one point per day, oldest first', () => {
  const s = getDailySeries([exp('a', 40, 'Other', day(0)), exp('b', 10, 'Other', day(-1))], 3, now);
  assert.equal(s.length, 3);
  assert.deepEqual(s.map((p) => p.total), [0, 10, 40]);
});

test('biggest leaks finds top category and small-purchase habit', () => {
  const list = [
    exp('a', 500, 'Shopping', day(-1)),
    exp('b', 20, 'Food & Dining', day(-1)),
    exp('c', 30, 'Food & Dining', day(-2)),
    exp('d', 25, 'Food & Dining', day(-3)),
  ];
  const l = getBiggestLeaks(list, now);
  assert.equal(l.topCategories[0].category, 'Shopping');
  assert.equal(l.smallHabit?.category, 'Food & Dining');
  assert.equal(l.smallHabit?.count, 3);
  assert.ok(l.priciestWeekday);
});

test('daily meter splits remaining money across days left', () => {
  // 1,000 left, 100 reserved for schedules, 10 days left, nothing spent today
  const m = getDailyMeter(1000, 100, 10, [], now);
  assert.equal(Math.round(m.budgetToday), 90);
  assert.equal(m.status, 'good');
  const over = getDailyMeter(500, 0, 10, [exp('x', 200, 'Other', day(0))], now);
  assert.equal(over.status, 'over');
});

test('import parser handles free text, CSV, skips money in, flags duplicates', () => {
  const text = [
    'Nov 12, 2026 Jollibee Ayala -₱245.00',
    '2026-11-11 Express Send to Juan PHP 500.00',
    'Nov 10, 2026 Received from Maria ₱1,000.00',
    'Ref No. 1234567890123 Globe Load 100.00',
  ].join('\n');
  const r = parseTransactions(text, [], now);
  assert.equal(r.length, 3);
  assert.equal(r[0].amount, 245);
  assert.equal(r[0].category, 'Food & Dining');
  assert.equal(r[1].amount, 500);
  assert.equal(r[2].amount, 100);
  assert.equal(r[2].category, 'Bills & Utilities');

  const csv = 'Date,Description,Amount\n2026-11-09,Grab ride,"1,250.50"\n2026-11-08,Netflix,549';
  const c = parseTransactions(csv, [], now);
  assert.equal(c.length, 2);
  assert.equal(c[0].amount, 1250.5);
  assert.equal(c[0].category, 'Transportation');
  assert.equal(c[1].category, 'Entertainment');

  const dup = parseTransactions('2026-11-09 Grab ride 1250.50', [
    { id: '1', title: 'Grab ride', amount: 1250.5, category: 'Transportation', date: new Date(2026, 10, 9, 8).toISOString() },
  ], now);
  assert.equal(dup[0].duplicate, true);
});

test('reminders group schedules and utang by day and skip past times', () => {
  const config: AllowanceConfig = {
    totalAllowance: 5000, periodType: 'monthly', startDate: '2026-11-01', endDate: '2026-11-30',
    currencySymbol: '₱', remindersEnabled: true, reminderTime: '08:00',
  };
  const sched: RecurringSchedule = {
    id: 's', title: 'Fare', amount: 120, category: 'Transportation', frequency: 'weekly',
    daysOfWeek: [1, 6], autoDeduct: false, isActive: true, createdAt: '2026-11-01',
  };
  const debt: Debt = {
    id: 'd', person: 'Juan', amount: 300, direction: 'lent', dueDate: '2026-11-14',
    settled: false, createdAt: '2026-11-01',
  };
  const items = buildReminderItems([sched], [debt], config, now);
  // 14-day window (Nov 13..27): Sat 14 (fare + Juan), Mon 16, Sat 21, Mon 23. Today (Fri) has none.
  assert.equal(items.length, 4);
  assert.ok(items[0].body.includes('Fare') && items[0].body.includes('Juan owes you'));
  assert.equal(items[0].date.getHours(), 8);
});

import { evaluateExpression } from './calculator';

test('calculator evaluates safely', () => {
  assert.equal(evaluateExpression('2+3×4'), 14);
  assert.equal(evaluateExpression('(2+3)×4'), 20);
  assert.equal(evaluateExpression('100÷4−5'), 20);
  assert.equal(evaluateExpression('0.1+0.2'), 0.3);
  assert.equal(evaluateExpression('200+10%'), 200.1);
  assert.equal(evaluateExpression('-5+8'), 3);
  assert.equal(evaluateExpression('5÷0'), null);
  assert.equal(evaluateExpression('2+'), null);
  assert.equal(evaluateExpression('1.2.3'), null);
  assert.equal(evaluateExpression('alert(1)'), null);
  assert.equal(evaluateExpression(''), null);
});
