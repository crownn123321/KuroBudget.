/**
 * Tiny safe calculator (no eval). Supports + − × ÷, decimals, parentheses,
 * unary minus and postfix % (e.g. "200+10%" = 200.1, "50%" = 0.5).
 */
export function evaluateExpression(input: string): number | null {
  const src = input.replace(/×/g, '*').replace(/÷/g, '/').replace(/−/g, '-').replace(/\s+/g, '');
  if (!src) return null;
  let pos = 0;

  const peek = () => src[pos];

  function parseNumber(): number {
    const start = pos;
    while (pos < src.length && /[0-9.]/.test(src[pos])) pos++;
    const text = src.slice(start, pos);
    if (!text || text === '.' || (text.match(/\./g) || []).length > 1) throw new Error('number');
    return parseFloat(text);
  }

  function parsePrimary(): number {
    let value: number;
    if (peek() === '(') {
      pos++;
      value = parseExpr();
      if (peek() !== ')') throw new Error('paren');
      pos++;
    } else if (peek() === '-') {
      pos++;
      value = -parsePrimary();
    } else if (peek() === '+') {
      pos++;
      value = parsePrimary();
    } else {
      value = parseNumber();
    }
    while (peek() === '%') {
      pos++;
      value = value / 100;
    }
    return value;
  }

  function parseTerm(): number {
    let value = parsePrimary();
    while (peek() === '*' || peek() === '/') {
      const op = src[pos++];
      const rhs = parsePrimary();
      if (op === '/' && rhs === 0) throw new Error('div0');
      value = op === '*' ? value * rhs : value / rhs;
    }
    return value;
  }

  function parseExpr(): number {
    let value = parseTerm();
    while (peek() === '+' || peek() === '-') {
      const op = src[pos++];
      const rhs = parseTerm();
      value = op === '+' ? value + rhs : value - rhs;
    }
    return value;
  }

  try {
    const result = parseExpr();
    if (pos !== src.length || !Number.isFinite(result)) return null;
    return Math.round(result * 1e8) / 1e8; // trim floating point noise
  } catch {
    return null;
  }
}

/** Formats a calculator result for display, e.g. 1234.5 -> "1,234.5" */
export function formatCalcResult(value: number): string {
  return value.toLocaleString('en-US', { maximumFractionDigits: 8 });
}
