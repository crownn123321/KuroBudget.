import { AllowanceConfig, ArchivedBudgetReport, Expense, ExpenseCategory } from '../types/budget';
import { CATEGORIES, DAY_NAMES, toISODateString } from './budgetCalculations';

const startOfDay = (d: Date) => new Date(d.getFullYear(), d.getMonth(), d.getDate());
const addDays = (d: Date, n: number) => new Date(d.getFullYear(), d.getMonth(), d.getDate() + n);

export interface WeeklyRow {
  category: ExpenseCategory;
  thisWeek: number;
  lastWeek: number;
  delta: number; // thisWeek - lastWeek
}

export interface WeeklySummary {
  thisWeekTotal: number;
  lastWeekTotal: number;
  delta: number;
  rows: WeeklyRow[]; // only categories with spending in either week, biggest first
}

/** "This week" = the last 7 days including today. "Last week" = the 7 days before that. */
export function getWeeklySummary(expenses: Expense[], now: Date = new Date()): WeeklySummary {
  const today = startOfDay(now);
  const thisStart = addDays(today, -6).getTime();
  const lastStart = addDays(today, -13).getTime();
  const end = addDays(today, 1).getTime();

  const thisMap = new Map<ExpenseCategory, number>();
  const lastMap = new Map<ExpenseCategory, number>();

  for (const e of expenses) {
    const t = startOfDay(new Date(e.date)).getTime();
    if (t >= thisStart && t < end) thisMap.set(e.category, (thisMap.get(e.category) || 0) + e.amount);
    else if (t >= lastStart && t < thisStart) lastMap.set(e.category, (lastMap.get(e.category) || 0) + e.amount);
  }

  const rows: WeeklyRow[] = CATEGORIES.map((category) => {
    const thisWeek = thisMap.get(category) || 0;
    const lastWeek = lastMap.get(category) || 0;
    return { category, thisWeek, lastWeek, delta: thisWeek - lastWeek };
  })
    .filter((r) => r.thisWeek > 0 || r.lastWeek > 0)
    .sort((a, b) => b.thisWeek - a.thisWeek || b.lastWeek - a.lastWeek);

  const thisWeekTotal = rows.reduce((s, r) => s + r.thisWeek, 0);
  const lastWeekTotal = rows.reduce((s, r) => s + r.lastWeek, 0);
  return { thisWeekTotal, lastWeekTotal, delta: thisWeekTotal - lastWeekTotal, rows };
}

export interface DailyPoint {
  date: string; // YYYY-MM-DD
  label: string; // e.g. "Mon"
  total: number;
}

/** Spending per day for the last `days` days (oldest first). */
export function getDailySeries(expenses: Expense[], days = 14, now: Date = new Date()): DailyPoint[] {
  const today = startOfDay(now);
  const points: DailyPoint[] = [];
  const index = new Map<string, DailyPoint>();
  for (let i = days - 1; i >= 0; i--) {
    const d = addDays(today, -i);
    const p: DailyPoint = { date: toISODateString(d), label: DAY_NAMES[d.getDay()].slice(0, 1), total: 0 };
    points.push(p);
    index.set(p.date, p);
  }
  for (const e of expenses) {
    const p = index.get(toISODateString(new Date(e.date)));
    if (p) p.total += e.amount;
  }
  return points;
}

export interface CyclePoint {
  label: string;
  spent: number;
  allowance: number;
  percent: number;
  isCurrent: boolean;
}

/** Past cycles (from archives) plus the current one, oldest first. */
export function getCycleTrend(
  archives: ArchivedBudgetReport[],
  config: AllowanceConfig,
  expenses: Expense[],
  max = 6
): CyclePoint[] {
  const past: CyclePoint[] = [...archives]
    .sort((a, b) => new Date(a.archivedAt).getTime() - new Date(b.archivedAt).getTime())
    .map((a) => ({
      label: a.startDate.slice(5),
      spent: a.totalSpent,
      allowance: a.totalAllowance,
      percent: a.totalAllowance > 0 ? (a.totalSpent / a.totalAllowance) * 100 : 0,
      isCurrent: false,
    }));
  const spent = expenses.reduce((s, e) => s + e.amount, 0);
  const current: CyclePoint = {
    label: 'Now',
    spent,
    allowance: config.totalAllowance,
    percent: config.totalAllowance > 0 ? (spent / config.totalAllowance) * 100 : 0,
    isCurrent: true,
  };
  return [...past, current].slice(-max);
}

export interface LeakReport {
  topCategories: Array<{ category: ExpenseCategory; total: number; share: number }>;
  priciestWeekday: { day: string; average: number } | null;
  smallHabit: { category: ExpenseCategory; count: number; total: number } | null;
}

/** Finds where the money goes: top categories, the weekday you spend most, and small purchases that add up. */
export function getBiggestLeaks(expenses: Expense[], now: Date = new Date()): LeakReport {
  const total = expenses.reduce((s, e) => s + e.amount, 0);

  const byCat = new Map<ExpenseCategory, number>();
  for (const e of expenses) byCat.set(e.category, (byCat.get(e.category) || 0) + e.amount);
  const topCategories = [...byCat.entries()]
    .map(([category, t]) => ({ category, total: t, share: total > 0 ? (t / total) * 100 : 0 }))
    .sort((a, b) => b.total - a.total)
    .slice(0, 3);

  let priciestWeekday: LeakReport['priciestWeekday'] = null;
  if (expenses.length > 0) {
    const firstDay = startOfDay(
      new Date(Math.min(...expenses.map((e) => new Date(e.date).getTime())))
    );
    const today = startOfDay(now);
    const counts = new Array(7).fill(0);
    for (let d = new Date(firstDay); d.getTime() <= today.getTime(); d = addDays(d, 1)) counts[d.getDay()]++;
    const sums = new Array(7).fill(0);
    for (const e of expenses) sums[new Date(e.date).getDay()] += e.amount;
    let best = -1;
    let bestAvg = 0;
    for (let i = 0; i < 7; i++) {
      const avg = sums[i] / Math.max(1, counts[i]);
      if (sums[i] > 0 && avg > bestAvg) {
        bestAvg = avg;
        best = i;
      }
    }
    if (best >= 0) priciestWeekday = { day: DAY_NAMES[best], average: bestAvg };
  }

  const small = new Map<ExpenseCategory, { count: number; total: number }>();
  for (const e of expenses) {
    if (e.amount < 100) {
      const cur = small.get(e.category) || { count: 0, total: 0 };
      small.set(e.category, { count: cur.count + 1, total: cur.total + e.amount });
    }
  }
  let smallHabit: LeakReport['smallHabit'] = null;
  for (const [category, v] of small.entries()) {
    if (v.count >= 3 && (!smallHabit || v.total > smallHabit.total)) smallHabit = { category, ...v };
  }

  return { topCategories, priciestWeekday, smallHabit };
}

export interface DailyMeter {
  budgetToday: number; // what you can spend today to last the cycle
  spentToday: number;
  remainingToday: number;
  daysLeft: number; // including today
  status: 'good' | 'warn' | 'over';
}

/**
 * Daily budget meter: (allowance left at the start of today − upcoming scheduled commitments)
 * divided by the days left in the cycle (today included).
 */
export function getDailyMeter(
  remainingAllowance: number,
  upcomingCommitment: number,
  daysRemaining: number,
  expenses: Expense[],
  now: Date = new Date()
): DailyMeter {
  const todayStr = toISODateString(now);
  const spentToday = expenses
    .filter((e) => toISODateString(new Date(e.date)) === todayStr)
    .reduce((s, e) => s + e.amount, 0);
  const daysLeft = Math.max(1, daysRemaining);
  const pool = Math.max(0, remainingAllowance + spentToday - upcomingCommitment);
  const budgetToday = pool / daysLeft;
  const remainingToday = budgetToday - spentToday;
  const ratio = budgetToday > 0 ? spentToday / budgetToday : spentToday > 0 ? 2 : 0;
  const status: DailyMeter['status'] = ratio > 1 ? 'over' : ratio >= 0.8 ? 'warn' : 'good';
  return { budgetToday, spentToday, remainingToday, daysLeft, status };
}
