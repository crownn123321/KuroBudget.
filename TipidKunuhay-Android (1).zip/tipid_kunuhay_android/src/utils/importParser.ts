import { Expense, ExpenseCategory } from '../types/budget';

export interface ParsedTransaction {
  key: string;
  date: string; // ISO
  title: string;
  amount: number;
  category: ExpenseCategory;
  duplicate: boolean;
}

const MONTHS: Record<string, number> = {
  jan: 0, feb: 1, mar: 2, apr: 3, may: 4, jun: 5, jul: 6, aug: 7, sep: 8, oct: 9, nov: 10, dec: 11,
};

const CATEGORY_RULES: Array<[RegExp, ExpenseCategory]> = [
  [/jollibee|mcdo|mcdonald|kfc|chowking|starbucks|coffee|cafe|foodpanda|grabfood|food|resto|milk ?tea|bakery|pizza/i, 'Food & Dining'],
  [/puregold|7-?eleven|seven eleven|sm supermarket|palengke|grocery|robinsons|walter ?mart|alfamart|ministop|savemore/i, 'Groceries'],
  [/grab|angkas|joyride|jeep|mrt|lrt|beep|uber|toll|fuel|gas|petron|shell|caltex|bus|taxi/i, 'Transportation'],
  [/load|globe|smart|tnt|dito|meralco|maynilad|water|electric|internet|pldt|converge|bill|insurance/i, 'Bills & Utilities'],
  [/netflix|spotify|steam|cinema|youtube|disney|game|movie|concert/i, 'Entertainment'],
  [/shopee|lazada|zalora|shein|tiktok shop|mall|uniqlo|store/i, 'Shopping'],
  [/mercury|watsons|drug|clinic|hospital|pharmacy|dental|medical|doctor/i, 'Health & Wellness'],
];

const INCOME_WORDS = /received|cash ?in|refund|credit(ed)?|deposit|salary|reward|cashback|incoming|from /i;

export function guessCategory(text: string): ExpenseCategory {
  for (const [re, cat] of CATEGORY_RULES) if (re.test(text)) return cat;
  return 'Other';
}

function parseAmountToken(raw: string): number {
  return parseFloat(raw.replace(/[^\d.\-]/g, ''));
}

/** Pulls a date out of text. Returns the ISO string and the matched substring. */
function findDate(text: string, now: Date): { iso: string; matched: string } | null {
  let m = text.match(/\b(\d{4})-(\d{1,2})-(\d{1,2})(?:[ T](\d{1,2}):(\d{2}))?/);
  if (m) {
    const d = new Date(+m[1], +m[2] - 1, +m[3], m[4] ? +m[4] : 12, m[5] ? +m[5] : 0);
    if (!isNaN(d.getTime())) return { iso: d.toISOString(), matched: m[0] };
  }
  m = text.match(/\b(\d{1,2})\/(\d{1,2})\/(\d{2,4})\b/);
  if (m) {
    const year = +m[3] < 100 ? 2000 + +m[3] : +m[3];
    const d = new Date(year, +m[1] - 1, +m[2], 12, 0);
    if (!isNaN(d.getTime()) && +m[1] <= 12) return { iso: d.toISOString(), matched: m[0] };
  }
  m = text.match(/\b(jan|feb|mar|apr|may|jun|jul|aug|sep|oct|nov|dec)[a-z]*\.?\s+(\d{1,2})(?:,?\s+(\d{4}))?/i);
  if (m) {
    const d = new Date(m[3] ? +m[3] : now.getFullYear(), MONTHS[m[1].toLowerCase()], +m[2], 12, 0);
    if (!isNaN(d.getTime())) return { iso: d.toISOString(), matched: m[0] };
  }
  m = text.match(/\b(\d{1,2})\s+(jan|feb|mar|apr|may|jun|jul|aug|sep|oct|nov|dec)[a-z]*\.?(?:,?\s+(\d{4}))?/i);
  if (m) {
    const d = new Date(m[3] ? +m[3] : now.getFullYear(), MONTHS[m[2].toLowerCase()], +m[1], 12, 0);
    if (!isNaN(d.getTime())) return { iso: d.toISOString(), matched: m[0] };
  }
  return null;
}

/** Picks the most likely money amount in a line. Returns signed value and matched substring. */
function findAmount(text: string): { value: number; matched: string } | null {
  const re = /(-)?\s*(₱|PHP|Php|php)?\s*(\d{1,3}(?:,\d{3})+(?:\.\d{1,2})?|\d+(?:\.\d{1,2})?)/g;
  const found: Array<{ value: number; matched: string; explicit: boolean; decimals: boolean }> = [];
  let m: RegExpExecArray | null;
  while ((m = re.exec(text)) !== null) {
    const digits = m[3].replace(/[,.]/g, '');
    if (digits.length >= 10) continue; // reference numbers, phone numbers
    const value = parseAmountToken(m[3]) * (m[1] ? -1 : 1);
    if (isNaN(value) || value === 0) continue;
    found.push({
      value,
      matched: m[0],
      explicit: !!m[2] || !!m[1],
      decimals: /\.\d{2}$/.test(m[3]),
    });
  }
  if (found.length === 0) return null;
  const pick =
    found.find((f) => f.explicit) ||
    [...found].reverse().find((f) => f.decimals) ||
    found[found.length - 1];
  return { value: pick.value, matched: pick.matched };
}

function splitCsv(line: string): string[] {
  const cells: string[] = [];
  let cur = '';
  let inQuotes = false;
  for (let i = 0; i < line.length; i++) {
    const c = line[i];
    if (c === '"') {
      if (inQuotes && line[i + 1] === '"') { cur += '"'; i++; } else inQuotes = !inQuotes;
    } else if (c === ',' && !inQuotes) {
      cells.push(cur.trim());
      cur = '';
    } else cur += c;
  }
  cells.push(cur.trim());
  return cells;
}

function cleanTitle(text: string, ...remove: string[]): string {
  let t = text;
  for (const r of remove) if (r) t = t.replace(r, ' ');
  t = t
    .replace(/\b(ref(erence)?|trace|txn|transaction)\s*(no\.?|number|#)?\s*[:#]?\s*[\w-]{6,}/gi, ' ')
    .replace(/\b\d{9,}\b/g, ' ')
    .replace(/[|;]+/g, ' ')
    .replace(/\s{2,}/g, ' ')
    .replace(/^[\s,\-–:]+|[\s,\-–:]+$/g, '');
  return t.slice(0, 60) || 'Imported expense';
}

const sameDay = (a: string, b: string) => new Date(a).toDateString() === new Date(b).toDateString();

/**
 * Best-effort parser for pasted GCash / Maya / bank transaction text or CSV.
 * Skips lines that look like money coming in. Always review the preview before importing.
 */
export function parseTransactions(
  text: string,
  existing: Expense[] = [],
  now: Date = new Date()
): ParsedTransaction[] {
  const lines = text.split(/\r?\n/).map((l) => l.trim()).filter(Boolean);
  const out: ParsedTransaction[] = [];

  // CSV with a header row?
  let header: string[] | null = null;
  if (lines.length > 1 && lines[0].includes(',')) {
    const h = splitCsv(lines[0]).map((c) => c.toLowerCase());
    if (h.some((c) => /date/.test(c)) && h.some((c) => /amount|debit|withdraw|payment/.test(c))) header = h;
  }

  lines.forEach((line, idx) => {
    if (header && idx === 0) return;

    let title = '';
    let value: number | null = null;
    let dateIso: string | null = null;
    let rawForCategory = line;

    if (header) {
      const cells = splitCsv(line);
      const get = (re: RegExp) => {
        const i = header!.findIndex((c) => re.test(c));
        return i >= 0 ? cells[i] || '' : '';
      };
      const dateCell = get(/date/);
      const descCell = get(/desc|detail|title|merchant|particular|name|remark/);
      const debitCell = get(/debit|withdraw/);
      const amountCell = debitCell || get(/amount|payment/);
      const typeCell = get(/type|direction/);
      const found = findDate(dateCell, now);
      dateIso = found ? found.iso : null;
      const amt = findAmount(amountCell);
      value = amt ? amt.value : null;
      title = cleanTitle(descCell || typeCell || line);
      rawForCategory = `${descCell} ${typeCell}`;
      if (INCOME_WORDS.test(typeCell) && !debitCell) value = null;
    } else {
      const dateFound = findDate(line, now);
      const withoutDate = dateFound ? line.replace(dateFound.matched, ' ') : line;
      const amt = findAmount(withoutDate);
      if (amt) {
        value = amt.value;
        title = cleanTitle(withoutDate, amt.matched);
      }
      dateIso = dateFound ? dateFound.iso : null;
      if (value !== null && value > 0 && INCOME_WORDS.test(line)) value = null;
    }

    if (value === null || value === 0) return;
    const amount = Math.abs(value);
    const iso = dateIso || new Date(now.getFullYear(), now.getMonth(), now.getDate(), 12, 0).toISOString();
    const duplicate = existing.some(
      (e) => Math.abs(e.amount - amount) < 0.005 && sameDay(e.date, iso) &&
        e.title.toLowerCase().slice(0, 6) === title.toLowerCase().slice(0, 6)
    );

    out.push({
      key: `imp-${idx}-${amount}`,
      date: iso,
      title,
      amount,
      category: guessCategory(`${title} ${rawForCategory}`),
      duplicate,
    });
  });

  return out;
}
