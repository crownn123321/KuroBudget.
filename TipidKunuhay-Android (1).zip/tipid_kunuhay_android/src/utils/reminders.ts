import { AllowanceConfig, Debt, RecurringSchedule } from '../types/budget';
import { formatCurrency, getUpcomingOccurrences, toISODateString } from './budgetCalculations';

export interface ReminderItem {
  date: Date; // when to notify
  title: string;
  body: string;
}

export function parseReminderTime(time?: string): { hour: number; minute: number } {
  const m = (time || '08:00').match(/^(\d{1,2}):(\d{2})$/);
  const hour = m ? Math.min(23, Math.max(0, +m[1])) : 8;
  const minute = m ? Math.min(59, Math.max(0, +m[2])) : 0;
  return { hour, minute };
}

/** One notification per day, listing scheduled expenses and utang due that day (next 14 days). */
export function buildReminderItems(
  schedules: RecurringSchedule[],
  debts: Debt[],
  config: AllowanceConfig,
  now: Date = new Date()
): ReminderItem[] {
  const { hour, minute } = parseReminderTime(config.reminderTime);
  const byDay = new Map<string, string[]>();
  const push = (day: string, text: string) => byDay.set(day, [...(byDay.get(day) || []), text]);

  for (const occ of getUpcomingOccurrences(schedules, now, 14)) {
    push(occ.dateString, `${occ.title} (${formatCurrency(occ.amount, config.currencySymbol)})`);
  }
  for (const d of debts) {
    if (d.settled || !d.dueDate) continue;
    const label =
      d.direction === 'lent'
        ? `${d.person} owes you ${formatCurrency(d.amount, config.currencySymbol)}`
        : `Pay ${d.person} ${formatCurrency(d.amount, config.currencySymbol)}`;
    push(d.dueDate, label);
  }

  const items: ReminderItem[] = [];
  for (const [day, lines] of [...byDay.entries()].sort()) {
    const [y, mo, da] = day.split('-').map(Number);
    const when = new Date(y, mo - 1, da, hour, minute, 0);
    if (when.getTime() <= now.getTime()) continue; // already passed
    items.push({
      date: when,
      title: day === toISODateString(now) ? 'Due today' : 'Coming up',
      body: lines.join(', '),
    });
  }
  return items;
}

const isNative = (): boolean => {
  const cap = (globalThis as { Capacitor?: { isNativePlatform?: () => boolean } }).Capacitor;
  return !!cap?.isNativePlatform?.();
};

/**
 * Replaces all pending reminders with the given ones. Only runs inside the Android app.
 * Returns false if notifications are not allowed.
 */
export async function syncReminders(enabled: boolean, items: ReminderItem[]): Promise<boolean> {
  if (!isNative()) return false;
  try {
    const { LocalNotifications } = await import('@capacitor/local-notifications');

    const pending = await LocalNotifications.getPending();
    if (pending.notifications.length > 0) {
      await LocalNotifications.cancel({ notifications: pending.notifications.map((n) => ({ id: n.id })) });
    }
    if (!enabled || items.length === 0) return true;

    let perm = await LocalNotifications.checkPermissions();
    if (perm.display !== 'granted') perm = await LocalNotifications.requestPermissions();
    if (perm.display !== 'granted') return false;

    await LocalNotifications.schedule({
      notifications: items.map((item, i) => ({
        id: 1000 + i,
        title: item.title,
        body: item.body,
        schedule: { at: item.date, allowWhileIdle: true },
      })),
    });
    return true;
  } catch (error) {
    console.error('Unable to sync reminders:', error);
    return false;
  }
}
