import React, { useState } from 'react';
import { Pencil, Plus, Sparkles, X } from 'lucide-react';
import { ExpenseCategory, QuickAddItem } from '../types/budget';
import { CATEGORIES, formatCurrency } from '../utils/budgetCalculations';

interface QuickAddChipsProps {
  items: QuickAddItem[];
  currencySymbol: string;
  onDeduct: (amount: number, title: string, category: ExpenseCategory) => void;
  onChange: (items: QuickAddItem[]) => void;
}

export const QuickAddChips: React.FC<QuickAddChipsProps> = ({ items, currencySymbol, onDeduct, onChange }) => {
  const [editing, setEditing] = useState(false);
  const [title, setTitle] = useState('');
  const [amount, setAmount] = useState('');
  const [category, setCategory] = useState<ExpenseCategory>('Food & Dining');

  const handleAdd = (e: React.FormEvent) => {
    e.preventDefault();
    const value = parseFloat(amount);
    if (!title.trim() || isNaN(value) || value <= 0) return;
    onChange([...items, { id: `qa-${Date.now()}`, title: title.trim(), amount: value, category }]);
    setTitle('');
    setAmount('');
  };

  return (
    <div className="mt-3.5">
      <div className="flex flex-wrap items-center gap-2">
        <span className="text-[11px] text-zinc-500 flex items-center gap-1 mr-1">
          <Sparkles className="w-3 h-3 text-zinc-500" />
          Quick-add:
        </span>

        {items.map((item) =>
          editing ? (
            <span
              key={item.id}
              className="inline-flex items-center gap-1 pl-2.5 pr-1 py-1 rounded-lg text-xs font-medium bg-zinc-800/80 text-zinc-300 border border-zinc-700/60"
            >
              {item.title} {formatCurrency(item.amount, currencySymbol)}
              <button
                type="button"
                aria-label={`Remove quick-add ${item.title}`}
                onClick={() => onChange(items.filter((i) => i.id !== item.id))}
                className="p-0.5 rounded hover:bg-zinc-700 text-zinc-400 hover:text-rose-400"
              >
                <X className="w-3 h-3" />
              </button>
            </span>
          ) : (
            <button
              key={item.id}
              type="button"
              onClick={() => onDeduct(item.amount, item.title, item.category)}
              className="px-2.5 py-1 rounded-lg text-xs font-medium bg-zinc-800/80 hover:bg-zinc-700 text-zinc-300 border border-zinc-700/60 hover:border-zinc-500 transition-colors active:scale-95"
            >
              -{formatCurrency(item.amount, currencySymbol).replace('.00', '')} {item.title}
            </button>
          )
        )}

        <button
          type="button"
          onClick={() => setEditing((v) => !v)}
          aria-label={editing ? 'Done editing quick-add buttons' : 'Edit quick-add buttons'}
          className="inline-flex items-center gap-1 px-2 py-1 rounded-lg text-[11px] font-medium text-zinc-400 hover:text-zinc-200 border border-dashed border-zinc-700 hover:border-zinc-500 transition-colors"
        >
          {editing ? 'Done' : (<><Pencil className="w-3 h-3" /> Edit</>)}
        </button>
      </div>

      {editing && (
        <form onSubmit={handleAdd} className="mt-2.5 flex flex-wrap items-center gap-2">
          <input
            type="text"
            placeholder="Name (e.g. Tricycle)"
            value={title}
            onChange={(e) => setTitle(e.target.value)}
            className="flex-1 min-w-[130px] bg-zinc-950 border border-zinc-700/80 rounded-lg px-3 py-1.5 text-xs text-zinc-100 placeholder-zinc-500 focus:outline-none focus:ring-2 focus:ring-emerald-500/40"
          />
          <input
            type="number"
            step="0.01"
            min="0.01"
            placeholder="Amount"
            value={amount}
            onChange={(e) => setAmount(e.target.value)}
            className="w-24 bg-zinc-950 border border-zinc-700/80 rounded-lg px-3 py-1.5 text-xs text-zinc-100 font-mono placeholder-zinc-500 focus:outline-none focus:ring-2 focus:ring-emerald-500/40"
          />
          <select
            value={category}
            onChange={(e) => setCategory(e.target.value as ExpenseCategory)}
            className="bg-zinc-950 border border-zinc-700/80 rounded-lg px-2 py-1.5 text-xs text-zinc-200 focus:outline-none focus:ring-2 focus:ring-emerald-500/40"
          >
            {CATEGORIES.map((c) => (
              <option key={c} value={c} className="bg-zinc-900">
                {c}
              </option>
            ))}
          </select>
          <button
            type="submit"
            className="inline-flex items-center gap-1 px-3 py-1.5 rounded-lg text-xs font-semibold text-zinc-950 bg-emerald-400 hover:bg-emerald-300"
          >
            <Plus className="w-3 h-3" /> Add
          </button>
        </form>
      )}
    </div>
  );
};
