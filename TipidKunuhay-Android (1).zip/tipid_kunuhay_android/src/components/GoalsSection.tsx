import React, { useState } from 'react';
import { PiggyBank, Plus, Trash2, PartyPopper } from 'lucide-react';
import { AllowanceConfig, SavingsGoal } from '../types/budget';
import { formatCurrency } from '../utils/budgetCalculations';
import { CollapsibleCard } from './CollapsibleCard';

interface GoalsSectionProps {
  config: AllowanceConfig;
  goals: SavingsGoal[];
  remainingAllowance: number;
  onAddGoal: (name: string, target: number) => void;
  onContribute: (goalId: string, amount: number, deductFromAllowance: boolean) => void;
  onDeleteGoal: (goalId: string) => void;
}

const GoalRow: React.FC<{
  goal: SavingsGoal;
  sym: string;
  onContribute: GoalsSectionProps['onContribute'];
  onDelete: () => void;
}> = ({ goal, sym, onContribute, onDelete }) => {
  const [amount, setAmount] = useState('');
  const [deduct, setDeduct] = useState(true);
  const [confirmDelete, setConfirmDelete] = useState(false);

  const pct = goal.target > 0 ? Math.min(100, (goal.saved / goal.target) * 100) : 0;
  const reached = goal.saved >= goal.target;

  const submit = (e: React.FormEvent) => {
    e.preventDefault();
    const value = parseFloat(amount);
    if (isNaN(value) || value <= 0) return;
    onContribute(goal.id, value, deduct);
    setAmount('');
  };

  return (
    <div className="p-3.5 rounded-2xl bg-zinc-950/60 border border-zinc-800/80">
      <div className="flex items-start justify-between gap-2">
        <div className="min-w-0">
          <div className="font-semibold text-sm text-zinc-100 flex items-center gap-1.5">
            {reached && <PartyPopper className="w-4 h-4 text-amber-400" />}
            <span className="truncate">{goal.name}</span>
          </div>
          <div className="text-xs text-zinc-400 font-mono">
            {formatCurrency(goal.saved, sym)} of {formatCurrency(goal.target, sym)} ({pct.toFixed(0)}%)
          </div>
        </div>
        {confirmDelete ? (
          <div className="flex items-center gap-1 shrink-0">
            <button type="button" onClick={onDelete} className="px-2 py-1 rounded-lg text-xs font-semibold bg-rose-500 text-white">
              Delete
            </button>
            <button type="button" onClick={() => setConfirmDelete(false)} className="px-2 py-1 rounded-lg text-xs bg-zinc-800 text-zinc-300">
              Keep
            </button>
          </div>
        ) : (
          <button
            type="button"
            onClick={() => setConfirmDelete(true)}
            aria-label={`Delete goal ${goal.name}`}
            className="p-1.5 rounded-lg text-zinc-500 hover:text-rose-400 hover:bg-zinc-800 transition-colors shrink-0"
          >
            <Trash2 className="w-4 h-4" />
          </button>
        )}
      </div>

      <div className="mt-2 h-2 rounded-full bg-zinc-800 overflow-hidden" role="progressbar" aria-valuenow={Math.round(pct)} aria-valuemin={0} aria-valuemax={100} aria-label={`${goal.name} progress`}>
        <div className={`h-full rounded-full ${reached ? 'bg-amber-400' : 'bg-emerald-400'}`} style={{ width: `${pct}%` }} />
      </div>
      {reached && <p className="mt-1.5 text-xs text-amber-300">Goal reached! Great job saving.</p>}

      <form onSubmit={submit} className="mt-2.5 flex flex-wrap items-center gap-2">
        <div className="relative w-28">
          <span className="absolute left-2.5 top-1/2 -translate-y-1/2 text-zinc-500 font-mono text-xs">{sym}</span>
          <input
            type="number"
            step="0.01"
            min="0.01"
            placeholder="Save"
            aria-label={`Amount to save toward ${goal.name}`}
            value={amount}
            onChange={(e) => setAmount(e.target.value)}
            className="w-full bg-zinc-950 border border-zinc-700/80 rounded-lg pl-6 pr-2 py-1.5 text-xs text-zinc-100 font-mono placeholder-zinc-500 focus:outline-none focus:ring-2 focus:ring-emerald-500/40"
          />
        </div>
        <button type="submit" className="px-3 py-1.5 rounded-lg text-xs font-semibold text-zinc-950 bg-emerald-400 hover:bg-emerald-300">
          Add savings
        </button>
        <label className="flex items-center gap-1.5 text-[11px] text-zinc-400 cursor-pointer">
          <input type="checkbox" checked={deduct} onChange={(e) => setDeduct(e.target.checked)} className="accent-emerald-400" />
          Deduct from allowance
        </label>
      </form>
    </div>
  );
};

export const GoalsSection: React.FC<GoalsSectionProps> = ({
  config,
  goals,
  remainingAllowance,
  onAddGoal,
  onContribute,
  onDeleteGoal,
}) => {
  const [name, setName] = useState('');
  const [target, setTarget] = useState('');
  const sym = config.currencySymbol;
  const totalSaved = goals.reduce((s, g) => s + g.saved, 0);

  const submit = (e: React.FormEvent) => {
    e.preventDefault();
    const value = parseFloat(target);
    if (!name.trim() || isNaN(value) || value <= 0) return;
    onAddGoal(name.trim(), value);
    setName('');
    setTarget('');
  };

  return (
    <CollapsibleCard
      id="goals"
      icon={<PiggyBank className="w-5 h-5" />}
      iconClassName="bg-amber-500/10 border-amber-500/20 text-amber-400"
      title="Savings Goals"
      badge={
        <span className="text-xs font-semibold px-2 py-0.5 rounded-full bg-amber-500/10 text-amber-300 border border-amber-500/20">
          {goals.length}
        </span>
      }
      subtitle={`Saved so far: ${formatCurrency(totalSaved, sym)}`}
    >
      <form onSubmit={submit} className="flex flex-wrap items-center gap-2 mb-4">
        <input
          type="text"
          placeholder="Goal (e.g. New phone)"
          aria-label="Goal name"
          value={name}
          onChange={(e) => setName(e.target.value)}
          className="flex-1 min-w-[150px] bg-zinc-950 border border-zinc-700/80 rounded-xl px-3.5 py-2 text-xs text-zinc-100 placeholder-zinc-500 focus:outline-none focus:ring-2 focus:ring-amber-500/40"
        />
        <div className="relative w-32">
          <span className="absolute left-3 top-1/2 -translate-y-1/2 text-zinc-500 font-mono text-xs">{sym}</span>
          <input
            type="number"
            step="0.01"
            min="0.01"
            placeholder="Target"
            aria-label="Goal target amount"
            value={target}
            onChange={(e) => setTarget(e.target.value)}
            className="w-full bg-zinc-950 border border-zinc-700/80 rounded-xl pl-7 pr-2 py-2 text-xs text-zinc-100 font-mono placeholder-zinc-500 focus:outline-none focus:ring-2 focus:ring-amber-500/40"
          />
        </div>
        <button type="submit" className="inline-flex items-center gap-1 px-3.5 py-2 rounded-xl text-xs font-semibold text-zinc-950 bg-amber-400 hover:bg-amber-300">
          <Plus className="w-3.5 h-3.5" /> Add goal
        </button>
      </form>

      {goals.length === 0 ? (
        <div className="text-center py-8 px-4 rounded-2xl border border-dashed border-zinc-800 bg-zinc-950/40">
          <PiggyBank className="w-8 h-8 text-zinc-600 mx-auto mb-2" />
          <p className="text-sm font-semibold text-zinc-300">No savings goals yet</p>
          <p className="text-xs text-zinc-500 mt-1">Set a target like &quot;New phone ₱15,000&quot; and add savings as you go.</p>
        </div>
      ) : (
        <div className="space-y-2.5">
          {goals.map((g) => (
            <GoalRow key={g.id} goal={g} sym={sym} onContribute={onContribute} onDelete={() => onDeleteGoal(g.id)} />
          ))}
          <p className="text-[11px] text-zinc-500">
            Allowance left right now: {formatCurrency(Math.max(0, remainingAllowance), sym)}. Money you deduct for savings
            shows up in Expenses as &quot;Savings&quot;.
          </p>
        </div>
      )}
    </CollapsibleCard>
  );
};
