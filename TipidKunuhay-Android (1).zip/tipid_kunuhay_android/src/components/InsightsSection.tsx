import React, { useMemo } from 'react';
import { BarChart3, TrendingDown, TrendingUp, Minus as MinusIcon, Lightbulb } from 'lucide-react';
import { AllowanceConfig, ArchivedBudgetReport, Expense } from '../types/budget';
import { CATEGORY_COLORS, formatCurrency } from '../utils/budgetCalculations';
import {
  getBiggestLeaks,
  getCycleTrend,
  getDailySeries,
  getWeeklySummary,
} from '../utils/insights';
import { CollapsibleCard } from './CollapsibleCard';

interface InsightsSectionProps {
  config: AllowanceConfig;
  expenses: Expense[];
  archives: ArchivedBudgetReport[];
}

const Delta: React.FC<{ value: number; sym: string }> = ({ value, sym }) => {
  if (Math.abs(value) < 0.005) {
    return (
      <span className="inline-flex items-center gap-0.5 text-zinc-500 font-mono text-xs">
        <MinusIcon className="w-3 h-3" /> same
      </span>
    );
  }
  const up = value > 0;
  return (
    <span className={`inline-flex items-center gap-0.5 font-mono text-xs ${up ? 'text-rose-400' : 'text-emerald-400'}`}>
      {up ? <TrendingUp className="w-3 h-3" /> : <TrendingDown className="w-3 h-3" />}
      {up ? '+' : '-'}
      {formatCurrency(Math.abs(value), sym)}
    </span>
  );
};

export const InsightsSection: React.FC<InsightsSectionProps> = ({ config, expenses, archives }) => {
  const sym = config.currencySymbol;
  const weekly = useMemo(() => getWeeklySummary(expenses), [expenses]);
  const daily = useMemo(() => getDailySeries(expenses, 14), [expenses]);
  const cycles = useMemo(() => getCycleTrend(archives, config, expenses), [archives, config, expenses]);
  const leaks = useMemo(() => getBiggestLeaks(expenses), [expenses]);

  const maxDaily = Math.max(1, ...daily.map((d) => d.total));
  const hasData = expenses.length > 0 || archives.length > 0;

  return (
    <CollapsibleCard
      id="insights"
      icon={<BarChart3 className="w-5 h-5" />}
      iconClassName="bg-sky-500/10 border-sky-500/20 text-sky-400"
      title="Insights"
      subtitle="Weekly summary, trends and where your money leaks"
    >
      {!hasData ? (
        <p className="text-xs text-zinc-500 text-center py-6">
          Add a few expenses and your weekly summary and trends will show up here.
        </p>
      ) : (
        <div className="space-y-6">
          {/* Weekly summary */}
          <div>
            <h3 className="text-xs font-semibold uppercase tracking-wider text-zinc-300 mb-2">
              Weekly summary (last 7 days vs the 7 before)
            </h3>
            <div className="grid grid-cols-3 gap-2 mb-3">
              <div className="p-2.5 rounded-xl bg-zinc-950/60 border border-zinc-800/80">
                <div className="text-[11px] text-zinc-500">This week</div>
                <div className="text-sm font-bold font-mono text-zinc-100">{formatCurrency(weekly.thisWeekTotal, sym)}</div>
              </div>
              <div className="p-2.5 rounded-xl bg-zinc-950/60 border border-zinc-800/80">
                <div className="text-[11px] text-zinc-500">Last week</div>
                <div className="text-sm font-bold font-mono text-zinc-300">{formatCurrency(weekly.lastWeekTotal, sym)}</div>
              </div>
              <div className="p-2.5 rounded-xl bg-zinc-950/60 border border-zinc-800/80">
                <div className="text-[11px] text-zinc-500">Change</div>
                <Delta value={weekly.delta} sym={sym} />
              </div>
            </div>
            {weekly.rows.length === 0 ? (
              <p className="text-xs text-zinc-500">No spending in the last two weeks.</p>
            ) : (
              <div className="space-y-1.5">
                {weekly.rows.map((r) => (
                  <div key={r.category} className="flex items-center justify-between gap-2 text-xs">
                    <span className="flex items-center gap-2 min-w-0">
                      <span className={`w-2 h-2 rounded-full shrink-0 ${CATEGORY_COLORS[r.category]?.dot || 'bg-zinc-500'}`} />
                      <span className="text-zinc-300 truncate">{r.category}</span>
                    </span>
                    <span className="flex items-center gap-3 shrink-0">
                      <span className="font-mono text-zinc-200">{formatCurrency(r.thisWeek, sym)}</span>
                      <Delta value={r.delta} sym={sym} />
                    </span>
                  </div>
                ))}
              </div>
            )}
          </div>

          {/* Daily trend */}
          <div>
            <h3 className="text-xs font-semibold uppercase tracking-wider text-zinc-300 mb-2">Daily spending (last 14 days)</h3>
            <div className="flex items-end gap-1 h-28" role="img" aria-label="Bar chart of daily spending for the last 14 days">
              {daily.map((d) => (
                <div key={d.date} className="flex-1 flex flex-col items-center justify-end h-full min-w-0">
                  <div
                    className="w-full rounded-t bg-emerald-400/80"
                    style={{ height: `${Math.max(d.total > 0 ? 4 : 0, (d.total / maxDaily) * 100)}%` }}
                    title={`${d.date}: ${formatCurrency(d.total, sym)}`}
                  />
                  <div className="text-[10px] text-zinc-500 mt-1">{d.label}</div>
                </div>
              ))}
            </div>
            <div className="text-[11px] text-zinc-500 mt-1">Tallest bar: {formatCurrency(maxDaily === 1 && daily.every((d) => d.total === 0) ? 0 : maxDaily, sym)}</div>
          </div>

          {/* Cycle trend */}
          {cycles.length > 1 && (
            <div>
              <h3 className="text-xs font-semibold uppercase tracking-wider text-zinc-300 mb-2">
                Past cycles (% of allowance spent)
              </h3>
              <div className="space-y-1.5">
                {cycles.map((c, i) => (
                  <div key={`${c.label}-${i}`} className="flex items-center gap-2 text-xs">
                    <span className="w-12 shrink-0 text-zinc-400 font-mono">{c.label}</span>
                    <div className="flex-1 h-2.5 rounded-full bg-zinc-800 overflow-hidden">
                      <div
                        className={`h-full rounded-full ${c.percent > 100 ? 'bg-rose-400' : c.isCurrent ? 'bg-sky-400' : 'bg-emerald-400/80'}`}
                        style={{ width: `${Math.min(100, c.percent)}%` }}
                      />
                    </div>
                    <span className="w-24 shrink-0 text-right font-mono text-zinc-300">
                      {c.percent.toFixed(0)}% · {formatCurrency(c.spent, sym).replace('.00', '')}
                    </span>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Biggest leaks */}
          <div>
            <h3 className="text-xs font-semibold uppercase tracking-wider text-zinc-300 mb-2 flex items-center gap-1.5">
              <Lightbulb className="w-3.5 h-3.5 text-amber-400" /> Biggest leaks this cycle
            </h3>
            {leaks.topCategories.length === 0 ? (
              <p className="text-xs text-zinc-500">Nothing to analyze yet.</p>
            ) : (
              <ul className="space-y-1.5 text-xs text-zinc-300">
                {leaks.topCategories.map((c, i) => (
                  <li key={c.category}>
                    <strong className="text-zinc-100">#{i + 1} {c.category}</strong>: {formatCurrency(c.total, sym)} ({c.share.toFixed(0)}% of spending)
                  </li>
                ))}
                {leaks.priciestWeekday && (
                  <li>
                    You spend the most on <strong className="text-zinc-100">{leaks.priciestWeekday.day}s</strong>, about{' '}
                    {formatCurrency(leaks.priciestWeekday.average, sym)} each.
                  </li>
                )}
                {leaks.smallHabit && (
                  <li>
                    Small <strong className="text-zinc-100">{leaks.smallHabit.category}</strong> buys (under {sym}100) happened{' '}
                    {leaks.smallHabit.count} times and added up to {formatCurrency(leaks.smallHabit.total, sym)}.
                  </li>
                )}
              </ul>
            )}
          </div>
        </div>
      )}
    </CollapsibleCard>
  );
};
