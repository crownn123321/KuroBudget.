import React, { useState } from 'react';
import { X, Calculator, ArrowDownRight, Delete } from 'lucide-react';
import { evaluateExpression, formatCalcResult } from '../utils/calculator';

interface CalculatorModalProps {
  isOpen: boolean;
  onClose: () => void;
  currencySymbol: string;
  /** Called with the result when the person wants to deduct it from their allowance */
  onUseAsExpense: (amount: number) => void;
}

const KEYS: Array<{ label: string; kind: 'num' | 'op' | 'fn' | 'eq'; span?: number }> = [
  { label: 'C', kind: 'fn' }, { label: '⌫', kind: 'fn' }, { label: '%', kind: 'op' }, { label: '÷', kind: 'op' },
  { label: '7', kind: 'num' }, { label: '8', kind: 'num' }, { label: '9', kind: 'num' }, { label: '×', kind: 'op' },
  { label: '4', kind: 'num' }, { label: '5', kind: 'num' }, { label: '6', kind: 'num' }, { label: '−', kind: 'op' },
  { label: '1', kind: 'num' }, { label: '2', kind: 'num' }, { label: '3', kind: 'num' }, { label: '+', kind: 'op' },
  { label: '0', kind: 'num' }, { label: '.', kind: 'num' }, { label: '=', kind: 'eq', span: 2 },
];

export const CalculatorModal: React.FC<CalculatorModalProps> = ({
  isOpen,
  onClose,
  currencySymbol,
  onUseAsExpense,
}) => {
  const [expr, setExpr] = useState('');

  if (!isOpen) return null;

  const result = evaluateExpression(expr);
  const hasOperator = /[+−×÷%]/.test(expr.replace(/^−/, ''));

  const press = (label: string, kind: string) => {
    if (label === 'C') return setExpr('');
    if (label === '⌫') return setExpr((e) => e.slice(0, -1));
    if (label === '=') {
      if (result !== null) setExpr(String(result).replace('-', '−'));
      return;
    }
    setExpr((e) => {
      const last = e.slice(-1);
      if (kind === 'op' && label !== '%') {
        if (!e && label !== '−') return e; // can't start with × ÷ +
        if (/[+−×÷]/.test(last)) return e.slice(0, -1) + label; // replace operator
      }
      if (label === '%' && (!e || /[+−×÷%]/.test(last))) return e;
      if (label === '.') {
        const currentNumber = e.split(/[+−×÷]/).pop() || '';
        if (currentNumber.includes('.')) return e;
        if (currentNumber === '') return e + '0.';
      }
      return e + label;
    });
  };

  const display = expr || '0';
  const canUse = result !== null && result > 0;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-zinc-950/80 backdrop-blur-sm animate-fade-in">
      <div className="relative w-full max-w-xs rounded-3xl bg-zinc-900 border border-zinc-800 p-4 sm:p-5 shadow-2xl max-h-[92dvh] overflow-y-auto overscroll-contain">
        <button
          onClick={onClose}
          aria-label="Close calculator"
          className="absolute right-3 top-3 p-2 text-zinc-400 hover:text-zinc-100 hover:bg-zinc-800 rounded-xl transition-colors"
        >
          <X className="w-5 h-5" />
        </button>

        <div className="flex items-center gap-2 mb-3 text-zinc-200">
          <Calculator className="w-4 h-4 text-sky-400" />
          <h3 className="text-sm font-bold">Calculator</h3>
        </div>

        <div className="rounded-2xl bg-zinc-950 border border-zinc-800 px-4 py-3 mb-3 text-right">
          <div className="text-sm text-zinc-400 font-mono min-h-5 break-all" aria-live="polite">
            {hasOperator ? display : '\u00A0'}
          </div>
          <div className="text-3xl font-bold text-zinc-100 font-mono break-all">
            {result !== null ? formatCalcResult(result) : expr ? '…' : '0'}
          </div>
        </div>

        <div className="grid grid-cols-4 gap-2">
          {KEYS.map((k) => (
            <button
              key={k.label}
              type="button"
              onClick={() => press(k.label, k.kind)}
              aria-label={k.label === '⌫' ? 'Backspace' : k.label === 'C' ? 'Clear' : k.label}
              style={k.span ? { gridColumn: `span ${k.span}` } : undefined}
              className={`py-3 rounded-xl text-lg font-semibold transition-all active:scale-95 flex items-center justify-center ${
                k.kind === 'eq'
                  ? 'bg-sky-400 text-zinc-950 hover:bg-sky-300'
                  : k.kind === 'op'
                  ? 'bg-zinc-800 text-sky-300 hover:bg-zinc-700'
                  : k.kind === 'fn'
                  ? 'bg-zinc-800 text-amber-300 hover:bg-zinc-700'
                  : 'bg-zinc-950 text-zinc-100 border border-zinc-800 hover:bg-zinc-800'
              }`}
            >
              {k.label === '⌫' ? <Delete className="w-5 h-5" /> : k.label}
            </button>
          ))}
        </div>

        <button
          type="button"
          disabled={!canUse}
          onClick={() => {
            if (result !== null && result > 0) {
              onUseAsExpense(result);
              setExpr('');
            }
          }}
          className="mt-3 w-full inline-flex items-center justify-center gap-1.5 px-4 py-2.5 rounded-xl text-xs font-semibold text-zinc-950 bg-emerald-400 hover:bg-emerald-300 disabled:opacity-40 disabled:cursor-not-allowed transition-all"
        >
          <ArrowDownRight className="w-4 h-4" />
          <span>
            Minus {canUse ? `${currencySymbol}${formatCalcResult(result as number)}` : 'result'} from allowance
          </span>
        </button>
      </div>
    </div>
  );
};
