import React, { useState } from 'react';
import { ChevronDown } from 'lucide-react';
import { loadUiFlag, saveUiFlag } from '../utils/storage';

/** Remembers whether a dropdown section is open between app launches. */
export function useOpenState(id: string, defaultOpen = false): [boolean, () => void] {
  const [open, setOpen] = useState<boolean>(() => loadUiFlag(id, defaultOpen));
  const toggle = () =>
    setOpen((prev) => {
      saveUiFlag(id, !prev);
      return !prev;
    });
  return [open, toggle];
}

interface CollapsibleCardProps {
  id: string;
  icon: React.ReactNode;
  iconClassName?: string;
  title: string;
  badge?: React.ReactNode;
  subtitle?: React.ReactNode;
  actions?: React.ReactNode;
  defaultOpen?: boolean;
  children: React.ReactNode;
}

/** A card whose body drops down when you tap the title. */
export const CollapsibleCard: React.FC<CollapsibleCardProps> = ({
  id,
  icon,
  iconClassName = 'bg-emerald-500/10 border-emerald-500/20 text-emerald-400',
  title,
  badge,
  subtitle,
  actions,
  defaultOpen = false,
  children,
}) => {
  const [open, toggle] = useOpenState(id, defaultOpen);

  return (
    <section className="rounded-3xl bg-zinc-900/60 border border-zinc-800/80 p-5 sm:p-7 shadow-xl">
      <div className="flex items-center justify-between gap-3">
        <button
          type="button"
          onClick={toggle}
          aria-expanded={open}
          className="flex items-center gap-3 min-w-0 text-left flex-1"
        >
          <div className={`w-10 h-10 shrink-0 rounded-xl border flex items-center justify-center ${iconClassName}`}>
            {icon}
          </div>
          <div className="min-w-0">
            <h2 className="text-base sm:text-lg font-bold text-zinc-100 flex items-center gap-2 flex-wrap">
              <span>{title}</span>
              {badge}
            </h2>
            {subtitle && <p className="text-xs text-zinc-400">{subtitle}</p>}
          </div>
          <ChevronDown
            className={`w-5 h-5 text-zinc-400 shrink-0 ml-auto transition-transform ${open ? 'rotate-180' : ''}`}
          />
        </button>
        {actions && <div className="shrink-0">{actions}</div>}
      </div>
      {open && <div className="mt-5 pt-5 border-t border-zinc-800/70">{children}</div>}
    </section>
  );
};
