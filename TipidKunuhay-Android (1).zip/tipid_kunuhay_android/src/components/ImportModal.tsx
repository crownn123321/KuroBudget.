import React, { useState } from 'react';
import { X, Upload, FileText } from 'lucide-react';
import { AllowanceConfig, Expense, ExpenseCategory } from '../types/budget';
import { CATEGORIES, formatCurrency } from '../utils/budgetCalculations';
import { ParsedTransaction, parseTransactions } from '../utils/importParser';

interface ImportModalProps {
  isOpen: boolean;
  onClose: () => void;
  config: AllowanceConfig;
  existing: Expense[];
  onImport: (items: ParsedTransaction[]) => void;
}

export const ImportModal: React.FC<ImportModalProps> = ({ isOpen, onClose, config, existing, onImport }) => {
  const [text, setText] = useState('');
  const [rows, setRows] = useState<ParsedTransaction[] | null>(null);
  const [selected, setSelected] = useState<Record<string, boolean>>({});

  if (!isOpen) return null;

  const reset = () => {
    setText('');
    setRows(null);
    setSelected({});
  };

  const handlePreview = () => {
    const parsed = parseTransactions(text, existing);
    setRows(parsed);
    setSelected(Object.fromEntries(parsed.map((r) => [r.key, !r.duplicate])));
  };

  const handleFile = async (file: File | undefined) => {
    if (!file) return;
    try {
      setText(await file.text());
      setRows(null);
    } catch {
      window.alert('Could not read that file. Try pasting the text instead.');
    }
  };

  const chosen = (rows || []).filter((r) => selected[r.key]);
  const updateRow = (key: string, patch: Partial<ParsedTransaction>) =>
    setRows((prev) => (prev || []).map((r) => (r.key === key ? { ...r, ...patch } : r)));

  const handleImport = () => {
    if (chosen.length === 0) return;
    onImport(chosen);
    reset();
    onClose();
  };

  const close = () => {
    reset();
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-zinc-950/80 backdrop-blur-sm animate-fade-in">
      <div className="relative w-full max-w-lg rounded-3xl bg-zinc-900 border border-zinc-800 p-4 sm:p-6 shadow-2xl max-h-[92dvh] overflow-y-auto overscroll-contain">
        <button
          onClick={close}
          aria-label="Close dialog"
          className="absolute right-4 top-4 p-2 text-zinc-400 hover:text-zinc-100 hover:bg-zinc-800 rounded-xl transition-colors"
        >
          <X className="w-5 h-5" />
        </button>

        <div className="flex items-center gap-3 mb-4">
          <div className="w-10 h-10 rounded-xl bg-sky-500/10 border border-sky-500/20 flex items-center justify-center text-sky-400">
            <Upload className="w-5 h-5" />
          </div>
          <div>
            <h3 className="text-lg font-bold text-zinc-100">Import transactions</h3>
            <p className="text-xs text-zinc-400">GCash, Maya or bank history (paste text or load a CSV)</p>
          </div>
        </div>

        {rows === null ? (
          <div className="space-y-3">
            <textarea
              value={text}
              onChange={(e) => setText(e.target.value)}
              rows={8}
              placeholder={'Paste your transaction history here, one per line, e.g.\nNov 12, 2026 Jollibee Ayala -₱245.00\n2026-11-11 Express Send to Juan PHP 500.00\n\nOr a CSV with Date, Description, Amount columns.'}
              className="w-full bg-zinc-950 border border-zinc-700 rounded-xl px-3.5 py-3 text-xs text-zinc-100 placeholder-zinc-600 font-mono focus:outline-none focus:ring-2 focus:ring-sky-500/40"
            />
            <label className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-medium text-zinc-300 bg-zinc-950 hover:bg-zinc-800 border border-zinc-800 cursor-pointer">
              <FileText className="w-3.5 h-3.5" />
              <span>Load CSV / text file</span>
              <input type="file" accept=".csv,.txt,text/csv,text/plain" className="hidden" onChange={(e) => handleFile(e.target.files?.[0])} />
            </label>
            <p className="text-[11px] text-zinc-500">
              This is a best-effort reader. It skips money received, and you can review and fix every line before anything is added.
            </p>
            <div className="flex justify-end gap-2.5 pt-1">
              <button type="button" onClick={close} className="px-4 py-2.5 rounded-xl text-xs font-medium text-zinc-400 hover:text-zinc-200 hover:bg-zinc-800">
                Cancel
              </button>
              <button
                type="button"
                onClick={handlePreview}
                disabled={!text.trim()}
                className="px-5 py-2.5 rounded-xl text-xs font-semibold text-zinc-950 bg-sky-400 hover:bg-sky-300 disabled:opacity-40"
              >
                Preview
              </button>
            </div>
          </div>
        ) : rows.length === 0 ? (
          <div className="space-y-3">
            <p className="text-sm text-zinc-300">
              No expenses found. Check that each line has an amount, then try again.
            </p>
            <button type="button" onClick={() => setRows(null)} className="px-4 py-2 rounded-xl text-xs font-semibold text-zinc-950 bg-sky-400 hover:bg-sky-300">
              Back
            </button>
          </div>
        ) : (
          <div className="space-y-3">
            <p className="text-xs text-zinc-400">
              Found {rows.length} expense{rows.length === 1 ? '' : 's'}. Untick anything you don&apos;t want. Possible duplicates are unticked.
            </p>
            <div className="space-y-2 max-h-[46dvh] overflow-y-auto pr-1">
              {rows.map((r) => (
                <div key={r.key} className="p-2.5 rounded-xl bg-zinc-950/70 border border-zinc-800/80">
                  <div className="flex items-start gap-2.5">
                    <input
                      type="checkbox"
                      aria-label={`Import ${r.title}`}
                      checked={!!selected[r.key]}
                      onChange={(e) => setSelected((s) => ({ ...s, [r.key]: e.target.checked }))}
                      className="mt-1 accent-sky-400"
                    />
                    <div className="flex-1 min-w-0">
                      <input
                        type="text"
                        value={r.title}
                        onChange={(e) => updateRow(r.key, { title: e.target.value })}
                        aria-label="Title"
                        className="w-full bg-transparent text-sm text-zinc-100 font-semibold focus:outline-none focus:bg-zinc-900 rounded px-1 -mx-1"
                      />
                      <div className="flex items-center gap-2 mt-1 flex-wrap">
                        <span className="text-[11px] text-zinc-500">
                          {new Date(r.date).toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' })}
                        </span>
                        <select
                          value={r.category}
                          onChange={(e) => updateRow(r.key, { category: e.target.value as ExpenseCategory })}
                          aria-label="Category"
                          className="bg-zinc-900 border border-zinc-800 rounded-md px-1.5 py-0.5 text-[11px] text-zinc-300"
                        >
                          {CATEGORIES.map((c) => (
                            <option key={c} value={c}>{c}</option>
                          ))}
                        </select>
                        {r.duplicate && <span className="text-[10px] px-1.5 py-0.5 rounded bg-amber-500/10 text-amber-400 border border-amber-500/20">Possible duplicate</span>}
                      </div>
                    </div>
                    <span className="font-mono font-bold text-sm text-rose-400 shrink-0">
                      -{formatCurrency(r.amount, config.currencySymbol)}
                    </span>
                  </div>
                </div>
              ))}
            </div>
            <div className="flex items-center justify-between gap-2.5 pt-1">
              <button type="button" onClick={() => setRows(null)} className="px-3 py-2 rounded-xl text-xs font-medium text-zinc-400 hover:text-zinc-200 hover:bg-zinc-800">
                Back
              </button>
              <button
                type="button"
                onClick={handleImport}
                disabled={chosen.length === 0}
                className="px-5 py-2.5 rounded-xl text-xs font-semibold text-zinc-950 bg-emerald-400 hover:bg-emerald-300 disabled:opacity-40"
              >
                Import {chosen.length} expense{chosen.length === 1 ? '' : 's'}
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
