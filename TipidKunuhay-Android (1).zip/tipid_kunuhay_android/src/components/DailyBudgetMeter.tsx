import React from 'react';
import { Gauge } from 'lucide-react';
import { AllowanceConfig, Expense } from '../types/budget';
import {
  calculateDaysRemaining,
  calculateRemainingAllowance,
  formatCurrency,
} from '../utils/budgetCalculations';
import { getDailyMeter } from '../utils/insights';

interface DailyBudgetMeterProps {
  config: AllowanceConfig;
  expenses: Expense[];
  upcomingCommitmentTotal: number;
}

export const DailyBudgetMeter: React.FC<DailyBudgetMeterProps> = ({
  config,
  expenses,
  upcomingCommitmentTotal,
}) => {
  const remaining = calculateRemainingAllowance(config.totalAllowance, expenses);
  const daysRemaining = calculateDaysRemaining(config.endDate);
  const meter = getDailyMeter(remaining, upcomingCommitmentTotal, daysRemaining, expenses);
  const sym = config.currencySymbol;

  const pct = meter.budgetToday > 0 ? Math.min(100, (meter.spentToday / meter.budgetToday) * 100) : meter.spentToday > 0 ? 100 : 0;
  const color =
    meter.status === 'over' ? 'bg-rose-400' : meter.status === 'warn' ? 'bg-amber-400' : 'bg-emerald-400';
  const text =
    meter.status === 'over' ? 'text-rose-400' : meter.status === 'warn' ? 'text-amber-400' : 'text-emerald-400';

  return (
    <div className="rounded-3xl bg-zinc-900/60 border border-zinc-800/80 p-5 sm:p-6 shadow-xl">
      <div className="flex items-center justify-between gap-3">
        <div className="flex items-center gap-2 text-xs font-semibold uppercase tracking-wider text-zinc-300">
          <Gauge className="w-4 h-4 text-sky-400" />
          <span>Today&apos;s Budget</span>
        </div>
        <span className="text-[11px] text-zinc-500">
          {meter.daysLeft} day{meter.daysLeft === 1 ? '' : 's'} left in cycle
        </span>
      </div>

      <div className="mt-3 flex items-end justify-between gap-3">
        <div>
          <div className={`text-2xl font-bold font-mono ${text}`}>
            {meter.remainingToday >= 0
              ? formatCurrency(meter.remainingToday, sym)
              : `-${formatCurrency(Math.abs(meter.remainingToday), sym)}`}
          </div>
          <div className="text-xs text-zinc-400">
            {meter.remainingToday >= 0 ? 'left to spend today' : 'over today\u2019s budget'}
          </div>
        </div>
        <div className="text-right text-xs text-zinc-400">
          <div>
            Spent today{' '}
            <strong className="text-zinc-200 font-mono">{formatCurrency(meter.spentToday, sym)}</strong>
          </div>
          <div>
            Daily budget{' '}
            <strong className="text-zinc-200 font-mono">{formatCurrency(meter.budgetToday, sym)}</strong>
          </div>
        </div>
      </div>

      <div className="mt-3 h-2.5 rounded-full bg-zinc-800 overflow-hidden" role="progressbar" aria-valuenow={Math.round(pct)} aria-valuemin={0} aria-valuemax={100} aria-label="Share of today's budget spent">
        <div className={`h-full rounded-full transition-all ${color}`} style={{ width: `${pct}%` }} />
      </div>

      {meter.status === 'over' && (
        <p className="mt-2 text-xs text-rose-300">
          You&apos;re past today&apos;s budget. Spending less on the next few days keeps your allowance on track.
        </p>
      )}
      {meter.status === 'warn' && (
        <p className="mt-2 text-xs text-amber-300">Almost at today&apos;s budget. Easy does it!</p>
      )}
      <p className="mt-2 text-[11px] text-zinc-500">
        Based on what&apos;s left after your scheduled expenses, divided across the remaining days.
      </p>
    </div>
  );
};
