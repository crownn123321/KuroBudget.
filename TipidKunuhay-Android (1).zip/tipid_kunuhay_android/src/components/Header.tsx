import React from 'react';
import {
  Wallet,
  Calendar,
  Plus,
  Clock,
  Settings,
  PieChart,
  Archive,
  Calculator,
} from 'lucide-react';
import { AllowanceConfig } from '../types/budget';

interface HeaderProps {
  config: AllowanceConfig;
  onOpenAddExpense: () => void;
  onOpenAddScheduled: () => void;
  onOpenSettings: () => void;
  onOpenAnalytics: () => void;
  onOpenCalculator: () => void;
  onOpenArchives: () => void;
}

export const Header: React.FC<HeaderProps> = ({
  config,
  onOpenAddExpense,
  onOpenAddScheduled,
  onOpenSettings,
  onOpenAnalytics,
  onOpenCalculator,
  onOpenArchives,
}) => {
  return (
    <header className="border-b border-zinc-800/70 bg-zinc-950/80 backdrop-blur-md sticky top-0 z-30">
      <div className="max-w-6xl mx-auto px-3 sm:px-6 min-h-16 py-2 flex items-center justify-between gap-2">
        {/* Brand */}
        <div className="flex items-center gap-2 sm:gap-3 min-w-0 shrink">
          <div className="w-8 h-8 sm:w-9 sm:h-9 rounded-xl bg-gradient-to-br from-emerald-500 to-teal-700 flex items-center justify-center shadow-lg shadow-emerald-950/40 border border-emerald-400/20">
            <Wallet className="w-5 h-5 text-zinc-950" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <span className="font-bold tracking-tight text-zinc-100 text-base sm:text-lg">
                Tipid <span className="text-emerald-400 font-semibold">Kunuhay</span>
              </span>
              <span className="hidden sm:inline-flex items-center px-2 py-0.5 rounded-full text-[10px] font-medium bg-emerald-500/10 text-emerald-400 border border-emerald-500/20">
                Allowance Flow
              </span>
            </div>
          </div>
        </div>

        {/* Center / Period summary badge */}
        <div className="hidden md:flex items-center gap-2 px-3 py-1.5 rounded-lg bg-zinc-900/80 border border-zinc-800 text-xs text-zinc-400">
          <Calendar className="w-3.5 h-3.5 text-zinc-500" />
          <span>{config.cycleName || 'Current Cycle'}:</span>
          <span className="text-zinc-200 font-medium">
            {config.startDate} &rarr; {config.endDate}
          </span>
        </div>

        {/* Action Buttons */}
        <div className="flex items-center gap-1 sm:gap-2 shrink-0">
          <button
            onClick={onOpenArchives}
            aria-label="View past budget reports and archives"
            className="hidden sm:inline-flex p-2 rounded-xl text-zinc-400 hover:text-amber-300 hover:bg-zinc-900 border border-transparent hover:border-zinc-800 transition-colors"
            title="Past Budget Reports"
          >
            <Archive className="w-4 h-4" />
          </button>

          <button
            onClick={onOpenAnalytics}
            aria-label="View spending breakdown and analytics"
            className="p-2 rounded-xl text-zinc-400 hover:text-zinc-200 hover:bg-zinc-900 border border-transparent hover:border-zinc-800 transition-colors"
            title="Analytics"
          >
            <PieChart className="w-4 h-4" />
          </button>

          <button
            onClick={onOpenSettings}
            aria-label="Configure allowance"
            className="p-2 rounded-xl text-zinc-400 hover:text-zinc-200 hover:bg-zinc-900 border border-transparent hover:border-zinc-800 transition-colors"
            title="Allowance Settings"
          >
            <Settings className="w-4 h-4" />
          </button>

          <button
            onClick={onOpenCalculator}
            aria-label="Open calculator"
            className="p-2 rounded-xl text-zinc-400 hover:text-sky-300 hover:bg-zinc-900 border border-transparent hover:border-zinc-800 transition-colors"
            title="Calculator"
          >
            <Calculator className="w-4 h-4" />
          </button>

          <button
            onClick={onOpenAddScheduled}
            aria-label="Add scheduled or recurring expense for specific day"
            className="hidden sm:inline-flex items-center gap-1.5 px-3 py-2 rounded-xl text-xs font-medium text-sky-300 bg-sky-950/40 hover:bg-sky-900/50 border border-sky-800/50 transition-colors"
          >
            <Clock className="w-3.5 h-3.5" />
            <span>Schedule</span>
          </button>

          <button
            onClick={onOpenAddExpense}
            aria-label="Deduct an expense from allowance"
            className="inline-flex items-center gap-1.5 px-3.5 py-2 rounded-xl text-xs font-semibold text-zinc-950 bg-emerald-400 hover:bg-emerald-300 shadow-md shadow-emerald-950/50 transition-all hover:scale-[1.02] active:scale-[0.98]"
          >
            <Plus className="w-4 h-4 stroke-[2.5]" />
            <span className="sm:hidden">Minus</span>
            <span className="hidden sm:inline">Minus Expense</span>
          </button>
        </div>
      </div>
    </header>
  );
};
