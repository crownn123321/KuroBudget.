import React, { useState } from 'react';
import { HandCoins, Plus, Trash2, CheckCircle2, Undo2 } from 'lucide-react';
import { AllowanceConfig, Debt, DebtDirection } from '../types/budget';
import { formatCurrency, parseISODate, toISODateString } from '../utils/budgetCalculations';
import { CollapsibleCard } from './CollapsibleCard';

interface DebtsSectionProps {
  config: AllowanceConfig;
  debts: Debt[];
  onAddDebt: (data: Omit<Debt, 'id' | 'createdAt' | 'settled'>) => void;
  onToggleSettled: (id: string) => void;
  onDeleteDebt: (id: string) => void;
}

function dueLabel(due?: string): { text: string; tone: string } | null {
  if (!due) return null;
  const today = parseISODate(toISODateString(new Date()));
  const diff = Math.round((parseISODate(due).getTime() - today.getTime()) / 86_400_000);
  if (diff < 0) return { text: `Overdue by ${-diff} day${diff === -1 ? '' : 's'}`, tone: 'text-rose-400' };
  if (diff === 0) return { text: 'Due today', tone: 'text-amber-400' };
  if (diff === 1) return { text: 'Due tomorrow', tone: 'text-amber-300' };
  return { text: `Due in ${diff} days`, tone: 'text-zinc-400' };
}

export const DebtsSection: React.FC<DebtsSectionProps> = ({
  config,
  debts,
  onAddDebt,
  onToggleSettled,
  onDeleteDebt,
}) => {
  const [person, setPerson] = useState('');
  const [amount, setAmount] = useState('');
  const [direction, setDirection] = useState<DebtDirection>('lent');
  const [dueDate, setDueDate] = useState('');
  const [note, setNote] = useState('');
  const sym = config.currencySymbol;

  const open = debts.filter((d) => !d.settled);
  const owedToMe = open.filter((d) => d.direction === 'lent').reduce((s, d) => s + d.amount, 0);
  const iOwe = open.filter((d) => d.direction === 'borrowed').reduce((s, d) => s + d.amount, 0);

  const submit = (e: React.FormEvent) => {
    e.preventDefault();
    const value = parseFloat(amount);
    if (!person.trim() || isNaN(value) || value <= 0) return;
    onAddDebt({
      person: person.trim(),
      amount: value,
      direction,
      dueDate: dueDate || undefined,
      note: note.trim() || undefined,
    });
    setPerson('');
    setAmount('');
    setDueDate('');
    setNote('');
  };

  const sorted = [...debts].sort((a, b) => {
    if (a.settled !== b.settled) return a.settled ? 1 : -1;
    return (a.dueDate || '9999').localeCompare(b.dueDate || '9999');
  });

  const inputCls =
    'bg-zinc-950 border border-zinc-700/80 rounded-xl px-3 py-2 text-xs text-zinc-100 placeholder-zinc-500 focus:outline-none focus:ring-2 focus:ring-sky-500/40';

  return (
    <CollapsibleCard
      id="debts"
      icon={<HandCoins className="w-5 h-5" />}
      iconClassName="bg-violet-500/10 border-violet-500/20 text-violet-400"
      title="Utang Tracker"
      badge={
        <span className="text-xs font-semibold px-2 py-0.5 rounded-full bg-violet-500/10 text-violet-300 border border-violet-500/20">
          {open.length} open
        </span>
      }
      subtitle={`Owed to you ${formatCurrency(owedToMe, sym)} • You owe ${formatCurrency(iOwe, sym)}`}
    >
      <form onSubmit={submit} className="grid grid-cols-2 gap-2 mb-4">
        <select
          value={direction}
          onChange={(e) => setDirection(e.target.value as DebtDirection)}
          aria-label="Lent or borrowed"
          className={`${inputCls} col-span-2`}
        >
          <option value="lent" className="bg-zinc-900">I lent money (they owe me)</option>
          <option value="borrowed" className="bg-zinc-900">I borrowed money (I owe them)</option>
        </select>
        <input
          type="text"
          placeholder="Person's name"
          aria-label="Person"
          value={person}
          onChange={(e) => setPerson(e.target.value)}
          className={inputCls}
        />
        <div className="relative">
          <span className="absolute left-3 top-1/2 -translate-y-1/2 text-zinc-500 font-mono text-xs">{sym}</span>
          <input
            type="number"
            step="0.01"
            min="0.01"
            placeholder="Amount"
            aria-label="Amount"
            value={amount}
            onChange={(e) => setAmount(e.target.value)}
            className={`${inputCls} w-full pl-7 font-mono`}
          />
        </div>
        <div>
          <label className="block text-[11px] text-zinc-500 mb-1">Due date (optional)</label>
          <input type="date" value={dueDate} onChange={(e) => setDueDate(e.target.value)} className={`${inputCls} w-full`} />
        </div>
        <div>
          <label className="block text-[11px] text-zinc-500 mb-1">Note (optional)</label>
          <input
            type="text"
            placeholder="e.g. for lunch"
            value={note}
            onChange={(e) => setNote(e.target.value)}
            className={`${inputCls} w-full`}
          />
        </div>
        <button
          type="submit"
          className="col-span-2 inline-flex items-center justify-center gap-1.5 px-4 py-2 rounded-xl text-xs font-semibold text-zinc-950 bg-violet-400 hover:bg-violet-300"
        >
          <Plus className="w-3.5 h-3.5" /> Add utang
        </button>
      </form>

      {debts.length === 0 ? (
        <div className="text-center py-8 px-4 rounded-2xl border border-dashed border-zinc-800 bg-zinc-950/40">
          <HandCoins className="w-8 h-8 text-zinc-600 mx-auto mb-2" />
          <p className="text-sm font-semibold text-zinc-300">No utang recorded</p>
          <p className="text-xs text-zinc-500 mt-1">Track money you lent or borrowed so nothing gets forgotten.</p>
        </div>
      ) : (
        <div className="space-y-2">
          {sorted.map((d) => {
            const due = d.settled ? null : dueLabel(d.dueDate);
            return (
              <div
                key={d.id}
                className={`flex items-center justify-between gap-3 p-3 rounded-2xl bg-zinc-950/60 border border-zinc-800/80 ${
                  d.settled ? 'opacity-60' : ''
                }`}
              >
                <div className="min-w-0">
                  <div className="text-sm font-semibold text-zinc-100 truncate">
                    {d.direction === 'lent' ? `${d.person} owes you` : `You owe ${d.person}`}
                    {d.settled && <span className="ml-2 text-[10px] font-medium text-emerald-400">Settled</span>}
                  </div>
                  <div className="text-[11px] text-zinc-500 truncate">
                    {d.note ? `${d.note}` : ''}
                    {d.note && d.dueDate ? ' • ' : ''}
                    {d.dueDate ? `Due ${d.dueDate}` : ''}
                  </div>
                  {due && <div className={`text-[11px] font-medium ${due.tone}`}>{due.text}</div>}
                </div>
                <div className="flex items-center gap-1.5 shrink-0">
                  <span className={`font-mono font-bold text-sm ${d.direction === 'lent' ? 'text-emerald-400' : 'text-rose-400'}`}>
                    {formatCurrency(d.amount, sym)}
                  </span>
                  <button
                    type="button"
                    onClick={() => onToggleSettled(d.id)}
                    aria-label={d.settled ? `Mark ${d.person} utang as unsettled` : `Mark ${d.person} utang as settled`}
                    title={d.settled ? 'Mark unsettled' : 'Mark settled'}
                    className="p-1.5 rounded-lg text-zinc-400 hover:text-emerald-400 hover:bg-zinc-800 transition-colors"
                  >
                    {d.settled ? <Undo2 className="w-4 h-4" /> : <CheckCircle2 className="w-4 h-4" />}
                  </button>
                  <button
                    type="button"
                    onClick={() => onDeleteDebt(d.id)}
                    aria-label={`Delete utang for ${d.person}`}
                    className="p-1.5 rounded-lg text-zinc-500 hover:text-rose-400 hover:bg-zinc-800 transition-colors"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>
              </div>
            );
          })}
          <p className="text-[11px] text-zinc-500">Utang is tracked separately and doesn&apos;t change your allowance balance.</p>
        </div>
      )}
    </CollapsibleCard>
  );
};
