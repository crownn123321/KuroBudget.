import type { CapacitorConfig } from '@capacitor/cli';

const config: CapacitorConfig = {
  appId: 'com.tipidkunuhay.app',
  appName: 'Tipid Kunuhay',
  webDir: 'dist',
};

export default config;
