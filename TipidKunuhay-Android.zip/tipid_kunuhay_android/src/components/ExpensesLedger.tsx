import React, { useState, useMemo } from 'react';
import {
  Receipt,
  Search,
  Trash2,
  Calendar,
  Download,
  Filter,
  Tag,
  Clock,
  RotateCcw,
} from 'lucide-react';
import { AllowanceConfig, Expense, ExpenseCategory } from '../types/budget';
import {
  formatCurrency,
  CATEGORY_COLORS,
  CATEGORIES,
} from '../utils/budgetCalculations';
import { escapeCsvCell, exportCsvFile } from '../utils/exportCsv';

interface ExpensesLedgerProps {
  config: AllowanceConfig;
  expenses: Expense[];
  onDeleteExpense: (id: string) => void;
  onClearAllExpenses: () => void;
}

export const ExpensesLedger: React.FC<ExpensesLedgerProps> = ({
  config,
  expenses,
  onDeleteExpense,
  onClearAllExpenses,
}) => {
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<string>('All');
  const [confirmClear, setConfirmClear] = useState(false);

  const filteredExpenses = useMemo(() => {
    return expenses
      .filter((exp) => {
        const matchesCategory =
          selectedCategory === 'All' || exp.category === selectedCategory;
        const matchesQuery =
          exp.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
          (exp.note && exp.note.toLowerCase().includes(searchQuery.toLowerCase()));
        return matchesCategory && matchesQuery;
      })
      .sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime());
  }, [expenses, searchQuery, selectedCategory]);

  const totalFiltered = filteredExpenses.reduce((sum, e) => sum + e.amount, 0);

  const handleExportCSV = async () => {
    const headers = ['Date', 'Title', 'Category', 'Amount', 'Note', 'Scheduled'];
    const rows = filteredExpenses.map((exp) => [
      exp.date,
      exp.title,
      exp.category,
      exp.amount.toFixed(2),
      exp.note || '',
      exp.scheduledId ? 'Yes' : 'No',
    ]);
    const csvContent = [headers, ...rows]
      .map((row) => row.map(escapeCsvCell).join(','))
      .join('\r\n');

    try {
      await exportCsvFile(
        `tipid-kunuhay-expenses-${new Date().toISOString().slice(0, 10)}.csv`,
        csvContent,
        'Tipid Kunuhay - Expenses'
      );
    } catch (error) {
      console.error('Failed to export expenses CSV:', error);
      window.alert('Unable to export the CSV file. Please try again.');
    }
  };

  return (
    <div className="rounded-3xl bg-zinc-900/60 border border-zinc-800/80 p-6 sm:p-7 shadow-xl">
      {/* Header & Controls */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 pb-5 border-b border-zinc-800/70">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-emerald-500/10 border border-emerald-500/20 flex items-center justify-center text-emerald-400">
            <Receipt className="w-5 h-5" />
          </div>
          <div>
            <h2 className="text-lg font-bold text-zinc-100 flex items-center gap-2">
              <span>Expenses Deducted</span>
              <span className="text-xs font-semibold px-2 py-0.5 rounded-full bg-zinc-800 text-zinc-300">
                {filteredExpenses.length} of {expenses.length}
              </span>
            </h2>
            <p className="text-xs text-zinc-400">
              Total deducted in this view:{' '}
              <strong className="text-zinc-200 font-mono">
                {formatCurrency(totalFiltered, config.currencySymbol)}
              </strong>
            </p>
          </div>
        </div>

        <div className="flex items-center gap-2 flex-wrap">
          <button
            onClick={handleExportCSV}
            disabled={expenses.length === 0}
            className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-medium text-zinc-300 bg-zinc-900 hover:bg-zinc-800 border border-zinc-800 hover:border-zinc-700 transition-colors disabled:opacity-40"
            title="Download CSV export"
          >
            <Download className="w-3.5 h-3.5" />
            <span>Export CSV</span>
          </button>

          {expenses.length > 0 && (
            confirmClear ? (
              <div className="flex items-center gap-1.5">
                <span className="text-xs text-rose-400">Clear all?</span>
                <button
                  onClick={() => {
                    onClearAllExpenses();
                    setConfirmClear(false);
                  }}
                  className="px-2.5 py-1 rounded-lg text-xs font-semibold bg-rose-500 text-white hover:bg-rose-600 transition-colors"
                >
                  Yes, Clear
                </button>
                <button
                  onClick={() => setConfirmClear(false)}
                  className="px-2.5 py-1 rounded-lg text-xs font-medium bg-zinc-800 text-zinc-300 hover:bg-zinc-700 transition-colors"
                >
                  Cancel
                </button>
              </div>
            ) : (
              <button
                onClick={() => setConfirmClear(true)}
                className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-medium text-zinc-400 hover:text-rose-400 bg-zinc-900 hover:bg-rose-950/20 border border-zinc-800 hover:border-rose-900/40 transition-colors"
                title="Clear all recorded deductions"
              >
                <Trash2 className="w-3.5 h-3.5" />
                <span>Clear All</span>
              </button>
            )
          )}
        </div>
      </div>

      {/* Search and Category Filters */}
      <div className="my-5 space-y-3">
        <div className="relative">
          <Search className="w-4 h-4 text-zinc-500 absolute left-3.5 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            placeholder="Search deductions by title or note..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full bg-zinc-950 border border-zinc-800 rounded-xl pl-9 pr-4 py-2 text-xs text-zinc-200 placeholder-zinc-500 focus:outline-none focus:ring-2 focus:ring-emerald-500/40 focus:border-emerald-500/60 transition-all"
          />
        </div>

        {/* Category Pills */}
        <div className="flex items-center gap-1.5 overflow-x-auto pb-1 text-xs no-scrollbar">
          <button
            onClick={() => setSelectedCategory('All')}
            className={`px-3 py-1 rounded-lg font-medium whitespace-nowrap transition-all ${
              selectedCategory === 'All'
                ? 'bg-zinc-100 text-zinc-950 shadow-sm'
                : 'bg-zinc-950 text-zinc-400 hover:text-zinc-200 border border-zinc-800'
            }`}
          >
            All
          </button>
          {CATEGORIES.map((cat) => (
            <button
              key={cat}
              onClick={() => setSelectedCategory(cat)}
              className={`px-2.5 py-1 rounded-lg font-medium whitespace-nowrap transition-all ${
                selectedCategory === cat
                  ? 'bg-zinc-100 text-zinc-950 shadow-sm'
                  : 'bg-zinc-950 text-zinc-400 hover:text-zinc-200 border border-zinc-800'
              }`}
            >
              {cat}
            </button>
          ))}
        </div>
      </div>

      {/* Deduction Items */}
      <div className="space-y-2">
        {filteredExpenses.length === 0 ? (
          <div className="text-center py-12 px-4 rounded-2xl border border-dashed border-zinc-800 bg-zinc-950/40">
            <Receipt className="w-8 h-8 text-zinc-600 mx-auto mb-2" />
            <p className="text-sm font-semibold text-zinc-300">
              {expenses.length === 0 ? 'No deductions recorded yet' : 'No matching expenses'}
            </p>
            <p className="text-xs text-zinc-500 mt-1">
              {expenses.length === 0
                ? 'Use the Quick Minus bar above to deduct your first expense from your allowance.'
                : 'Try clearing your search query or choosing another category filter.'}
            </p>
          </div>
        ) : (
          filteredExpenses.map((exp) => {
            const colorInfo = CATEGORY_COLORS[exp.category];
            const expenseDate = new Date(exp.date);

            return (
              <div
                key={exp.id}
                className="group flex items-center justify-between p-3 sm:p-3.5 rounded-2xl bg-zinc-950/60 border border-zinc-800/80 hover:border-zinc-700 transition-all"
              >
                <div className="flex items-center gap-3">
                  <div
                    className={`w-2.5 h-2.5 rounded-full shrink-0 ${
                      colorInfo ? colorInfo.dot : 'bg-zinc-500'
                    }`}
                  />
                  <div>
                    <div className="flex flex-wrap items-center gap-2">
                      <span className="font-semibold text-sm text-zinc-100">
                        {exp.title}
                      </span>
                      <span
                        className={`text-[10px] px-2 py-0.5 rounded-md font-medium ${
                          colorInfo ? colorInfo.bg : 'bg-zinc-800'
                        } ${colorInfo ? colorInfo.text : 'text-zinc-400'}`}
                      >
                        {exp.category}
                      </span>
                      {exp.scheduledId && (
                        <span className="text-[10px] px-1.5 py-0.5 rounded-md bg-sky-500/10 text-sky-400 border border-sky-500/20 flex items-center gap-1">
                          <Clock className="w-2.5 h-2.5" />
                          Scheduled
                        </span>
                      )}
                    </div>
                    {exp.note && (
                      <p className="text-xs text-zinc-500 mt-0.5">{exp.note}</p>
                    )}
                    <div className="text-[11px] text-zinc-500 flex items-center gap-1.5 mt-0.5">
                      <Calendar className="w-3 h-3 text-zinc-600" />
                      <span>
                        {expenseDate.toLocaleDateString('en-US', {
                          weekday: 'short',
                          month: 'short',
                          day: 'numeric',
                        })}
                      </span>
                      <span className="text-zinc-600">&bull;</span>
                      <span>
                        {expenseDate.toLocaleTimeString('en-US', {
                          hour: '2-digit',
                          minute: '2-digit',
                        })}
                      </span>
                    </div>
                  </div>
                </div>

                <div className="flex items-center gap-3">
                  <div className="text-right">
                    <span className="font-mono font-bold text-sm sm:text-base text-rose-400">
                      -{formatCurrency(exp.amount, config.currencySymbol)}
                    </span>
                  </div>

                  <button
                    onClick={() => onDeleteExpense(exp.id)}
                    aria-label={`Delete expense ${exp.title} and restore amount to allowance`}
                    className="p-1.5 rounded-lg text-zinc-500 hover:text-zinc-200 hover:bg-zinc-800 transition-colors"
                    title="Delete and refund to allowance"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>
              </div>
            );
          })
        )}
      </div>
    </div>
  );
};
