import React, { useState } from 'react';
import {
  X,
  Smartphone,
  Share2,
  PlusSquare,
  Copy,
  Check,
  Download,
  Apple,
  QrCode,
  Sparkles,
  HelpCircle,
  FileCode,
  ShieldCheck,
  Zap,
} from 'lucide-react';
import { usePWAInstall } from '../utils/usePWAInstall';

interface InstallPhoneModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const InstallPhoneModal: React.FC<InstallPhoneModalProps> = ({
  isOpen,
  onClose,
}) => {
  const { isInstallable, isInstalled, isNativeApp, install } = usePWAInstall();
  const [activeTab, setActiveTab] = useState<'infinix' | 'ios' | 'qr' | 'apk'>('infinix');
  const [copied, setCopied] = useState(false);

  if (!isOpen) return null;

  // Real accessible URL for phone scanning and loading
  const appUrl =
    typeof window !== 'undefined' && window.location.origin.includes('run.app')
      ? window.location.origin
      : 'https://ais-pre-etn4eciemmqqycv6b6tmqn-895272104268.asia-east1.run.app';

  const handleCopy = async () => {
    try {
      if (navigator.clipboard?.writeText) {
        await navigator.clipboard.writeText(appUrl);
      } else {
        const temporaryInput = document.createElement('textarea');
        temporaryInput.value = appUrl;
        temporaryInput.setAttribute('readonly', '');
        temporaryInput.style.position = 'fixed';
        temporaryInput.style.opacity = '0';
        document.body.appendChild(temporaryInput);
        temporaryInput.select();
        const copiedSuccessfully = document.execCommand('copy');
        temporaryInput.remove();
        if (!copiedSuccessfully) throw new Error('Clipboard copy was unavailable.');
      }
      setCopied(true);
      window.setTimeout(() => setCopied(false), 2500);
    } catch (error) {
      console.error('Unable to copy app link:', error);
      window.alert('Unable to copy the link on this device.');
    }
  };

  const handleInstallClick = async () => {
    const success = await install();
    if (success) {
      onClose();
    }
  };

  const qrUrl = `https://api.qrserver.com/v1/create-qr-code/?size=240x240&data=${encodeURIComponent(
    appUrl
  )}&bgcolor=09090b&color=34d399&margin=1`;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-zinc-950/85 backdrop-blur-md animate-fade-in">
      <div className="relative w-full max-w-xl rounded-3xl bg-zinc-900 border border-zinc-800 p-6 sm:p-7 shadow-2xl max-h-[90dvh] overflow-y-auto">
        {/* Close Button */}
        <button
          onClick={onClose}
          aria-label="Close install guide dialog"
          className="absolute right-4 top-4 p-2 text-zinc-400 hover:text-zinc-100 hover:bg-zinc-800 rounded-xl transition-colors"
        >
          <X className="w-5 h-5" />
        </button>

        {/* Title */}
        <div className="flex items-center gap-3 mb-5">
          <div className="w-11 h-11 rounded-2xl bg-emerald-500/10 border border-emerald-500/20 flex items-center justify-center text-emerald-400 shrink-0">
            <Smartphone className="w-6 h-6" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h3 className="text-lg font-bold text-zinc-100">
                Install Tipid Kunuhay
              </h3>
              <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-emerald-500/15 text-emerald-300 border border-emerald-500/30">
                Android Ready
              </span>
            </div>
            <p className="text-xs text-zinc-400">
              Built for Android 6+ and modern mobile browsers
            </p>
          </div>
        </div>

        {/* User's Direct Question Clarification Callout */}
        <div className="mb-5 p-4 rounded-2xl bg-zinc-950 border border-zinc-800">
          <div className="flex items-start gap-2.5">
            <HelpCircle className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
            <div className="space-y-1">
              <h4 className="text-xs font-bold text-zinc-200">
                "Do I just need the code to make an app on my Android phone?"
              </h4>
              <p className="text-[11px] text-zinc-400 leading-relaxed">
                {isNativeApp ? (
                  <><strong className="text-emerald-300">Tipid Kunuhay is installed as an Android app.</strong> Your allowance, expenses, schedules, and archived reports are stored on this device.</>
                ) : isInstalled ? (
                  <><strong className="text-emerald-300">This app is installed.</strong> Your allowance, expenses, schedules, and archived reports are stored on this device.</>
                ) : (
                  <><strong className="text-emerald-300">Web install is available.</strong> You can add this PWA to your home screen from Chrome. For a standalone APK installer, use the Make APK tab.</>
                )}
              </p>
            </div>
          </div>
        </div>

        {/* One-click native install button if available in Chrome/Android */}
        {isInstallable && (
          <div className="mb-5 p-4 rounded-2xl bg-gradient-to-r from-emerald-950/70 to-zinc-900 border border-emerald-500/30 flex items-center justify-between gap-3">
            <div>
              <div className="text-xs font-bold text-emerald-300 flex items-center gap-1.5">
                <Sparkles className="w-4 h-4 text-emerald-400" />
                Browser Install Detected!
              </div>
              <div className="text-[11px] text-zinc-400">
                Tap below to install directly to your Android home screen.
              </div>
            </div>
            <button
              onClick={handleInstallClick}
              className="px-4 py-2 rounded-xl text-xs font-bold text-zinc-950 bg-emerald-400 hover:bg-emerald-300 shadow-md shadow-emerald-950/40 transition-transform active:scale-95 flex items-center gap-1.5 whitespace-nowrap"
            >
              <Download className="w-3.5 h-3.5" />
              <span>Install on Android</span>
            </button>
          </div>
        )}

        {/* Device Switcher Tabs */}
        <div className="grid grid-cols-4 gap-1.5 p-1 rounded-xl bg-zinc-950 border border-zinc-800 text-xs font-medium mb-5">
          <button
            type="button"
            onClick={() => setActiveTab('infinix')}
            className={`py-2 px-2.5 rounded-lg flex items-center justify-center gap-1 transition-all ${
              activeTab === 'infinix'
                ? 'bg-zinc-800 text-emerald-300 shadow-sm font-bold border border-zinc-700'
                : 'text-zinc-400 hover:text-zinc-200'
            }`}
          >
            <Smartphone className="w-3.5 h-3.5 text-emerald-400" />
            <span className="truncate">Android</span>
          </button>
          <button
            type="button"
            onClick={() => setActiveTab('qr')}
            className={`py-2 px-2.5 rounded-lg flex items-center justify-center gap-1 transition-all ${
              activeTab === 'qr'
                ? 'bg-zinc-800 text-sky-300 shadow-sm font-bold border border-zinc-700'
                : 'text-zinc-400 hover:text-zinc-200'
            }`}
          >
            <QrCode className="w-3.5 h-3.5 text-sky-400" />
            <span className="truncate">Scan QR</span>
          </button>
          <button
            type="button"
            onClick={() => setActiveTab('apk')}
            className={`py-2 px-2.5 rounded-lg flex items-center justify-center gap-1 transition-all ${
              activeTab === 'apk'
                ? 'bg-zinc-800 text-amber-300 shadow-sm font-bold border border-zinc-700'
                : 'text-zinc-400 hover:text-zinc-200'
            }`}
          >
            <FileCode className="w-3.5 h-3.5 text-amber-400" />
            <span className="truncate">Make APK</span>
          </button>
          <button
            type="button"
            onClick={() => setActiveTab('ios')}
            className={`py-2 px-2.5 rounded-lg flex items-center justify-center gap-1 transition-all ${
              activeTab === 'ios'
                ? 'bg-zinc-800 text-zinc-100 shadow-sm font-bold border border-zinc-700'
                : 'text-zinc-400 hover:text-zinc-200'
            }`}
          >
            <Apple className="w-3.5 h-3.5" />
            <span className="truncate">iPhone / iOS</span>
          </button>
        </div>

        {/* Tab 1: Android phone 4G & Android Instructions */}
        {activeTab === 'infinix' && (
          <div className="space-y-4">
            <div className="p-4 rounded-2xl bg-zinc-950/80 border border-zinc-800 space-y-3">
              <div className="text-xs font-bold text-zinc-200 flex items-center justify-between">
                <span>Android phone (Google Chrome)</span>
                <span className="text-[10px] text-emerald-400 bg-emerald-500/10 px-2 py-0.5 rounded-md border border-emerald-500/20 font-mono">
                  1-Tap Install
                </span>
              </div>

              <div className="flex items-start gap-3">
                <div className="w-6 h-6 rounded-full bg-emerald-500/10 border border-emerald-500/30 text-emerald-400 flex items-center justify-center text-xs font-bold shrink-0">
                  1
                </div>
                <div className="text-xs text-zinc-200">
                  Open <strong>Google Chrome</strong> on your Android phone and paste this link (or scan the QR code in the next tab).
                </div>
              </div>

              <div className="flex items-start gap-3">
                <div className="w-6 h-6 rounded-full bg-emerald-500/10 border border-emerald-500/30 text-emerald-400 flex items-center justify-center text-xs font-bold shrink-0">
                  2
                </div>
                <div className="text-xs text-zinc-200">
                  Tap Chrome's <strong>three dots menu (⋮)</strong> at the top right of your screen.
                </div>
              </div>

              <div className="flex items-start gap-3">
                <div className="w-6 h-6 rounded-full bg-emerald-500/10 border border-emerald-500/30 text-emerald-400 flex items-center justify-center text-xs font-bold shrink-0">
                  3
                </div>
                <div className="text-xs text-zinc-200">
                  Select <strong className="text-emerald-300">"Install app"</strong> (or <strong className="text-emerald-300">"Add to Home screen"</strong>).
                </div>
              </div>

              <div className="flex items-start gap-3">
                <div className="w-6 h-6 rounded-full bg-emerald-500/10 border border-emerald-500/30 text-emerald-400 flex items-center justify-center text-xs font-bold shrink-0">
                  4
                </div>
                <div className="text-xs text-zinc-200">
                  Tap <strong>Install</strong>. The <strong>Tipid Kunuhay</strong> icon will instantly appear on your Android home screen and app drawer!
                </div>
              </div>
            </div>

            {/* Alternate Android browser note */}
            <div className="p-3.5 rounded-xl bg-zinc-950 border border-zinc-800 text-[11px] text-zinc-400 leading-relaxed">
              <strong className="text-zinc-200">Using another Android browser?</strong> Open its browser menu and choose <strong>"Add to Home screen"</strong> when available.
            </div>
          </div>
        )}

        {/* Tab 2: QR Code */}
        {activeTab === 'qr' && (
          <div className="flex flex-col items-center justify-center py-2 space-y-3 text-center">
            <div className="p-3 bg-zinc-950 rounded-2xl border border-zinc-800 shadow-inner">
              <img
                src={qrUrl}
                alt="Scan to open Tipid Kunuhay on your Android phone"
                width={200}
                height={200}
                className="rounded-xl border border-zinc-800"
              />
            </div>
            <div className="space-y-1">
              <p className="text-xs font-semibold text-zinc-200">
                Scan with your Android camera
              </p>
              <p className="text-[11px] text-zinc-400 max-w-sm">
                Open your Android camera app or Google Lens, point it at this QR code, and tap the link to launch <strong>Tipid Kunuhay</strong> instantly.
              </p>
            </div>
          </div>
        )}

        {/* Tab 3: APK / No-Code App Maker */}
        {activeTab === 'apk' && (
          <div className="space-y-3.5">
            <div className="p-4 rounded-2xl bg-zinc-950 border border-zinc-800 space-y-2.5">
              <div className="flex items-center gap-2 text-xs font-bold text-amber-300">
                <FileCode className="w-4 h-4 text-amber-400" />
                <span>How to get an APK file without coding</span>
              </div>
              <p className="text-[11px] text-zinc-300 leading-relaxed">
                Build a standalone <strong>.APK installer</strong> from this project on a computer with Node.js and Android Studio:
              </p>
              <ol className="text-[11px] text-zinc-400 space-y-2 pl-4 list-decimal">
                <li>Extract the Tipid Kunuhay Android source ZIP and open its folder in a terminal.</li>
                <li>Run <code className="text-emerald-400 font-mono text-[10px]">npm install</code> to install the project dependencies.</li>
                <li>Run <code className="text-emerald-400 font-mono text-[10px]">npm run android:init</code> once to create the Android project.</li>
                <li>Run <code className="text-emerald-400 font-mono text-[10px]">npm run android:sync</code>, then <code className="text-emerald-400 font-mono text-[10px]">npm run android:open</code>.</li>
                <li>In Android Studio, choose <strong>Build</strong> &rarr; <strong>Build Bundle(s) / APK(s)</strong> &rarr; <strong>Build APK(s)</strong>.</li>
              </ol>
              <p className="text-[10px] text-zinc-500 leading-relaxed">
                The debug APK is created at <code className="text-emerald-400 font-mono">android/app/build/outputs/apk/debug/app-debug.apk</code>. Android SDK and JDK setup are required on the build computer.
              </p>
            </div>

            <div className="p-3 rounded-xl bg-emerald-500/10 border border-emerald-500/20 text-[11px] text-emerald-300 flex items-center gap-2">
              <ShieldCheck className="w-4 h-4 shrink-0 text-emerald-400" />
              <span>
                Tip: Installing via Chrome (Tab 1) is faster and updates automatically without downloading APK files!
              </span>
            </div>
          </div>
        )}

        {/* Tab 4: iOS Safari */}
        {activeTab === 'ios' && (
          <div className="space-y-3.5">
            <div className="p-4 rounded-2xl bg-zinc-950/80 border border-zinc-800 space-y-3">
              <div className="flex items-start gap-3">
                <div className="w-6 h-6 rounded-full bg-emerald-500/10 border border-emerald-500/30 text-emerald-400 flex items-center justify-center text-xs font-bold shrink-0">
                  1
                </div>
                <div className="text-xs text-zinc-200">
                  Open this link in <strong>Safari</strong> on your iPhone or iPad.
                </div>
              </div>

              <div className="flex items-start gap-3">
                <div className="w-6 h-6 rounded-full bg-emerald-500/10 border border-emerald-500/30 text-emerald-400 flex items-center justify-center text-xs font-bold shrink-0">
                  2
                </div>
                <div className="text-xs text-zinc-200">
                  Tap the <strong className="text-sky-300">Share button</strong> (the square with an arrow pointing upward <Share2 className="w-3.5 h-3.5 inline mx-1 text-sky-400" />).
                </div>
              </div>

              <div className="flex items-start gap-3">
                <div className="w-6 h-6 rounded-full bg-emerald-500/10 border border-emerald-500/30 text-emerald-400 flex items-center justify-center text-xs font-bold shrink-0">
                  3
                </div>
                <div className="text-xs text-zinc-200">
                  Scroll down in the share sheet and tap{' '}
                  <strong className="text-emerald-300 flex items-center gap-1 my-1">
                    <PlusSquare className="w-3.5 h-3.5 text-emerald-400" />
                    "Add to Home Screen"
                  </strong>
                </div>
              </div>

              <div className="flex items-start gap-3">
                <div className="w-6 h-6 rounded-full bg-emerald-500/10 border border-emerald-500/30 text-emerald-400 flex items-center justify-center text-xs font-bold shrink-0">
                  4
                </div>
                <div className="text-xs text-zinc-200">
                  Tap <strong>Add</strong>. The Tipid Kunuhay icon will appear on your home screen!
                </div>
              </div>
            </div>
          </div>
        )}

        {/* Share / Copy Link Section */}
        <div className="mt-5 pt-4 border-t border-zinc-800">
          <label className="block text-[11px] font-semibold uppercase tracking-wider text-zinc-400 mb-1.5">
            Tipid Kunuhay Link to Open on Android phone
          </label>
          <div className="flex items-center gap-2">
            <input
              type="text"
              readOnly
              value={appUrl}
              className="flex-1 bg-zinc-950 border border-zinc-800 rounded-xl px-3 py-2 text-xs text-zinc-300 font-mono truncate focus:outline-none"
            />
            <button
              onClick={handleCopy}
              className={`px-3.5 py-2 rounded-xl text-xs font-semibold flex items-center gap-1.5 transition-all ${
                copied
                  ? 'bg-emerald-500 text-zinc-950'
                  : 'bg-zinc-800 text-zinc-200 hover:bg-zinc-700 border border-zinc-700'
              }`}
            >
              {copied ? (
                <>
                  <Check className="w-3.5 h-3.5" />
                  <span>Copied!</span>
                </>
              ) : (
                <>
                  <Copy className="w-3.5 h-3.5" />
                  <span>Copy Link</span>
                </>
              )}
            </button>
          </div>
        </div>

        {/* Footer Info Highlights */}
        <div className="mt-4 flex flex-wrap items-center justify-between text-[11px] text-zinc-500 gap-2">
          <span className="flex items-center gap-1">
            <Zap className="w-3 h-3 text-emerald-400" />
            Runs Fullscreen on Android
          </span>
          <span>&bull; Works offline with local memory</span>
          <span>&bull; No Play Store account needed</span>
        </div>
      </div>
    </div>
  );
};
