import React, { useState } from 'react';
import {
  TrendingDown,
  ShieldCheck,
  CalendarDays,
  Zap,
  ArrowDownRight,
  Sparkles,
} from 'lucide-react';
import { AllowanceConfig, Expense, ExpenseCategory } from '../types/budget';
import {
  formatCurrency,
  calculateSpent,
  calculateRemainingAllowance,
  calculateSafeToSpend,
  calculateDaysRemaining,
  calculateDailyAllowance,
  CATEGORIES,
} from '../utils/budgetCalculations';
import { BudgetCircleGauge } from './BudgetCircleGauge';

interface AllowanceHeroCardProps {
  config: AllowanceConfig;
  expenses: Expense[];
  upcomingCommitmentTotal: number;
  onQuickDeduct: (amount: number, title: string, category: ExpenseCategory) => void;
  onOpenSettings: () => void;
}

export const AllowanceHeroCard: React.FC<AllowanceHeroCardProps> = ({
  config,
  expenses,
  upcomingCommitmentTotal,
  onQuickDeduct,
  onOpenSettings,
}) => {
  const [quickAmount, setQuickAmount] = useState('');
  const [quickTitle, setQuickTitle] = useState('');
  const [quickCategory, setQuickCategory] = useState<ExpenseCategory>('Food & Dining');

  const totalSpent = calculateSpent(expenses);
  const remainingAllowance = calculateRemainingAllowance(config.totalAllowance, expenses);
  const safeToSpend = calculateSafeToSpend(remainingAllowance, upcomingCommitmentTotal);
  const daysRemaining = calculateDaysRemaining(config.endDate);
  const dailyAllowance = calculateDailyAllowance(remainingAllowance, daysRemaining);

  const spentRatio = config.totalAllowance > 0
    ? Math.min(100, Math.max(0, (totalSpent / config.totalAllowance) * 100))
    : 0;
  const remainingRatio = Math.max(0, 100 - spentRatio);

  const isOverBudget = remainingAllowance < 0;
  const isLowBudget = !isOverBudget && remainingRatio < 20;

  const handleQuickSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const val = parseFloat(quickAmount);
    if (isNaN(val) || val <= 0) return;
    const title = quickTitle.trim() || `${quickCategory}`;
    onQuickDeduct(val, title, quickCategory);
    setQuickAmount('');
    setQuickTitle('');
  };

  const handleQuickChip = (amount: number, title: string, category: ExpenseCategory) => {
    onQuickDeduct(amount, title, category);
  };

  return (
    <div className="relative overflow-hidden rounded-3xl bg-gradient-to-b from-zinc-900/90 to-zinc-950 border border-zinc-800/80 shadow-2xl p-6 sm:p-8">
      {/* Subtle background ambient lighting */}
      <div
        className={`absolute -top-32 -right-32 w-80 h-80 rounded-full blur-3xl pointer-events-none opacity-20 ${
          isOverBudget
            ? 'bg-red-500'
            : isLowBudget
            ? 'bg-amber-500'
            : 'bg-emerald-500'
        }`}
      />

      <div className="relative z-10">
        {/* Top bar with Allowance Label, Status */}
        <div className="flex flex-wrap items-center justify-between gap-4 pb-4 border-b border-zinc-800/60">
          <div className="flex items-center gap-2 flex-wrap">
            <span className="text-xs uppercase tracking-wider font-semibold text-zinc-400">
              Current Allowance Balance
            </span>
            <button
              onClick={onOpenSettings}
              className="text-[11px] font-medium text-emerald-400 hover:text-emerald-300 underline underline-offset-2 ml-1"
            >
              (Edit {formatCurrency(config.totalAllowance, config.currencySymbol)})
            </button>
          </div>

          <div className="flex items-center gap-2">
            {isOverBudget ? (
              <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-semibold bg-rose-500/10 text-rose-400 border border-rose-500/20">
                <span className="w-1.5 h-1.5 rounded-full bg-rose-400 animate-pulse" />
                Over Allowance
              </span>
            ) : isLowBudget ? (
              <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-semibold bg-amber-500/10 text-amber-400 border border-amber-500/20">
                <span className="w-1.5 h-1.5 rounded-full bg-amber-400" />
                Low Balance ({remainingRatio.toFixed(0)}% Left)
              </span>
            ) : (
              <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-semibold bg-emerald-500/10 text-emerald-400 border border-emerald-500/20">
                <span className="w-1.5 h-1.5 rounded-full bg-emerald-400" />
                On Track ({remainingRatio.toFixed(0)}% Left)
              </span>
            )}
          </div>
        </div>

        {/* Hero Amount & Circular Gauge Section */}
        <div className="py-6 sm:py-7 flex flex-col lg:flex-row items-center justify-between gap-6">
          {/* Left Column: Big Numbers and Stat Cards */}
          <div className="flex-1 w-full space-y-5">
            <div>
              <div className="text-xs text-zinc-400 font-medium mb-1">
                Remaining to Spend
              </div>
              <div className="flex items-baseline gap-2 flex-wrap">
                <span
                  className={`text-4xl sm:text-5xl font-extrabold tracking-tight font-mono ${
                    isOverBudget
                      ? 'text-rose-400'
                      : isLowBudget
                      ? 'text-amber-300'
                      : 'text-zinc-50'
                  }`}
                >
                  {formatCurrency(remainingAllowance, config.currencySymbol)}
                </span>
                <span className="text-zinc-500 text-sm sm:text-base font-normal">
                  of {formatCurrency(config.totalAllowance, config.currencySymbol)}
                </span>
              </div>
            </div>

            {/* Safe-to-Spend & Daily Pace Highlights */}
            <div className="grid grid-cols-2 gap-3 max-w-md">
              <div className="bg-zinc-900/90 border border-zinc-800 rounded-2xl p-3.5">
                <div className="flex items-center gap-1.5 text-[11px] font-medium text-zinc-400 mb-0.5">
                  <ShieldCheck className="w-3.5 h-3.5 text-sky-400" />
                  <span>Safe to Spend</span>
                </div>
                <div className="text-base sm:text-lg font-bold font-mono text-sky-300">
                  {formatCurrency(safeToSpend, config.currencySymbol)}
                </div>
                <div className="text-[10px] text-zinc-500 truncate">
                  After {formatCurrency(upcomingCommitmentTotal, config.currencySymbol)} upcoming
                </div>
              </div>

              <div className="bg-zinc-900/90 border border-zinc-800 rounded-2xl p-3.5">
                <div className="flex items-center gap-1.5 text-[11px] font-medium text-zinc-400 mb-0.5">
                  <CalendarDays className="w-3.5 h-3.5 text-emerald-400" />
                  <span>Daily Allowance</span>
                </div>
                <div className="text-base sm:text-lg font-bold font-mono text-emerald-300">
                  {formatCurrency(dailyAllowance, config.currencySymbol)}
                  <span className="text-xs font-normal text-zinc-500">/day</span>
                </div>
                <div className="text-[10px] text-zinc-500 truncate">
                  {daysRemaining} day{daysRemaining === 1 ? '' : 's'} remaining
                </div>
              </div>
            </div>

            {/* Linear progressive bar */}
            <div className="space-y-1.5 max-w-md">
              <div className="flex justify-between text-[11px] text-zinc-400 font-medium">
                <span>Spent: {formatCurrency(totalSpent, config.currencySymbol)} ({spentRatio.toFixed(1)}%)</span>
                <span>Available: {formatCurrency(Math.max(0, remainingAllowance), config.currencySymbol)}</span>
              </div>
              <div className="h-2.5 w-full bg-zinc-800/80 rounded-full overflow-hidden p-0.5 border border-zinc-700/40">
                <div
                  className={`h-full rounded-full transition-all duration-500 ${
                    isOverBudget
                      ? 'bg-rose-500'
                      : isLowBudget
                      ? 'bg-gradient-to-r from-amber-500 to-rose-400'
                      : 'bg-gradient-to-r from-emerald-500 via-teal-400 to-emerald-300'
                  }`}
                  style={{ width: `${Math.min(100, Math.max(2, spentRatio))}%` }}
                />
              </div>
            </div>
          </div>

          {/* Right Column: Circular Progress Graph */}
          <div className="w-full lg:w-auto flex justify-center py-2 lg:py-0 border-t lg:border-t-0 lg:border-l border-zinc-800/60 lg:pl-8">
            <BudgetCircleGauge
              totalAllowance={config.totalAllowance}
              totalSpent={totalSpent}
              currencySymbol={config.currencySymbol}
              size={180}
              strokeWidth={13}
            />
          </div>
        </div>

        {/* Quick Deduct / Minus Bar */}
        <div className="mt-6 pt-5 border-t border-zinc-800/80">
          <div className="flex items-center justify-between mb-3">
            <label
              htmlFor="quick-minus-amount"
              className="text-xs font-semibold uppercase tracking-wider text-zinc-300 flex items-center gap-1.5"
            >
              <Zap className="w-3.5 h-3.5 text-amber-400 fill-amber-400" />
              <span>Quick Minus from Allowance</span>
            </label>
            <span className="text-[11px] text-zinc-500 hidden sm:inline">
              Instant deduction with enter key
            </span>
          </div>

          <form
            onSubmit={handleQuickSubmit}
            className="flex flex-col sm:flex-row items-stretch sm:items-center gap-2.5"
          >
            {/* Amount input */}
            <div className="relative flex-1 min-w-[130px]">
              <span className="absolute left-3.5 top-1/2 -translate-y-1/2 text-zinc-400 font-mono text-sm">
                {config.currencySymbol}
              </span>
              <input
                id="quick-minus-amount"
                type="number"
                step="0.01"
                min="0.01"
                required
                placeholder="Amount (e.g. 150)"
                value={quickAmount}
                onChange={(e) => setQuickAmount(e.target.value)}
                className="w-full bg-zinc-950 border border-zinc-700/80 rounded-xl pl-8 pr-3 py-2.5 text-zinc-100 placeholder-zinc-500 font-mono text-sm focus:outline-none focus:ring-2 focus:ring-emerald-500/50 focus:border-emerald-500 transition-all"
              />
            </div>

            {/* Note / Title input */}
            <div className="flex-1 min-w-[160px]">
              <input
                type="text"
                placeholder="Description (e.g. Lunch)"
                value={quickTitle}
                onChange={(e) => setQuickTitle(e.target.value)}
                className="w-full bg-zinc-950 border border-zinc-700/80 rounded-xl px-3.5 py-2.5 text-zinc-100 placeholder-zinc-500 text-sm focus:outline-none focus:ring-2 focus:ring-emerald-500/50 focus:border-emerald-500 transition-all"
              />
            </div>

            {/* Category selector */}
            <div className="sm:w-44">
              <select
                value={quickCategory}
                onChange={(e) => setQuickCategory(e.target.value as ExpenseCategory)}
                className="w-full bg-zinc-950 border border-zinc-700/80 rounded-xl px-3 py-2.5 text-zinc-200 text-sm focus:outline-none focus:ring-2 focus:ring-emerald-500/50 focus:border-emerald-500 transition-all"
              >
                {CATEGORIES.map((cat) => (
                  <option key={cat} value={cat} className="bg-zinc-900 text-zinc-100">
                    {cat}
                  </option>
                ))}
              </select>
            </div>

            {/* Minus button */}
            <button
              type="submit"
              className="inline-flex items-center justify-center gap-1.5 px-5 py-2.5 rounded-xl text-sm font-semibold text-zinc-950 bg-emerald-400 hover:bg-emerald-300 transition-all shadow-md shadow-emerald-950/40 active:scale-95"
            >
              <ArrowDownRight className="w-4 h-4 stroke-[2.5]" />
              <span>Minus</span>
            </button>
          </form>

          {/* Quick preset minus chips */}
          <div className="mt-3.5 flex flex-wrap items-center gap-2">
            <span className="text-[11px] text-zinc-500 flex items-center gap-1 mr-1">
              <Sparkles className="w-3 h-3 text-zinc-500" />
              1-Click Minus:
            </span>
            <button
              type="button"
              onClick={() => handleQuickChip(50, 'Coffee / Merienda', 'Food & Dining')}
              className="px-2.5 py-1 rounded-lg text-xs font-medium bg-zinc-800/80 hover:bg-zinc-700 text-zinc-300 border border-zinc-700/60 hover:border-zinc-500 transition-colors"
            >
              -₱50 Merienda
            </button>
            <button
              type="button"
              onClick={() => handleQuickChip(150, 'Value Meal / Lunch', 'Food & Dining')}
              className="px-2.5 py-1 rounded-lg text-xs font-medium bg-zinc-800/80 hover:bg-zinc-700 text-zinc-300 border border-zinc-700/60 hover:border-zinc-500 transition-colors"
            >
              -₱150 Lunch
            </button>
            <button
              type="button"
              onClick={() => handleQuickChip(300, 'Jeep / Grab / Gas', 'Transportation')}
              className="px-2.5 py-1 rounded-lg text-xs font-medium bg-zinc-800/80 hover:bg-zinc-700 text-zinc-300 border border-zinc-700/60 hover:border-zinc-500 transition-colors"
            >
              -₱300 Commute
            </button>
            <button
              type="button"
              onClick={() => handleQuickChip(1000, 'Palengke / Supermarket', 'Groceries')}
              className="px-2.5 py-1 rounded-lg text-xs font-medium bg-zinc-800/80 hover:bg-zinc-700 text-zinc-300 border border-zinc-700/60 hover:border-zinc-500 transition-colors"
            >
              -₱1,000 Grocery
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
