import {
  AllowanceConfig,
  ArchivedBudgetReport,
  Expense,
  ExpenseCategory,
  RecurringSchedule,
  UpcomingOccurrence,
} from '../types/budget';

export const DAY_NAMES = [
  'Sunday',
  'Monday',
  'Tuesday',
  'Wednesday',
  'Thursday',
  'Friday',
  'Saturday',
] as const;

export const CATEGORIES: ExpenseCategory[] = [
  'Food & Dining',
  'Groceries',
  'Transportation',
  'Bills & Utilities',
  'Entertainment',
  'Shopping',
  'Health & Wellness',
  'Personal',
  'Other',
];

export const CATEGORY_COLORS: Record<ExpenseCategory, { bg: string; text: string; border: string; dot: string }> = {
  'Food & Dining': { bg: 'bg-amber-500/10', text: 'text-amber-400', border: 'border-amber-500/20', dot: 'bg-amber-400' },
  'Groceries': { bg: 'bg-emerald-500/10', text: 'text-emerald-400', border: 'border-emerald-500/20', dot: 'bg-emerald-400' },
  'Transportation': { bg: 'bg-sky-500/10', text: 'text-sky-400', border: 'border-sky-500/20', dot: 'bg-sky-400' },
  'Bills & Utilities': { bg: 'bg-red-500/10', text: 'text-red-400', border: 'border-red-500/20', dot: 'bg-red-400' },
  'Entertainment': { bg: 'bg-purple-500/10', text: 'text-purple-400', border: 'border-purple-500/20', dot: 'bg-purple-400' },
  'Shopping': { bg: 'bg-pink-500/10', text: 'text-pink-400', border: 'border-pink-500/20', dot: 'bg-pink-400' },
  'Health & Wellness': { bg: 'bg-teal-500/10', text: 'text-teal-400', border: 'border-teal-500/20', dot: 'bg-teal-400' },
  'Personal': { bg: 'bg-indigo-500/10', text: 'text-indigo-400', border: 'border-indigo-500/20', dot: 'bg-indigo-400' },
  'Other': { bg: 'bg-zinc-500/10', text: 'text-zinc-400', border: 'border-zinc-500/20', dot: 'bg-zinc-400' },
};

/**
 * Format currency with a symbol and 2 decimal places
 */
export const PESO_SYMBOL = '₱';

export function formatCurrency(amount: number, symbol: string = PESO_SYMBOL): string {
  const rounded = Math.round(amount * 100) / 100;
  return `${symbol}${rounded.toLocaleString('en-US', {
    minimumFractionDigits: 2,
    maximumFractionDigits: 2,
  })}`;
}

/**
 * Calculate total expenses spent
 */
export function calculateSpent(expenses: Expense[]): number {
  return expenses.reduce((sum, item) => sum + item.amount, 0);
}

/**
 * Calculate remaining allowance
 */
export function calculateRemainingAllowance(totalAllowance: number, expenses: Expense[]): number {
  const spent = calculateSpent(expenses);
  return totalAllowance - spent;
}

/**
 * Calculate safe to spend balance after reserving for upcoming scheduled commitments
 */
export function calculateSafeToSpend(remainingAllowance: number, upcomingCommitment: number): number {
  return remainingAllowance - upcomingCommitment;
}

/**
 * Calculate days remaining until end date (inclusive)
 */
export function calculateDaysRemaining(endDateStr: string, fromDate: Date = new Date()): number {
  const today = new Date(fromDate.getFullYear(), fromDate.getMonth(), fromDate.getDate());
  const [endYear, endMonth, endDay] = endDateStr.split('-').map(Number);
  const targetEnd = new Date(endYear, endMonth - 1, endDay);
  
  const diffTime = targetEnd.getTime() - today.getTime();
  const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
  return Math.max(1, diffDays + 1); // at least 1 day
}

/**
 * Calculate recommended daily allowance burn rate
 */
export function calculateDailyAllowance(remaining: number, daysRemaining: number): number {
  if (daysRemaining <= 0) return Math.max(0, remaining);
  return Math.max(0, remaining / daysRemaining);
}

/**
 * Format date to YYYY-MM-DD
 */
export function toISODateString(d: Date): string {
  const year = d.getFullYear();
  const month = String(d.getMonth() + 1).padStart(2, '0');
  const day = String(d.getDate()).padStart(2, '0');
  return `${year}-${month}-${day}`;
}

/**
 * Parse YYYY-MM-DD safely into Date (local midnight)
 */
export function parseISODate(dateStr: string): Date {
  const [year, month, day] = dateStr.split('-').map(Number);
  return new Date(year, month - 1, day);
}

/**
 * Selected weekdays for a weekly schedule (sorted, unique, 0 = Sunday).
 * Supports older saved data that only has a single `dayOfWeek`.
 */
export function getScheduleDays(schedule: RecurringSchedule): number[] {
  const raw =
    schedule.daysOfWeek && schedule.daysOfWeek.length > 0
      ? schedule.daysOfWeek
      : schedule.dayOfWeek !== undefined
      ? [schedule.dayOfWeek]
      : [];
  return Array.from(new Set(raw.filter((d) => Number.isInteger(d) && d >= 0 && d <= 6))).sort((a, b) => a - b);
}

/**
 * Human readable label for a set of weekdays, e.g. "Every Friday",
 * "Every Mon, Tue, Wed & Sat", "Every day"
 */
export function formatDaysLabel(days: number[]): string {
  const sorted = Array.from(new Set(days)).sort((a, b) => a - b);
  if (sorted.length === 0) return 'No days selected';
  if (sorted.length === 7) return 'Every day';
  if (sorted.length === 1) return `Every ${DAY_NAMES[sorted[0]]}`;
  const short = sorted.map((d) => DAY_NAMES[d].slice(0, 3));
  return `Every ${short.slice(0, -1).join(', ')} & ${short[short.length - 1]}`;
}

/**
 * Determine readable label for schedule frequency
 */
export function getScheduleFrequencyLabel(schedule: RecurringSchedule): string {
  if (schedule.frequency === 'weekly') {
    const days = getScheduleDays(schedule);
    if (days.length > 0) return formatDaysLabel(days);
  }
  if (schedule.frequency === 'monthly' && schedule.dayOfMonth !== undefined) {
    const day = schedule.dayOfMonth;
    const suffix = day === 1 || day === 21 || day === 31 ? 'st' : day === 2 || day === 22 ? 'nd' : day === 3 || day === 23 ? 'rd' : 'th';
    return `Every month on the ${day}${suffix}`;
  }
  if (schedule.frequency === 'specific_date' && schedule.specificDate) {
    return `On ${schedule.specificDate}`;
  }
  return 'Recurring';
}

/**
 * Get next occurrence date for a recurring schedule
 */
export function getNextOccurrence(schedule: RecurringSchedule, fromDate: Date = new Date()): Date | null {
  const current = new Date(fromDate.getFullYear(), fromDate.getMonth(), fromDate.getDate());
  const todayStr = toISODateString(current);

  if (schedule.frequency === 'weekly') {
    const days = getScheduleDays(schedule);
    if (days.length === 0) return null;
    const currentDay = current.getDay();

    // Find the soonest selected weekday (today counts unless already applied today)
    for (let offset = 0; offset < 7; offset++) {
      const day = (currentDay + offset) % 7;
      if (!days.includes(day)) continue;
      if (offset === 0 && schedule.lastAppliedDate === todayStr) continue;
      return new Date(current.getFullYear(), current.getMonth(), current.getDate() + offset);
    }
    // Only today was selected and it's already applied: next week
    return new Date(current.getFullYear(), current.getMonth(), current.getDate() + 7);
  }

  if (schedule.frequency === 'monthly' && schedule.dayOfMonth !== undefined) {
    const targetDay = schedule.dayOfMonth;
    let nextDate = new Date(current.getFullYear(), current.getMonth(), targetDay);

    // If target day has passed this month (or today and already applied), move to next month
    if (nextDate.getTime() < current.getTime() || (nextDate.getTime() === current.getTime() && schedule.lastAppliedDate === todayStr)) {
      nextDate = new Date(current.getFullYear(), current.getMonth() + 1, targetDay);
    }
    return nextDate;
  }

  if (schedule.frequency === 'specific_date' && schedule.specificDate) {
    const targetDate = parseISODate(schedule.specificDate);
    // If it's already in the past and already applied, no next occurrence
    if (targetDate.getTime() < current.getTime() && schedule.lastAppliedDate) {
      return null;
    }
    return targetDate;
  }

  return null;
}

/**
 * Generate upcoming occurrences for all active schedules within a window
 */
export function getUpcomingOccurrences(
  schedules: RecurringSchedule[],
  fromDate: Date = new Date(),
  daysAhead: number = 30
): UpcomingOccurrence[] {
  const current = new Date(fromDate.getFullYear(), fromDate.getMonth(), fromDate.getDate());
  const limitDate = new Date(current.getTime() + daysAhead * 24 * 60 * 60 * 1000);
  const occurrences: UpcomingOccurrence[] = [];

  for (const schedule of schedules) {
    if (!schedule.isActive) continue;

    if (schedule.frequency === 'weekly') {
      const days = getScheduleDays(schedule);
      if (days.length === 0) continue;
      const todayStr = toISODateString(current);
      const label = formatDaysLabel(days);

      // Walk each day in the window and keep the selected weekdays
      for (let offset = 0; offset <= daysAhead; offset++) {
        const checkDate = new Date(current.getFullYear(), current.getMonth(), current.getDate() + offset);
        if (!days.includes(checkDate.getDay())) continue;
        const dateStr = toISODateString(checkDate);
        if (offset === 0 && schedule.lastAppliedDate === todayStr) continue;

        occurrences.push({
          scheduleId: schedule.id,
          title: schedule.title,
          amount: schedule.amount,
          category: schedule.category,
          date: checkDate,
          dateString: dateStr,
          formattedDate: checkDate.toLocaleDateString('en-US', {
            weekday: 'short',
            month: 'short',
            day: 'numeric',
          }),
          daysAway: offset,
          frequencyLabel: label,
          autoDeduct: schedule.autoDeduct,
        });
      }
    } else if (schedule.frequency === 'monthly' && schedule.dayOfMonth !== undefined) {
      let checkDate = getNextOccurrence(schedule, current);
      while (checkDate && checkDate.getTime() <= limitDate.getTime()) {
        const diffMs = checkDate.getTime() - current.getTime();
        const daysAway = Math.round(diffMs / (1000 * 60 * 60 * 24));
        const dateStr = toISODateString(checkDate);

        occurrences.push({
          scheduleId: schedule.id,
          title: schedule.title,
          amount: schedule.amount,
          category: schedule.category,
          date: new Date(checkDate),
          dateString: dateStr,
          formattedDate: checkDate.toLocaleDateString('en-US', {
            weekday: 'short',
            month: 'short',
            day: 'numeric',
          }),
          daysAway,
          frequencyLabel: `Monthly (${schedule.dayOfMonth}th)`,
          autoDeduct: schedule.autoDeduct,
        });

        // Advance 1 month
        checkDate = new Date(checkDate.getFullYear(), checkDate.getMonth() + 1, schedule.dayOfMonth);
      }
    } else if (schedule.frequency === 'specific_date' && schedule.specificDate) {
      const targetDate = parseISODate(schedule.specificDate);
      if (targetDate.getTime() >= current.getTime() && targetDate.getTime() <= limitDate.getTime()) {
        const diffMs = targetDate.getTime() - current.getTime();
        const daysAway = Math.round(diffMs / (1000 * 60 * 60 * 24));

        occurrences.push({
          scheduleId: schedule.id,
          title: schedule.title,
          amount: schedule.amount,
          category: schedule.category,
          date: targetDate,
          dateString: schedule.specificDate,
          formattedDate: targetDate.toLocaleDateString('en-US', {
            weekday: 'short',
            month: 'short',
            day: 'numeric',
          }),
          daysAway,
          frequencyLabel: `On ${schedule.specificDate}`,
          autoDeduct: schedule.autoDeduct,
        });
      }
    }
  }

  // Sort by date ascending
  return occurrences.sort((a, b) => a.date.getTime() - b.date.getTime());
}

/**
 * Calculate sum of upcoming scheduled expenses within the current allowance cycle
 */
export function calculateCommitmentWithinCycle(
  schedules: RecurringSchedule[],
  config: AllowanceConfig,
  fromDate: Date = new Date()
): number {
  const current = new Date(fromDate.getFullYear(), fromDate.getMonth(), fromDate.getDate());
  const endDate = parseISODate(config.endDate);
  
  if (endDate.getTime() < current.getTime()) return 0;
  
  const diffDays = Math.ceil((endDate.getTime() - current.getTime()) / (1000 * 60 * 60 * 24));
  const occurrences = getUpcomingOccurrences(schedules, current, Math.max(1, diffDays));
  
  return occurrences
    .filter(occ => occ.date.getTime() <= endDate.getTime())
    .reduce((sum, occ) => sum + occ.amount, 0);
}

/**
 * Category breakdown summary
 */
export function calculateCategoryBreakdown(expenses: Expense[]): Array<{
  category: ExpenseCategory;
  amount: number;
  percentage: number;
  count: number;
}> {
  const total = calculateSpent(expenses);
  const map = new Map<ExpenseCategory, { amount: number; count: number }>();

  for (const exp of expenses) {
    const existing = map.get(exp.category) || { amount: 0, count: 0 };
    map.set(exp.category, {
      amount: existing.amount + exp.amount,
      count: existing.count + 1,
    });
  }

  const result: Array<{
    category: ExpenseCategory;
    amount: number;
    percentage: number;
    count: number;
  }> = [];

  for (const [category, data] of map.entries()) {
    result.push({
      category,
      amount: data.amount,
      percentage: total > 0 ? (data.amount / total) * 100 : 0,
      count: data.count,
    });
  }

  return result.sort((a, b) => b.amount - a.amount);
}

/**
 * Creates an archived snapshot report of the budget before resetting
 */
export function createArchiveSnapshot(
  config: AllowanceConfig,
  expenses: Expense[],
  note?: string
): ArchivedBudgetReport {
  const totalSpent = calculateSpent(expenses);
  const remainingBalance = calculateRemainingAllowance(config.totalAllowance, expenses);
  const spentPercentage = config.totalAllowance > 0
    ? Math.round((totalSpent / config.totalAllowance) * 1000) / 10
    : 0;

  return {
    id: `archive-${Date.now()}`,
    cycleName: config.cycleName || `${config.startDate} to ${config.endDate}`,
    startDate: config.startDate,
    endDate: config.endDate,
    archivedAt: new Date().toISOString(),
    currencySymbol: config.currencySymbol,
    totalAllowance: config.totalAllowance,
    totalSpent,
    remainingBalance,
    spentPercentage,
    expenses: [...expenses],
    note,
  };
}

