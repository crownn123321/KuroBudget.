import test from 'node:test';
import assert from 'node:assert/strict';
import {
  calculateRemainingAllowance,
  calculateSpent,
  calculateSafeToSpend,
  getNextOccurrence,
  getScheduleDays,
  getScheduleFrequencyLabel,
  getUpcomingOccurrences,
  calculateDaysRemaining,
  calculateDailyAllowance,
  formatCurrency,
  toISODateString,
  calculateCategoryBreakdown,
  createArchiveSnapshot,
} from './budgetCalculations';
import { Expense, RecurringSchedule } from '../types/budget';

test('calculateSpent sums all expense amounts correctly', () => {
  const expenses: Expense[] = [
    { id: '1', title: 'Coffee', amount: 5.5, category: 'Food & Dining', date: '2026-11-01' },
    { id: '2', title: 'Groceries', amount: 44.5, category: 'Groceries', date: '2026-11-02' },
    { id: '3', title: 'Metro', amount: 10, category: 'Transportation', date: '2026-11-03' },
  ];
  assert.equal(calculateSpent(expenses), 60);
});

test('calculateRemainingAllowance subtracts expenses from total allowance', () => {
  const allowance = 500;
  const expenses: Expense[] = [
    { id: '1', title: 'Dinner', amount: 45, category: 'Food & Dining', date: '2026-11-01' },
    { id: '2', title: 'Train', amount: 25, category: 'Transportation', date: '2026-11-02' },
  ];
  const remaining = calculateRemainingAllowance(allowance, expenses);
  assert.equal(remaining, 430);
});

test('calculateSafeToSpend reserves scheduled expenses from allowance', () => {
  const remainingAllowance = 430;
  const scheduledCommitments = 130; // e.g. upcoming Friday dinner and Tuesday bills
  const safe = calculateSafeToSpend(remainingAllowance, scheduledCommitments);
  assert.equal(safe, 300);
});

test('getNextOccurrence handles "Every Friday" (dayOfWeek = 5)', () => {
  const fridaySchedule: RecurringSchedule = {
    id: 'rec-1',
    title: 'Friday Movie & Dining',
    amount: 50,
    category: 'Entertainment',
    frequency: 'weekly',
    dayOfWeek: 5, // Friday
    autoDeduct: true,
    isActive: true,
    createdAt: '2026-11-01',
  };

  // Suppose today is Wednesday, Nov 4, 2026 (day 3)
  const wednesday = new Date(2026, 10, 4); // Month is 0-indexed: 10 = Nov
  assert.equal(wednesday.getDay(), 3); // Wednesday

  const nextDate = getNextOccurrence(fridaySchedule, wednesday);
  assert.notEqual(nextDate, null);
  // Next Friday is Nov 6, 2026
  assert.equal(nextDate?.getDay(), 5);
  assert.equal(toISODateString(nextDate!), '2026-11-06');
});

test('getNextOccurrence handles "Every Tuesday" (dayOfWeek = 2)', () => {
  const tuesdaySchedule: RecurringSchedule = {
    id: 'rec-2',
    title: 'Tuesday Commute Pass',
    amount: 20,
    category: 'Transportation',
    frequency: 'weekly',
    dayOfWeek: 2, // Tuesday
    autoDeduct: true,
    isActive: true,
    createdAt: '2026-11-01',
  };

  // Suppose today is Friday, Nov 6, 2026 (day 5)
  const friday = new Date(2026, 10, 6);
  assert.equal(friday.getDay(), 5);

  const nextDate = getNextOccurrence(tuesdaySchedule, friday);
  assert.notEqual(nextDate, null);
  // Next Tuesday is Nov 10, 2026
  assert.equal(nextDate?.getDay(), 2);
  assert.equal(toISODateString(nextDate!), '2026-11-10');
});

test('getNextOccurrence pushes to next week if today is Friday and already applied', () => {
  const fridaySchedule: RecurringSchedule = {
    id: 'rec-1',
    title: 'Friday Pizza',
    amount: 30,
    category: 'Food & Dining',
    frequency: 'weekly',
    dayOfWeek: 5,
    autoDeduct: true,
    isActive: true,
    lastAppliedDate: '2026-11-06', // already applied today!
    createdAt: '2026-11-01',
  };

  const todayFriday = new Date(2026, 10, 6);
  const nextDate = getNextOccurrence(fridaySchedule, todayFriday);
  assert.notEqual(nextDate, null);
  assert.equal(toISODateString(nextDate!), '2026-11-13'); // next Friday
});

test('getUpcomingOccurrences correctly returns multiple upcoming occurrences within 14 days', () => {
  const schedules: RecurringSchedule[] = [
    {
      id: 'rec-fri',
      title: 'Friday Outing',
      amount: 40,
      category: 'Entertainment',
      frequency: 'weekly',
      dayOfWeek: 5,
      autoDeduct: true,
      isActive: true,
      createdAt: '2026-11-01',
    },
    {
      id: 'rec-tue',
      title: 'Tuesday Fuel',
      amount: 35,
      category: 'Transportation',
      frequency: 'weekly',
      dayOfWeek: 2,
      autoDeduct: true,
      isActive: true,
      createdAt: '2026-11-01',
    },
  ];

  // From Sunday Nov 1, 2026
  const startSunday = new Date(2026, 10, 1);
  const upcoming = getUpcomingOccurrences(schedules, startSunday, 14);

  // Expect:
  // Nov 3 (Tue)
  // Nov 6 (Fri)
  // Nov 10 (Tue)
  // Nov 13 (Fri)
  assert.equal(upcoming.length, 4);
  assert.equal(upcoming[0].title, 'Tuesday Fuel');
  assert.equal(upcoming[0].dateString, '2026-11-03');
  assert.equal(upcoming[1].title, 'Friday Outing');
  assert.equal(upcoming[1].dateString, '2026-11-06');
});

test('calculateDailyAllowance splits remaining allowance across remaining days', () => {
  assert.equal(calculateDailyAllowance(300, 10), 30);
  assert.equal(calculateDailyAllowance(100, 4), 25);
  assert.equal(calculateDailyAllowance(0, 5), 0);
});

test('calculateCategoryBreakdown computes percentages and sorting', () => {
  const expenses: Expense[] = [
    { id: '1', title: 'Supermarket', amount: 150, category: 'Groceries', date: '2026-11-01' },
    { id: '2', title: 'Steakhouse', amount: 50, category: 'Food & Dining', date: '2026-11-02' },
  ];
  const breakdown = calculateCategoryBreakdown(expenses);
  assert.equal(breakdown[0].category, 'Groceries');
  assert.equal(breakdown[0].amount, 150);
  assert.equal(breakdown[0].percentage, 75);
  assert.equal(breakdown[1].category, 'Food & Dining');
  assert.equal(breakdown[1].amount, 50);
  assert.equal(breakdown[1].percentage, 25);
});

test('formatCurrency outputs expected formatted strings including Philippine Peso', () => {
  assert.equal(formatCurrency(1250.5), '₱1,250.50'); // peso is the default
  assert.equal(formatCurrency(0), '₱0.00');
  assert.equal(formatCurrency(25000, '₱'), '₱25,000.00');
  assert.equal(formatCurrency(150.75, '₱'), '₱150.75');
});

test('budget used percentage calculates correctly for circle graph', () => {
  const totalAllowance = 20000;
  const spent = 5000;
  const usedRatio = (spent / totalAllowance) * 100;
  assert.equal(usedRatio, 25);
  const remainingRatio = 100 - usedRatio;
  assert.equal(remainingRatio, 75);
});

test('createArchiveSnapshot correctly packages allowance report for historical archive', () => {
  const config = {
    totalAllowance: 1000,
    periodType: 'monthly' as const,
    startDate: '2026-11-01',
    endDate: '2026-11-30',
    currencySymbol: '₱',
    cycleName: 'November Budget',
  };
  const expenses: Expense[] = [
    { id: '1', title: 'Groceries', amount: 250, category: 'Groceries', date: '2026-11-02' },
    { id: '2', title: 'Transport', amount: 50, category: 'Transportation', date: '2026-11-03' },
  ];
  const snapshot = createArchiveSnapshot(config, expenses, 'End of month reset');
  assert.equal(snapshot.cycleName, 'November Budget');
  assert.equal(snapshot.totalAllowance, 1000);
  assert.equal(snapshot.totalSpent, 300);
  assert.equal(snapshot.remainingBalance, 700);
  assert.equal(snapshot.spentPercentage, 30);
  assert.equal(snapshot.expenses.length, 2);
  assert.equal(snapshot.note, 'End of month reset');
});



test('weekly schedule supports multiple days: Mon, Tue, Wed & Sat on one expense', () => {
  const multi: RecurringSchedule = {
    id: 'rec-multi',
    title: 'Commute Fare',
    amount: 120,
    category: 'Transportation',
    frequency: 'weekly',
    daysOfWeek: [6, 1, 3, 2], // intentionally unsorted
    autoDeduct: true,
    isActive: true,
    createdAt: '2026-11-01',
  };

  assert.deepEqual(getScheduleDays(multi), [1, 2, 3, 6]);
  assert.equal(getScheduleFrequencyLabel(multi), 'Every Mon, Tue, Wed & Sat');

  // From Sunday Nov 1, 2026 -> next is Monday Nov 2
  const sunday = new Date(2026, 10, 1);
  assert.equal(toISODateString(getNextOccurrence(multi, sunday)!), '2026-11-02');

  // From Thursday Nov 5 -> next is Saturday Nov 7
  const thursday = new Date(2026, 10, 5);
  assert.equal(toISODateString(getNextOccurrence(multi, thursday)!), '2026-11-07');

  // 8-day window from Sunday Nov 1 (Nov 1..9): Mon 2, Tue 3, Wed 4, Sat 7, Mon 9
  const upcoming = getUpcomingOccurrences([multi], sunday, 8);
  assert.deepEqual(
    upcoming.map((o) => o.dateString),
    ['2026-11-02', '2026-11-03', '2026-11-04', '2026-11-07', '2026-11-09']
  );
});

test('multi-day schedule skips today once already applied but keeps later days', () => {
  const multi: RecurringSchedule = {
    id: 'rec-multi-2',
    title: 'Commute Fare',
    amount: 120,
    category: 'Transportation',
    frequency: 'weekly',
    daysOfWeek: [1, 2, 3, 6],
    autoDeduct: true,
    isActive: true,
    lastAppliedDate: '2026-11-03', // Tuesday already deducted
    createdAt: '2026-11-01',
  };
  const tuesday = new Date(2026, 10, 3);
  assert.equal(toISODateString(getNextOccurrence(multi, tuesday)!), '2026-11-04'); // Wednesday
});

test('legacy single dayOfWeek schedules still work', () => {
  const legacy: RecurringSchedule = {
    id: 'rec-legacy',
    title: 'Old Friday',
    amount: 50,
    category: 'Entertainment',
    frequency: 'weekly',
    dayOfWeek: 5,
    autoDeduct: true,
    isActive: true,
    createdAt: '2026-11-01',
  };
  assert.deepEqual(getScheduleDays(legacy), [5]);
  assert.equal(getScheduleFrequencyLabel(legacy), 'Every Friday');
});
