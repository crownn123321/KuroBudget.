import { AllowanceConfig, Expense, RecurringSchedule } from '../types/budget';
import { PESO_SYMBOL, getScheduleDays, toISODateString } from './budgetCalculations';

const STORAGE_KEYS = {
  CONFIG: 'tipid_tipid_ta_config_v1',
  EXPENSES: 'tipid_tipid_ta_expenses_v1',
  SCHEDULES: 'tipid_tipid_ta_schedules_v1',
  ARCHIVES: 'tipid_tipid_ta_archives_v1',
  OLD_CONFIG: 'kuro_budget_config_v1',
  OLD_EXPENSES: 'kuro_budget_expenses_v1',
  OLD_SCHEDULES: 'kuro_budget_schedules_v1',
  OLD_ARCHIVES: 'way_money_budget_archives_v1',
};

export function getDefaultConfig(): AllowanceConfig {
  const now = new Date();
  const year = now.getFullYear();
  const month = now.getMonth();
  
  // Default to current calendar month
  const startDate = new Date(year, month, 1);
  const lastDay = new Date(year, month + 1, 0);

  return {
    totalAllowance: 5000,
    periodType: 'monthly',
    startDate: toISODateString(startDate),
    endDate: toISODateString(lastDay),
    currencySymbol: PESO_SYMBOL,
    cycleName: `${now.toLocaleString('default', { month: 'long' })} Allowance`,
  };
}

export function getDefaultSchedules(): RecurringSchedule[] {
  const now = new Date();
  const year = now.getFullYear();
  const month = now.getMonth();

  // Create scheduled expenses, including "Every Friday" and "Every Tuesday"
  return [
    {
      id: 'sched-1',
      title: 'Friday Dining & Outing',
      amount: 250,
      category: 'Food & Dining',
      frequency: 'weekly',
      daysOfWeek: [5], // Friday
      autoDeduct: true,
      isActive: true,
      note: 'Weekly dinner or drinks with friends',
      createdAt: new Date(year, month, 1).toISOString(),
    },
    {
      id: 'sched-2',
      title: 'Commute Fare (Mon, Tue, Wed & Sat)',
      amount: 120,
      category: 'Transportation',
      frequency: 'weekly',
      daysOfWeek: [1, 2, 3, 6], // Mon, Tue, Wed & Sat
      autoDeduct: true,
      isActive: true,
      note: 'Daily jeep/bus fare on commute days',
      createdAt: new Date(year, month, 1).toISOString(),
    },
    {
      id: 'sched-3',
      title: 'Streaming & Cloud Services',
      amount: 500,
      category: 'Bills & Utilities',
      frequency: 'monthly',
      dayOfMonth: 15,
      autoDeduct: true,
      isActive: true,
      note: 'Spotify, Netflix & iCloud',
      createdAt: new Date(year, month, 1).toISOString(),
    },
    {
      id: 'sched-4',
      title: 'Weekend Palengke',
      amount: 400,
      category: 'Groceries',
      frequency: 'weekly',
      daysOfWeek: [6], // Saturday
      autoDeduct: false,
      isActive: true,
      note: 'Fresh produce and weekly groceries',
      createdAt: new Date(year, month, 1).toISOString(),
    },
  ];
}

export function getDefaultExpenses(): Expense[] {
  const now = new Date();
  const year = now.getFullYear();
  const month = now.getMonth();
  const day = now.getDate();

  return [
    {
      id: 'exp-1',
      title: 'Artisan Coffee & Croissant',
      amount: 150,
      category: 'Food & Dining',
      date: new Date(year, month, Math.max(1, day - 2), 9, 30).toISOString(),
      note: 'Morning espresso',
    },
    {
      id: 'exp-2',
      title: 'Weekly Supermarket Haul',
      amount: 1500,
      category: 'Groceries',
      date: new Date(year, month, Math.max(1, day - 3), 17, 15).toISOString(),
      note: 'Pantry essentials and fruit',
    },
    {
      id: 'exp-3',
      title: 'Subway Multi-Pass',
      amount: 100,
      category: 'Transportation',
      date: new Date(year, month, Math.max(1, day - 4), 8, 45).toISOString(),
    },
    {
      id: 'exp-4',
      title: 'Cinema Ticket',
      amount: 350,
      category: 'Entertainment',
      date: new Date(year, month, Math.max(1, day - 5), 20, 0).toISOString(),
      note: 'Weekend evening screening',
    },
  ];
}

export function loadConfig(): AllowanceConfig {
  try {
    const raw = localStorage.getItem(STORAGE_KEYS.CONFIG) || localStorage.getItem(STORAGE_KEYS.OLD_CONFIG);
    if (!raw) return getDefaultConfig();
    // Philippine Peso is the only supported currency
    return { ...JSON.parse(raw), currencySymbol: PESO_SYMBOL };
  } catch {
    return getDefaultConfig();
  }
}

export function saveConfig(config: AllowanceConfig): void {
  try {
    localStorage.setItem(STORAGE_KEYS.CONFIG, JSON.stringify(config));
  } catch (err) {
    console.error('Failed to save allowance config:', err);
  }
}

export function loadExpenses(): Expense[] {
  try {
    const raw = localStorage.getItem(STORAGE_KEYS.EXPENSES) || localStorage.getItem(STORAGE_KEYS.OLD_EXPENSES);
    if (!raw) return getDefaultExpenses();
    return JSON.parse(raw);
  } catch {
    return getDefaultExpenses();
  }
}

export function saveExpenses(expenses: Expense[]): void {
  try {
    localStorage.setItem(STORAGE_KEYS.EXPENSES, JSON.stringify(expenses));
  } catch (err) {
    console.error('Failed to save expenses:', err);
  }
}

export function loadSchedules(): RecurringSchedule[] {
  try {
    const raw = localStorage.getItem(STORAGE_KEYS.SCHEDULES) || localStorage.getItem(STORAGE_KEYS.OLD_SCHEDULES);
    if (!raw) return getDefaultSchedules();
    const parsed: RecurringSchedule[] = JSON.parse(raw);
    // Upgrade older single-day schedules to the multi-day format
    return parsed.map((sch) => {
      if (sch.frequency !== 'weekly') return sch;
      const { dayOfWeek: _legacy, ...rest } = sch;
      return { ...rest, daysOfWeek: getScheduleDays(sch) };
    });
  } catch {
    return getDefaultSchedules();
  }
}

export function saveSchedules(schedules: RecurringSchedule[]): void {
  try {
    localStorage.setItem(STORAGE_KEYS.SCHEDULES, JSON.stringify(schedules));
  } catch (err) {
    console.error('Failed to save schedules:', err);
  }
}

export function loadArchivedReports(): import('../types/budget').ArchivedBudgetReport[] {
  try {
    const raw = localStorage.getItem(STORAGE_KEYS.ARCHIVES) || localStorage.getItem(STORAGE_KEYS.OLD_ARCHIVES);
    if (!raw) return [];
    const parsed: import('../types/budget').ArchivedBudgetReport[] = JSON.parse(raw);
    return parsed.map((r) => ({ ...r, currencySymbol: PESO_SYMBOL }));
  } catch {
    return [];
  }
}

export function saveArchivedReports(reports: import('../types/budget').ArchivedBudgetReport[]): void {
  try {
    localStorage.setItem(STORAGE_KEYS.ARCHIVES, JSON.stringify(reports));
  } catch (err) {
    console.error('Failed to save archived reports:', err);
  }
}

