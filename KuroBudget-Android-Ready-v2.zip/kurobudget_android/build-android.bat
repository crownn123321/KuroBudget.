@echo off
setlocal
cd /d "%~dp0"

where npm >nul 2>nul || (echo Node.js and npm are required.& exit /b 1)
if not exist node_modules call npm install || exit /b 1
if not exist android call npm run android:init || exit /b 1
call npm run android:sync || exit /b 1
cd android
call gradlew.bat assembleDebug || exit /b 1
echo.
echo Debug APK: %CD%\app\build\outputs\apk\debug\app-debug.apk
endlocal
