#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"

if ! command -v npm >/dev/null 2>&1; then
  echo "Node.js and npm are required." >&2
  exit 1
fi

if [ ! -d node_modules ]; then
  npm install
fi

if [ ! -d android ]; then
  npm run android:init
fi

npm run android:sync
( cd android && ./gradlew assembleDebug )
printf '\nDebug APK: %s/android/app/build/outputs/apk/debug/app-debug.apk\n' "$PWD"
