# KuroBudget — Android + Web

A dark allowance and expense tracker built with React, TypeScript, Vite, and Capacitor. The Android app packages the same local-first interface in a native Android WebView container. Budgets, expenses, recurring schedules, and archives remain on the device using WebView `localStorage`.

## Requirements

- Node.js 22.12+ (the project uses Vite 8)
- Android Studio 2024.2.1 or newer, with the Android SDK installed
- JDK 21 (use the Gradle JDK configured by Android Studio)
- Android SDK Platform 35 or the platform required by the installed Capacitor 7 Android template

## First Android build

Run these commands from the project root:

```bash
npm install
npm run android:init
npm run android:sync
npm run android:open
```

In Android Studio, wait for Gradle sync to finish, then select **Build → Build Bundle(s) / APK(s) → Build APK(s)**. The debug APK is written to:

```text
android/app/build/outputs/apk/debug/app-debug.apk
```

Copy that APK to the Android phone and install it. On the phone, allow installation from the file manager/browser when Android asks. A debug APK is suitable for private testing; create a signed release build before public distribution.

For a one-command debug build after Android Studio and the SDK are installed, run `build-android.bat` on Windows or `./build-android.sh` on macOS/Linux. These scripts install npm dependencies if needed, create/sync the Android project, generate app icons, and run Gradle's debug APK task.

## Rebuilding after code changes

```bash
npm run android:sync
npm run android:open
```

Then build the APK again in Android Studio. `npm run build:android` builds the web assets in Capacitor mode and deliberately skips PWA service-worker generation inside the native package. The normal `npm run build` keeps PWA support for web deployment.

## Web/PWA development

```bash
npm install
npm run dev
```

## Checks

```bash
npm run lint
npm test
```

## Android compatibility notes

- CSV exports use the Android share sheet in the native app; browser downloads remain enabled on the web build.
- Android system Back closes the active dialog first, then exits the app when no dialog is open.
- Native launcher icons and splash assets are generated from the included `assets/` artwork during `android:init` and `android:sync`.
- Date/time inputs initialize using the phone's local timezone.
- The web build continues to include the PWA manifest and service worker; the APK build does not need a service worker because its web assets are packaged locally.
- All budget data is local to the installed app. Uninstalling the app or clearing its app data can remove that data; export reports regularly for backups.

## Project identity

- App label: `KuroBudget`
- Android application ID: `com.kurobudget.allowancetracker`
- Web asset directory: `dist`
