export type ExpenseCategory =
  | 'Food & Dining'
  | 'Groceries'
  | 'Transportation'
  | 'Bills & Utilities'
  | 'Entertainment'
  | 'Shopping'
  | 'Health & Wellness'
  | 'Personal'
  | 'Other';

export interface Expense {
  id: string;
  title: string;
  amount: number;
  category: ExpenseCategory;
  date: string; // ISO string YYYY-MM-DDTHH:mm:ss
  note?: string;
  scheduledId?: string; // Set if created from a scheduled rule
}

export type RecurringFrequency = 'weekly' | 'monthly' | 'specific_date';

export interface RecurringSchedule {
  id: string;
  title: string;
  amount: number;
  category: ExpenseCategory;
  frequency: RecurringFrequency;
  dayOfWeek?: number; // 0 = Sunday, 1 = Monday, 2 = Tuesday, 3 = Wednesday, 4 = Thursday, 5 = Friday, 6 = Saturday
  dayOfMonth?: number; // 1 - 31
  specificDate?: string; // YYYY-MM-DD
  autoDeduct: boolean; // Automatically deduct from allowance when date arrives
  isActive: boolean;
  lastAppliedDate?: string; // YYYY-MM-DD of last execution
  note?: string;
  createdAt: string;
}

export type PeriodType = 'weekly' | 'biweekly' | 'monthly' | 'custom';

export interface AllowanceConfig {
  totalAllowance: number;
  periodType: PeriodType;
  startDate: string; // YYYY-MM-DD
  endDate: string; // YYYY-MM-DD
  currencySymbol: string; // '$', '€', '£', etc.
  cycleName?: string;
}

export interface UpcomingOccurrence {
  scheduleId: string;
  title: string;
  amount: number;
  category: ExpenseCategory;
  date: Date;
  dateString: string; // YYYY-MM-DD
  formattedDate: string; // e.g. "Friday, Nov 13"
  daysAway: number; // 0 = Today, 1 = Tomorrow, etc.
  frequencyLabel: string; // e.g. "Every Friday", "Nov 20, 2026"
  autoDeduct: boolean;
}

export interface ArchivedBudgetReport {
  id: string;
  cycleName: string;
  startDate: string;
  endDate: string;
  archivedAt: string;
  currencySymbol: string;
  totalAllowance: number;
  totalSpent: number;
  remainingBalance: number;
  spentPercentage: number;
  expenses: Expense[];
  note?: string;
}

