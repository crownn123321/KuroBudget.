import React, { useState } from 'react';
import {
  X,
  Archive,
  Calendar,
  ChevronDown,
  ChevronUp,
  Download,
  Trash2,
  TrendingDown,
  PiggyBank,
  Receipt,
  Clock,
} from 'lucide-react';
import { ArchivedBudgetReport } from '../types/budget';
import {
  formatCurrency,
  CATEGORY_COLORS,
  calculateCategoryBreakdown,
} from '../utils/budgetCalculations';
import { escapeCsvCell, exportCsvFile } from '../utils/exportCsv';

interface ArchivedReportsModalProps {
  isOpen: boolean;
  onClose: () => void;
  archives: ArchivedBudgetReport[];
  onDeleteArchive: (id: string) => void;
}

export const ArchivedReportsModal: React.FC<ArchivedReportsModalProps> = ({
  isOpen,
  onClose,
  archives,
  onDeleteArchive,
}) => {
  const [expandedId, setExpandedId] = useState<string | null>(null);

  if (!isOpen) return null;

  const toggleExpand = (id: string) => {
    setExpandedId((curr) => (curr === id ? null : id));
  };

  const handleExportArchiveCSV = async (report: ArchivedBudgetReport) => {
    const headers = ['Date', 'Title', 'Category', 'Amount', 'Note'];
    const expenseRows = report.expenses.map((exp) => [
      exp.date,
      exp.title,
      exp.category,
      exp.amount.toFixed(2),
      exp.note || '',
    ]);
    const summaryRows = [
      [''],
      ['Cycle Summary', report.cycleName],
      ['Total Allowance', report.totalAllowance.toFixed(2)],
      ['Total Spent', report.totalSpent.toFixed(2)],
      ['Remaining Balance', report.remainingBalance.toFixed(2)],
      ['Budget Used %', `${report.spentPercentage}%`],
    ];
    const csvContent = [headers, ...expenseRows, ...summaryRows]
      .map((row) => row.map(escapeCsvCell).join(','))
      .join('\r\n');
    const safeCycleName = report.cycleName.toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/^-|-$/g, '');

    try {
      await exportCsvFile(
        `kurobudget-report-${safeCycleName || 'archive'}.csv`,
        csvContent,
        `KuroBudget - ${report.cycleName}`
      );
    } catch (error) {
      console.error('Failed to export archived report CSV:', error);
      window.alert('Unable to export the CSV file. Please try again.');
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-zinc-950/85 backdrop-blur-md animate-fade-in">
      <div className="relative w-full max-w-2xl rounded-3xl bg-zinc-900 border border-zinc-800 p-4 sm:p-7 shadow-2xl max-h-[90dvh] overflow-y-auto overscroll-contain">
        {/* Close Button */}
        <button
          onClick={onClose}
          aria-label="Close archived reports dialog"
          className="absolute right-4 top-4 p-2 text-zinc-400 hover:text-zinc-100 hover:bg-zinc-800 rounded-xl transition-colors"
        >
          <X className="w-5 h-5" />
        </button>

        <div className="flex items-center gap-3 mb-6">
          <div className="w-11 h-11 rounded-2xl bg-amber-500/10 border border-amber-500/20 flex items-center justify-center text-amber-400 shrink-0">
            <Archive className="w-6 h-6" />
          </div>
          <div>
            <h3 className="text-lg font-bold text-zinc-100 flex items-center gap-2">
              <span>Past Budget Reports</span>
              <span className="text-xs font-semibold px-2 py-0.5 rounded-full bg-zinc-800 text-zinc-300">
                {archives.length} archived
              </span>
            </h3>
            <p className="text-xs text-zinc-400">
              Historical allowance reports saved each time you reset for a new budget cycle
            </p>
          </div>
        </div>

        {archives.length === 0 ? (
          <div className="text-center py-12 px-4 rounded-2xl border border-dashed border-zinc-800 bg-zinc-950/40">
            <Archive className="w-10 h-10 text-zinc-600 mx-auto mb-3" />
            <h4 className="text-sm font-semibold text-zinc-300">No archived budget reports yet</h4>
            <p className="text-xs text-zinc-500 mt-1.5 max-w-sm mx-auto">
              When your current allowance cycle ends, tap <strong>"Reset Budget &amp; Archive"</strong> in Settings.
              Your full report, circular gauge stats, and transactions will be archived here.
            </p>
          </div>
        ) : (
          <div className="space-y-4">
            {archives.map((report) => {
              const isExpanded = expandedId === report.id;
              const breakdown = calculateCategoryBreakdown(report.expenses);
              const formattedArchiveDate = new Date(report.archivedAt).toLocaleDateString('en-US', {
                month: 'short',
                day: 'numeric',
                year: 'numeric',
              });

              return (
                <div
                  key={report.id}
                  className="rounded-2xl bg-zinc-950 border border-zinc-800/90 overflow-hidden transition-all"
                >
                  {/* Card Header / Summary */}
                  <div className="p-4 sm:p-5">
                    <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                      <div>
                        <div className="flex items-center gap-2">
                          <h4 className="font-bold text-zinc-100 text-base">
                            {report.cycleName}
                          </h4>
                          <span className="text-[10px] px-2 py-0.5 rounded-md font-mono bg-zinc-800 text-zinc-400">
                            {report.spentPercentage}% used
                          </span>
                        </div>
                        <div className="flex items-center gap-2 mt-1 text-xs text-zinc-400">
                          <span className="flex items-center gap-1">
                            <Calendar className="w-3.5 h-3.5 text-zinc-500" />
                            {report.startDate} &rarr; {report.endDate}
                          </span>
                          <span className="text-zinc-600">&bull;</span>
                          <span className="text-zinc-500 text-[11px]">
                            Archived on {formattedArchiveDate}
                          </span>
                        </div>
                      </div>

                      {/* Right: Quick Numbers */}
                      <div className="flex items-center justify-between sm:justify-end gap-4 pt-2 sm:pt-0 border-t sm:border-t-0 border-zinc-800/60">
                        <div className="text-left sm:text-right">
                          <div className="text-xs text-zinc-400">Allowance / Spent</div>
                          <div className="font-mono font-bold text-sm text-zinc-200">
                            {formatCurrency(report.totalAllowance, report.currencySymbol)}
                            <span className="text-zinc-500 text-xs font-normal"> / </span>
                            <span className="text-rose-400">
                              {formatCurrency(report.totalSpent, report.currencySymbol)}
                            </span>
                          </div>
                        </div>

                        <div className="flex items-center gap-1.5">
                          <button
                            type="button"
                            onClick={() => toggleExpand(report.id)}
                            className="p-2 rounded-xl text-zinc-400 hover:text-zinc-100 hover:bg-zinc-800 border border-zinc-800 transition-colors"
                            title={isExpanded ? 'Collapse report' : 'Expand full report'}
                            aria-label={isExpanded ? 'Collapse report' : 'Expand full report'}
                          >
                            {isExpanded ? (
                              <ChevronUp className="w-4 h-4" />
                            ) : (
                              <ChevronDown className="w-4 h-4" />
                            )}
                          </button>
                          <button
                            type="button"
                            onClick={() => onDeleteArchive(report.id)}
                            className="p-2 rounded-xl text-zinc-500 hover:text-rose-400 hover:bg-rose-950/20 border border-zinc-800 transition-colors"
                            title="Delete this archived report"
                            aria-label="Delete archived report"
                          >
                            <Trash2 className="w-4 h-4" />
                          </button>
                        </div>
                      </div>
                    </div>

                    {/* Progress Bar for the cycle */}
                    <div className="mt-4 space-y-1.5">
                      <div className="h-2 w-full bg-zinc-900 rounded-full overflow-hidden border border-zinc-800">
                        <div
                          className={`h-full rounded-full ${
                            report.spentPercentage > 100
                              ? 'bg-rose-500'
                              : report.spentPercentage >= 80
                              ? 'bg-amber-400'
                              : 'bg-emerald-400'
                          }`}
                          style={{ width: `${Math.min(100, Math.max(2, report.spentPercentage))}%` }}
                        />
                      </div>
                      <div className="flex justify-between text-[11px] text-zinc-500 font-mono">
                        <span>Spent: {formatCurrency(report.totalSpent, report.currencySymbol)}</span>
                        <span>
                          Remaining:{' '}
                          <strong
                            className={
                              report.remainingBalance >= 0 ? 'text-emerald-400' : 'text-rose-400'
                            }
                          >
                            {formatCurrency(report.remainingBalance, report.currencySymbol)}
                          </strong>
                        </span>
                      </div>
                    </div>
                  </div>

                  {/* Expanded Report Details */}
                  {isExpanded && (
                    <div className="p-4 sm:p-5 border-t border-zinc-800/80 bg-zinc-900/40 space-y-5">
                      {/* Category Breakdown */}
                      <div>
                        <h5 className="text-xs font-semibold uppercase tracking-wider text-zinc-400 mb-2.5">
                          Category Breakdown
                        </h5>
                        <div className="space-y-2">
                          {breakdown.map((item) => {
                            const color = CATEGORY_COLORS[item.category];
                            return (
                              <div key={item.category} className="space-y-1">
                                <div className="flex items-center justify-between text-xs">
                                  <span className="text-zinc-300 font-medium">{item.category}</span>
                                  <span className="font-mono text-zinc-200">
                                    {formatCurrency(item.amount, report.currencySymbol)} (
                                    {item.percentage.toFixed(1)}%)
                                  </span>
                                </div>
                                <div className="h-1.5 w-full bg-zinc-950 rounded-full overflow-hidden">
                                  <div
                                    className={`h-full rounded-full ${color ? color.dot : 'bg-zinc-400'}`}
                                    style={{ width: `${Math.min(100, Math.max(1, item.percentage))}%` }}
                                  />
                                </div>
                              </div>
                            );
                          })}
                        </div>
                      </div>

                      {/* Transactions in this archived cycle */}
                      <div>
                        <div className="flex items-center justify-between mb-2">
                          <h5 className="text-xs font-semibold uppercase tracking-wider text-zinc-400">
                            Transactions ({report.expenses.length})
                          </h5>
                          <button
                            type="button"
                            onClick={() => handleExportArchiveCSV(report)}
                            className="inline-flex items-center gap-1 text-[11px] font-semibold text-sky-400 hover:text-sky-300"
                          >
                            <Download className="w-3 h-3" />
                            <span>Export Cycle CSV</span>
                          </button>
                        </div>

                        <div className="max-h-48 overflow-y-auto space-y-1.5 pr-1">
                          {report.expenses.map((exp) => (
                            <div
                              key={exp.id}
                              className="flex items-center justify-between p-2 rounded-xl bg-zinc-950/80 border border-zinc-800/60 text-xs"
                            >
                              <div>
                                <span className="font-semibold text-zinc-200">{exp.title}</span>
                                <span className="text-zinc-500 text-[10px] ml-2">
                                  {exp.category} &bull; {new Date(exp.date).toLocaleDateString()}
                                </span>
                              </div>
                              <span className="font-mono font-bold text-rose-400">
                                -{formatCurrency(exp.amount, report.currencySymbol)}
                              </span>
                            </div>
                          ))}
                        </div>
                      </div>
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        )}

        <div className="mt-6 pt-4 border-t border-zinc-800 flex justify-end">
          <button
            type="button"
            onClick={onClose}
            className="px-5 py-2 rounded-xl text-xs font-semibold text-zinc-950 bg-zinc-100 hover:bg-zinc-200 transition-colors"
          >
            Close
          </button>
        </div>
      </div>
    </div>
  );
};
