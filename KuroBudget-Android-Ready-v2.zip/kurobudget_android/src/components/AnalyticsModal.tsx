import React from 'react';
import { X, PieChart, TrendingDown, DollarSign } from 'lucide-react';
import { AllowanceConfig, Expense } from '../types/budget';
import {
  calculateSpent,
  calculateRemainingAllowance,
  calculateCategoryBreakdown,
  formatCurrency,
  CATEGORY_COLORS,
} from '../utils/budgetCalculations';

interface AnalyticsModalProps {
  isOpen: boolean;
  onClose: () => void;
  config: AllowanceConfig;
  expenses: Expense[];
}

export const AnalyticsModal: React.FC<AnalyticsModalProps> = ({
  isOpen,
  onClose,
  config,
  expenses,
}) => {
  if (!isOpen) return null;

  const totalSpent = calculateSpent(expenses);
  const remaining = calculateRemainingAllowance(config.totalAllowance, expenses);
  const breakdown = calculateCategoryBreakdown(expenses);

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-zinc-950/80 backdrop-blur-sm animate-fade-in">
      <div className="relative w-full max-w-lg rounded-3xl bg-zinc-900 border border-zinc-800 p-4 sm:p-7 shadow-2xl max-h-[90dvh] overflow-y-auto overscroll-contain">
        <button
          onClick={onClose}
          aria-label="Close dialog"
          className="absolute right-4 top-4 p-2 text-zinc-400 hover:text-zinc-100 hover:bg-zinc-800 rounded-xl transition-colors"
        >
          <X className="w-5 h-5" />
        </button>

        <div className="flex items-center gap-3 mb-5">
          <div className="w-10 h-10 rounded-xl bg-purple-500/10 border border-purple-500/20 flex items-center justify-center text-purple-400">
            <PieChart className="w-5 h-5" />
          </div>
          <div>
            <h3 className="text-lg font-bold text-zinc-100">
              Spending Breakdown &amp; Analytics
            </h3>
            <p className="text-xs text-zinc-400">
              How your allowance is distributed across categories
            </p>
          </div>
        </div>

        {/* Top Summary Cards */}
        <div className="grid grid-cols-2 gap-3 mb-6">
          <div className="p-4 rounded-2xl bg-zinc-950 border border-zinc-800">
            <div className="text-[11px] font-medium text-zinc-400 mb-1">Total Deducted</div>
            <div className="text-xl font-bold font-mono text-zinc-100">
              {formatCurrency(totalSpent, config.currencySymbol)}
            </div>
            <div className="text-[10px] text-zinc-500 mt-0.5">
              Across {expenses.length} expense{expenses.length === 1 ? '' : 's'}
            </div>
          </div>

          <div className="p-4 rounded-2xl bg-zinc-950 border border-zinc-800">
            <div className="text-[11px] font-medium text-zinc-400 mb-1">Remaining Allowance</div>
            <div
              className={`text-xl font-bold font-mono ${
                remaining >= 0 ? 'text-emerald-400' : 'text-rose-400'
              }`}
            >
              {formatCurrency(remaining, config.currencySymbol)}
            </div>
            <div className="text-[10px] text-zinc-500 mt-0.5">
              {config.totalAllowance > 0
                ? `${((remaining / config.totalAllowance) * 100).toFixed(0)}% available`
                : ''}
            </div>
          </div>
        </div>

        {/* Breakdown List */}
        <div className="space-y-4">
          <h4 className="text-xs font-semibold uppercase tracking-wider text-zinc-400">
            Category Breakdown
          </h4>

          {breakdown.length === 0 ? (
            <div className="text-center py-8 text-xs text-zinc-500">
              No expenses recorded yet. Deduct expenses to view category breakdown.
            </div>
          ) : (
            breakdown.map((item) => {
              const color = CATEGORY_COLORS[item.category];

              return (
                <div key={item.category} className="space-y-1.5">
                  <div className="flex items-center justify-between text-xs">
                    <div className="flex items-center gap-2">
                      <span className={`w-2.5 h-2.5 rounded-full ${color ? color.dot : 'bg-zinc-400'}`} />
                      <span className="font-semibold text-zinc-200">{item.category}</span>
                      <span className="text-[10px] text-zinc-500">
                        ({item.count} deduction{item.count === 1 ? '' : 's'})
                      </span>
                    </div>
                    <div className="flex items-center gap-2">
                      <span className="font-mono font-bold text-zinc-100">
                        {formatCurrency(item.amount, config.currencySymbol)}
                      </span>
                      <span className="text-zinc-500 font-mono text-[11px] w-12 text-right">
                        {item.percentage.toFixed(1)}%
                      </span>
                    </div>
                  </div>

                  {/* Visual Bar */}
                  <div className="h-2 w-full bg-zinc-950 rounded-full overflow-hidden border border-zinc-800">
                    <div
                      className={`h-full rounded-full ${color ? color.dot : 'bg-zinc-400'}`}
                      style={{ width: `${Math.min(100, Math.max(1, item.percentage))}%` }}
                    />
                  </div>
                </div>
              );
            })
          )}
        </div>

        <div className="mt-8 pt-4 border-t border-zinc-800 flex justify-end">
          <button
            onClick={onClose}
            className="px-5 py-2 rounded-xl text-xs font-semibold text-zinc-950 bg-zinc-100 hover:bg-zinc-200 transition-colors"
          >
            Close
          </button>
        </div>
      </div>
    </div>
  );
};
