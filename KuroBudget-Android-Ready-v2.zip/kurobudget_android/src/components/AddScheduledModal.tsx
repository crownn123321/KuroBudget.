import React, { useState, useEffect } from 'react';
import { X, CalendarClock, Sparkles, Check } from 'lucide-react';
import {
  AllowanceConfig,
  ExpenseCategory,
  RecurringFrequency,
  RecurringSchedule,
} from '../types/budget';
import {
  CATEGORIES,
  DAY_NAMES,
  toISODateString,
} from '../utils/budgetCalculations';

interface AddScheduledModalProps {
  isOpen: boolean;
  onClose: () => void;
  config: AllowanceConfig;
  initialDayOfWeek?: number;
  initialTitle?: string;
  onAddSchedule: (schedule: Omit<RecurringSchedule, 'id' | 'createdAt'>) => void;
}

export const AddScheduledModal: React.FC<AddScheduledModalProps> = ({
  isOpen,
  onClose,
  config,
  initialDayOfWeek = 5, // default to Friday!
  initialTitle = '',
  onAddSchedule,
}) => {
  const [title, setTitle] = useState(initialTitle);
  const [amount, setAmount] = useState('');
  const [category, setCategory] = useState<ExpenseCategory>('Food & Dining');
  const [frequency, setFrequency] = useState<RecurringFrequency>('weekly');
  const [dayOfWeek, setDayOfWeek] = useState<number>(initialDayOfWeek);
  const [dayOfMonth, setDayOfMonth] = useState<number>(1);
  const [specificDate, setSpecificDate] = useState(() => {
    const d = new Date();
    d.setDate(d.getDate() + 7);
    return toISODateString(d);
  });
  const [autoDeduct, setAutoDeduct] = useState(true);
  const [note, setNote] = useState('');

  // Sync props when opened with presets
  useEffect(() => {
    if (isOpen) {
      if (initialTitle) setTitle(initialTitle);
      if (initialDayOfWeek !== undefined) {
        setDayOfWeek(initialDayOfWeek);
        setFrequency('weekly');
      }
    }
  }, [isOpen, initialDayOfWeek, initialTitle]);

  if (!isOpen) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const parsedAmount = parseFloat(amount);
    if (isNaN(parsedAmount) || parsedAmount <= 0) return;
    if (!title.trim()) return;

    onAddSchedule({
      title: title.trim(),
      amount: parsedAmount,
      category,
      frequency,
      dayOfWeek: frequency === 'weekly' ? dayOfWeek : undefined,
      dayOfMonth: frequency === 'monthly' ? dayOfMonth : undefined,
      specificDate: frequency === 'specific_date' ? specificDate : undefined,
      autoDeduct,
      isActive: true,
      note: note.trim() || undefined,
    });

    // Reset fields
    setTitle('');
    setAmount('');
    setNote('');
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-zinc-950/80 backdrop-blur-sm animate-fade-in">
      <div className="relative w-full max-w-lg rounded-3xl bg-zinc-900 border border-zinc-800 p-4 sm:p-7 shadow-2xl max-h-[90dvh] overflow-y-auto overscroll-contain">
        {/* Close Button */}
        <button
          onClick={onClose}
          aria-label="Close dialog"
          className="absolute right-4 top-4 p-2 text-zinc-400 hover:text-zinc-100 hover:bg-zinc-800 rounded-xl transition-colors"
        >
          <X className="w-5 h-5" />
        </button>

        <div className="flex items-center gap-3 mb-5">
          <div className="w-10 h-10 rounded-xl bg-sky-500/10 border border-sky-500/20 flex items-center justify-center text-sky-400">
            <CalendarClock className="w-5 h-5" />
          </div>
          <div>
            <h3 className="text-lg font-bold text-zinc-100">
              Schedule an Expense
            </h3>
            <p className="text-xs text-zinc-400">
              Add an expense that happens on a specific day (like every Friday or Tuesday)
            </p>
          </div>
        </div>

        <form onSubmit={handleSubmit} className="space-y-4">
          {/* Quick Presets for user requirement */}
          <div className="p-3 rounded-2xl bg-zinc-950 border border-zinc-800/80">
            <div className="text-[11px] font-semibold text-zinc-400 uppercase tracking-wider mb-2 flex items-center gap-1.5">
              <Sparkles className="w-3 h-3 text-sky-400" />
              <span>Quick Presets</span>
            </div>
            <div className="flex flex-wrap items-center gap-1.5">
              <button
                type="button"
                onClick={() => {
                  setFrequency('weekly');
                  setDayOfWeek(5); // Friday
                  if (!title) setTitle('Friday Night Out');
                  setCategory('Food & Dining');
                }}
                className={`px-2.5 py-1 rounded-lg text-xs font-medium transition-colors ${
                  frequency === 'weekly' && dayOfWeek === 5
                    ? 'bg-sky-400 text-zinc-950 font-semibold'
                    : 'bg-zinc-900 text-zinc-300 hover:bg-zinc-800 border border-zinc-700/60'
                }`}
              >
                Every Friday
              </button>
              <button
                type="button"
                onClick={() => {
                  setFrequency('weekly');
                  setDayOfWeek(2); // Tuesday
                  if (!title) setTitle('Tuesday Transit / Fuel');
                  setCategory('Transportation');
                }}
                className={`px-2.5 py-1 rounded-lg text-xs font-medium transition-colors ${
                  frequency === 'weekly' && dayOfWeek === 2
                    ? 'bg-sky-400 text-zinc-950 font-semibold'
                    : 'bg-zinc-900 text-zinc-300 hover:bg-zinc-800 border border-zinc-700/60'
                }`}
              >
                Every Tuesday
              </button>
              <button
                type="button"
                onClick={() => {
                  setFrequency('weekly');
                  setDayOfWeek(6); // Saturday
                  if (!title) setTitle('Saturday Groceries');
                  setCategory('Groceries');
                }}
                className={`px-2.5 py-1 rounded-lg text-xs font-medium transition-colors ${
                  frequency === 'weekly' && dayOfWeek === 6
                    ? 'bg-sky-400 text-zinc-950 font-semibold'
                    : 'bg-zinc-900 text-zinc-300 hover:bg-zinc-800 border border-zinc-700/60'
                }`}
              >
                Every Saturday
              </button>
              <button
                type="button"
                onClick={() => {
                  setFrequency('monthly');
                  setDayOfMonth(1);
                  if (!title) setTitle('Monthly Subscription / Bill');
                  setCategory('Bills & Utilities');
                }}
                className={`px-2.5 py-1 rounded-lg text-xs font-medium transition-colors ${
                  frequency === 'monthly' && dayOfMonth === 1
                    ? 'bg-sky-400 text-zinc-950 font-semibold'
                    : 'bg-zinc-900 text-zinc-300 hover:bg-zinc-800 border border-zinc-700/60'
                }`}
              >
                1st of Month
              </button>
            </div>
          </div>

          {/* Amount and Title */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <label className="block text-xs font-semibold uppercase tracking-wider text-zinc-300 mb-1.5">
                Expense Amount
              </label>
              <div className="relative">
                <span className="absolute left-3.5 top-1/2 -translate-y-1/2 text-zinc-400 font-mono text-base">
                  {config.currencySymbol}
                </span>
                <input
                  type="number"
                  step="0.01"
                  min="0.01"
                  required
                  placeholder="0.00"
                  value={amount}
                  onChange={(e) => setAmount(e.target.value)}
                  className="w-full bg-zinc-950 border border-zinc-700 rounded-xl pl-8 pr-3 py-2.5 text-zinc-100 font-mono text-base focus:outline-none focus:ring-2 focus:ring-sky-500/50 focus:border-sky-500 transition-all"
                />
              </div>
            </div>

            <div>
              <label className="block text-xs font-semibold uppercase tracking-wider text-zinc-300 mb-1.5">
                Expense Title
              </label>
              <input
                type="text"
                required
                placeholder="e.g. Friday Pizza, Commute pass"
                value={title}
                onChange={(e) => setTitle(e.target.value)}
                className="w-full bg-zinc-950 border border-zinc-700 rounded-xl px-3.5 py-2.5 text-sm text-zinc-100 placeholder-zinc-500 focus:outline-none focus:ring-2 focus:ring-sky-500/50 focus:border-sky-500 transition-all"
              />
            </div>
          </div>

          {/* Frequency Type */}
          <div>
            <label className="block text-xs font-semibold uppercase tracking-wider text-zinc-300 mb-1.5">
              Occurrence Schedule
            </label>
            <div className="grid grid-cols-3 gap-2">
              <button
                type="button"
                onClick={() => setFrequency('weekly')}
                className={`py-2 px-3 rounded-xl text-xs font-medium border text-center transition-all ${
                  frequency === 'weekly'
                    ? 'bg-sky-500/15 border-sky-400 text-sky-300 font-semibold'
                    : 'bg-zinc-950 border-zinc-800 text-zinc-400 hover:text-zinc-200'
                }`}
              >
                Weekly on Day
              </button>
              <button
                type="button"
                onClick={() => setFrequency('monthly')}
                className={`py-2 px-3 rounded-xl text-xs font-medium border text-center transition-all ${
                  frequency === 'monthly'
                    ? 'bg-sky-500/15 border-sky-400 text-sky-300 font-semibold'
                    : 'bg-zinc-950 border-zinc-800 text-zinc-400 hover:text-zinc-200'
                }`}
              >
                Monthly Date
              </button>
              <button
                type="button"
                onClick={() => setFrequency('specific_date')}
                className={`py-2 px-3 rounded-xl text-xs font-medium border text-center transition-all ${
                  frequency === 'specific_date'
                    ? 'bg-sky-500/15 border-sky-400 text-sky-300 font-semibold'
                    : 'bg-zinc-950 border-zinc-800 text-zinc-400 hover:text-zinc-200'
                }`}
              >
                Specific Date
              </button>
            </div>
          </div>

          {/* Day of Week Selector if Weekly */}
          {frequency === 'weekly' && (
            <div className="p-3 rounded-2xl bg-zinc-950 border border-zinc-800">
              <label className="block text-xs font-medium text-zinc-300 mb-2">
                Repeat Every Week on:
              </label>
              <div className="grid grid-cols-7 gap-1.5">
                {DAY_NAMES.map((name, idx) => {
                  const isSelected = dayOfWeek === idx;
                  const isFriday = idx === 5;
                  const isTuesday = idx === 2;

                  return (
                    <button
                      key={name}
                      type="button"
                      onClick={() => setDayOfWeek(idx)}
                      className={`py-2 rounded-xl text-xs font-bold transition-all ${
                        isSelected
                          ? 'bg-sky-400 text-zinc-950 shadow-md shadow-sky-950/50'
                          : 'bg-zinc-900 text-zinc-400 hover:bg-zinc-800 hover:text-zinc-200 border border-zinc-800'
                      }`}
                      title={`Every ${name}`}
                    >
                      <div className="text-[10px] uppercase font-mono">{name.slice(0, 3)}</div>
                      {(isFriday || isTuesday) && !isSelected && (
                        <div className="w-1 h-1 rounded-full bg-sky-400 mx-auto mt-0.5" />
                      )}
                    </button>
                  );
                })}
              </div>
              <div className="mt-2 text-[11px] text-sky-400 font-medium text-center">
                &rarr; Will deduct automatically every{' '}
                <strong>{DAY_NAMES[dayOfWeek]}</strong>
              </div>
            </div>
          )}

          {/* Day of Month Selector if Monthly */}
          {frequency === 'monthly' && (
            <div className="p-3 rounded-2xl bg-zinc-950 border border-zinc-800">
              <label className="block text-xs font-medium text-zinc-300 mb-1.5">
                Day of the Month (1-31):
              </label>
              <div className="flex items-center gap-3">
                <input
                  type="number"
                  min="1"
                  max="31"
                  value={dayOfMonth}
                  onChange={(e) => setDayOfMonth(Math.min(31, Math.max(1, parseInt(e.target.value) || 1)))}
                  className="w-24 bg-zinc-900 border border-zinc-700 rounded-xl px-3 py-2 text-zinc-100 font-mono text-center font-bold focus:outline-none focus:ring-2 focus:ring-sky-500/50"
                />
                <span className="text-xs text-zinc-400">
                  e.g. 1st, 15th, or 28th of every month
                </span>
              </div>
            </div>
          )}

          {/* Specific Date Picker if Specific Date */}
          {frequency === 'specific_date' && (
            <div className="p-3 rounded-2xl bg-zinc-950 border border-zinc-800">
              <label className="block text-xs font-medium text-zinc-300 mb-1.5">
                Exact Calendar Date:
              </label>
              <input
                type="date"
                required
                value={specificDate}
                onChange={(e) => setSpecificDate(e.target.value)}
                className="w-full bg-zinc-900 border border-zinc-700 rounded-xl px-3.5 py-2 text-zinc-100 text-sm focus:outline-none focus:ring-2 focus:ring-sky-500/50"
              />
            </div>
          )}

          {/* Category */}
          <div>
            <label className="block text-xs font-semibold uppercase tracking-wider text-zinc-300 mb-1.5">
              Category
            </label>
            <select
              value={category}
              onChange={(e) => setCategory(e.target.value as ExpenseCategory)}
              className="w-full bg-zinc-950 border border-zinc-700 rounded-xl px-3 py-2.5 text-sm text-zinc-200 focus:outline-none focus:ring-2 focus:ring-sky-500/50 transition-all"
            >
              {CATEGORIES.map((cat) => (
                <option key={cat} value={cat} className="bg-zinc-900 text-zinc-100">
                  {cat}
                </option>
              ))}
            </select>
          </div>

          {/* User Requested: Dedicated Option to automatically deduct on the day it is set */}
          <div
            onClick={() => setAutoDeduct(!autoDeduct)}
            className={`p-3.5 rounded-2xl border cursor-pointer transition-all ${
              autoDeduct
                ? 'bg-sky-500/10 border-sky-500/40 shadow-sm'
                : 'bg-zinc-950 border-zinc-800 hover:border-zinc-700'
            }`}
          >
            <div className="flex items-start justify-between gap-3">
              <div className="space-y-1">
                <div className="flex items-center gap-2">
                  <span className={`text-xs font-bold ${autoDeduct ? 'text-sky-300' : 'text-zinc-300'}`}>
                    Automatically deduct on the day it is set
                  </span>
                  <span
                    className={`text-[10px] px-2 py-0.5 rounded-full font-bold uppercase tracking-wider ${
                      autoDeduct
                        ? 'bg-sky-400 text-zinc-950'
                        : 'bg-zinc-800 text-zinc-400'
                    }`}
                  >
                    {autoDeduct ? 'Active' : 'Off'}
                  </span>
                </div>
                <p className="text-[11px] text-zinc-400 leading-relaxed">
                  {autoDeduct
                    ? `Will automatically minus ${amount ? `${config.currencySymbol}${amount}` : 'this amount'} from your allowance every ${
                        frequency === 'weekly'
                          ? DAY_NAMES[dayOfWeek]
                          : frequency === 'monthly'
                          ? `day ${dayOfMonth} of the month`
                          : specificDate
                      }.`
                    : 'Manual mode: KuroBudget will alert you on the due date so you can confirm deduction with one tap.'}
                </p>
              </div>

              {/* Toggle Switch */}
              <button
                type="button"
                role="switch"
                aria-checked={autoDeduct}
                onClick={(e) => {
                  e.stopPropagation();
                  setAutoDeduct(!autoDeduct);
                }}
                className={`relative inline-flex h-6 w-11 shrink-0 cursor-pointer rounded-full border-2 border-transparent transition-colors duration-200 ease-in-out focus:outline-none focus:ring-2 focus:ring-sky-500/50 mt-0.5 ${
                  autoDeduct ? 'bg-sky-400' : 'bg-zinc-700'
                }`}
              >
                <span
                  className={`pointer-events-none inline-block h-5 w-5 transform rounded-full bg-zinc-950 shadow-lg ring-0 transition duration-200 ease-in-out ${
                    autoDeduct ? 'translate-x-5' : 'translate-x-0'
                  }`}
                />
              </button>
            </div>
          </div>

          {/* Notes */}
          <div>
            <label className="block text-xs font-semibold uppercase tracking-wider text-zinc-300 mb-1.5">
              Optional Note
            </label>
            <input
              type="text"
              placeholder="e.g. Movie with friends, Commute bus reload..."
              value={note}
              onChange={(e) => setNote(e.target.value)}
              className="w-full bg-zinc-950 border border-zinc-700 rounded-xl px-3.5 py-2 text-xs text-zinc-200 placeholder-zinc-500 focus:outline-none focus:ring-2 focus:ring-sky-500/50 transition-all"
            />
          </div>

          {/* Submit */}
          <div className="pt-3 flex items-center justify-end gap-2.5">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2.5 rounded-xl text-xs font-medium text-zinc-400 hover:text-zinc-200 hover:bg-zinc-800 transition-colors"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="px-5 py-2.5 rounded-xl text-xs font-semibold text-zinc-950 bg-sky-400 hover:bg-sky-300 shadow-md shadow-sky-950/40 transition-all"
            >
              Save Scheduled Expense
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
