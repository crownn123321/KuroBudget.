import React, { useState } from 'react';
import {
  CalendarClock,
  Plus,
  Repeat,
  CheckCircle2,
  Trash2,
  PauseCircle,
  PlayCircle,
  Calendar,
  AlertCircle,
  Clock,
  Sparkles,
} from 'lucide-react';
import {
  AllowanceConfig,
  RecurringSchedule,
  UpcomingOccurrence,
} from '../types/budget';
import {
  formatCurrency,
  getScheduleFrequencyLabel,
  getNextOccurrence,
  getUpcomingOccurrences,
  CATEGORY_COLORS,
  DAY_NAMES,
  toISODateString,
} from '../utils/budgetCalculations';

interface ScheduledExpensesSectionProps {
  config: AllowanceConfig;
  schedules: RecurringSchedule[];
  onOpenAddModal: () => void;
  onOpenAddPreset: (dayOfWeek: number, defaultTitle?: string) => void;
  onToggleActive: (id: string) => void;
  onToggleAutoDeduct?: (id: string) => void;
  onDeleteSchedule: (id: string) => void;
  onDeductScheduledNow: (schedule: RecurringSchedule, dateStr?: string) => void;
}

export const ScheduledExpensesSection: React.FC<ScheduledExpensesSectionProps> = ({
  config,
  schedules,
  onOpenAddModal,
  onOpenAddPreset,
  onToggleActive,
  onToggleAutoDeduct,
  onDeleteSchedule,
  onDeductScheduledNow,
}) => {
  const [activeTab, setActiveTab] = useState<'rules' | 'timeline'>('rules');

  const now = new Date();
  const todayStr = toISODateString(now);

  const upcomingOccurrences = getUpcomingOccurrences(schedules, now, 28);
  const totalUpcomingCommitment = upcomingOccurrences.reduce((sum, occ) => sum + occ.amount, 0);

  // Check if any scheduled item is due today
  const dueToday = upcomingOccurrences.filter(
    (occ) => occ.dateString === todayStr
  );

  return (
    <div className="rounded-3xl bg-zinc-900/60 border border-zinc-800/80 p-6 sm:p-7 shadow-xl">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-5 border-b border-zinc-800/70">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-sky-500/10 border border-sky-500/20 flex items-center justify-center text-sky-400">
            <CalendarClock className="w-5 h-5" />
          </div>
          <div>
            <h2 className="text-lg font-bold text-zinc-100 flex items-center gap-2">
              <span>Scheduled &amp; Recurring Expenses</span>
              <span className="text-xs font-semibold px-2 py-0.5 rounded-full bg-sky-500/10 text-sky-400 border border-sky-500/20">
                {schedules.length}
              </span>
            </h2>
            <p className="text-xs text-zinc-400">
              Set expenses that trigger on specific days (like every Friday or Tuesday)
            </p>
          </div>
        </div>

        <div className="flex items-center gap-2">
          {/* Quick Preset Buttons for user's prompt: every friday / tuesday */}
          <div className="hidden lg:flex items-center gap-1.5 mr-2">
            <button
              onClick={() => onOpenAddPreset(5, 'Friday Outing & Drinks')}
              className="px-2.5 py-1.5 rounded-lg text-xs font-medium bg-zinc-800 hover:bg-zinc-700 text-sky-300 border border-zinc-700 transition-colors flex items-center gap-1"
              title="Add expense recurring every Friday"
            >
              <Sparkles className="w-3 h-3 text-sky-400" />
              + Every Fri
            </button>
            <button
              onClick={() => onOpenAddPreset(2, 'Tuesday Commute / Fuel')}
              className="px-2.5 py-1.5 rounded-lg text-xs font-medium bg-zinc-800 hover:bg-zinc-700 text-sky-300 border border-zinc-700 transition-colors flex items-center gap-1"
              title="Add expense recurring every Tuesday"
            >
              <Sparkles className="w-3 h-3 text-sky-400" />
              + Every Tue
            </button>
          </div>

          <button
            onClick={onOpenAddModal}
            aria-label="Add new scheduled expense"
            className="inline-flex items-center gap-1.5 px-3.5 py-2 rounded-xl text-xs font-semibold text-zinc-950 bg-sky-400 hover:bg-sky-300 shadow-md shadow-sky-950/40 transition-all hover:scale-[1.02] active:scale-[0.98]"
          >
            <Plus className="w-3.5 h-3.5 stroke-[2.5]" />
            <span>Add Scheduled</span>
          </button>
        </div>
      </div>

      {/* Due Today Banner if any scheduled item falls on today */}
      {dueToday.length > 0 && (
        <div className="mt-4 p-4 rounded-2xl bg-amber-500/10 border border-amber-500/30 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3">
          <div className="flex items-start gap-3">
            <AlertCircle className="w-5 h-5 text-amber-400 shrink-0 mt-0.5 sm:mt-0" />
            <div>
              <div className="text-xs font-semibold text-amber-300">
                {dueToday.length} Scheduled Expense{dueToday.length > 1 ? 's' : ''} Due Today!
              </div>
              <div className="text-xs text-amber-200/70">
                {dueToday.map((item) => `${item.title} (${formatCurrency(item.amount, config.currencySymbol)})`).join(', ')}
              </div>
            </div>
          </div>
          <div className="flex items-center gap-2 w-full sm:w-auto">
            {dueToday.map((occ) => {
              const matchedSchedule = schedules.find((s) => s.id === occ.scheduleId);
              if (!matchedSchedule) return null;
              return (
                <button
                  key={occ.scheduleId}
                  onClick={() => onDeductScheduledNow(matchedSchedule, occ.dateString)}
                  className="px-3 py-1.5 rounded-lg text-xs font-semibold text-zinc-950 bg-amber-400 hover:bg-amber-300 transition-colors shadow-sm"
                >
                  Deduct {occ.title} ({formatCurrency(occ.amount, config.currencySymbol)})
                </button>
              );
            })}
          </div>
        </div>
      )}

      {/* View Switcher Tabs */}
      <div className="flex items-center justify-between gap-4 mt-5 mb-4">
        <div className="inline-flex p-1 rounded-xl bg-zinc-950 border border-zinc-800 text-xs font-medium">
          <button
            onClick={() => setActiveTab('rules')}
            className={`px-3 py-1.5 rounded-lg transition-all ${
              activeTab === 'rules'
                ? 'bg-zinc-800 text-zinc-100 shadow-sm'
                : 'text-zinc-400 hover:text-zinc-200'
            }`}
          >
            All Schedules ({schedules.length})
          </button>
          <button
            onClick={() => setActiveTab('timeline')}
            className={`px-3 py-1.5 rounded-lg transition-all ${
              activeTab === 'timeline'
                ? 'bg-zinc-800 text-zinc-100 shadow-sm'
                : 'text-zinc-400 hover:text-zinc-200'
            }`}
          >
            Upcoming 4 Weeks ({upcomingOccurrences.length})
          </button>
        </div>

        <div className="text-xs text-zinc-400 hidden sm:block">
          Reserved next 28 days:{' '}
          <span className="font-semibold text-sky-400 font-mono">
            {formatCurrency(totalUpcomingCommitment, config.currencySymbol)}
          </span>
        </div>
      </div>

      {/* Tab 1: Rules List */}
      {activeTab === 'rules' && (
        <div className="space-y-3">
          {schedules.length === 0 ? (
            <div className="text-center py-12 px-4 rounded-2xl border border-dashed border-zinc-800 bg-zinc-950/40">
              <Calendar className="w-10 h-10 text-zinc-600 mx-auto mb-3" />
              <p className="text-sm font-semibold text-zinc-300">No scheduled expenses yet</p>
              <p className="text-xs text-zinc-500 mt-1 max-w-sm mx-auto">
                Schedule recurring expenses for specific days like every Friday or Tuesday to track allowance impact in advance.
              </p>
              <button
                onClick={onOpenAddModal}
                className="mt-4 px-4 py-2 rounded-xl text-xs font-semibold bg-sky-500/20 text-sky-300 hover:bg-sky-500/30 border border-sky-500/40 transition-colors"
              >
                + Add your first schedule
              </button>
            </div>
          ) : (
            schedules.map((schedule) => {
              const nextDate = getNextOccurrence(schedule, now);
              const colorInfo = CATEGORY_COLORS[schedule.category];
              const frequencyLabel = getScheduleFrequencyLabel(schedule);

              return (
                <div
                  key={schedule.id}
                  className={`group rounded-2xl p-4 border transition-all ${
                    schedule.isActive
                      ? 'bg-zinc-950/70 border-zinc-800/80 hover:border-zinc-700'
                      : 'bg-zinc-950/30 border-zinc-900 opacity-60'
                  }`}
                >
                  <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                    {/* Left: Info */}
                    <div className="flex items-start gap-3">
                      <div
                        className={`w-9 h-9 rounded-xl flex items-center justify-center shrink-0 mt-0.5 ${
                          colorInfo ? colorInfo.bg : 'bg-zinc-800'
                        } ${colorInfo ? colorInfo.border : 'border-zinc-700'} border`}
                      >
                        <Repeat className={`w-4 h-4 ${colorInfo ? colorInfo.text : 'text-zinc-400'}`} />
                      </div>

                      <div>
                        <div className="flex flex-wrap items-center gap-2">
                          <h3 className="font-semibold text-zinc-100 text-sm">
                            {schedule.title}
                          </h3>
                          {/* Frequency Tag (e.g. Every Friday / Every Tuesday) */}
                          <span className="px-2 py-0.5 rounded-md text-[11px] font-semibold bg-sky-500/15 text-sky-300 border border-sky-500/30">
                            {frequencyLabel}
                          </span>
                          <span
                            className={`px-2 py-0.5 rounded-md text-[10px] font-medium ${
                              colorInfo ? colorInfo.bg : 'bg-zinc-800'
                            } ${colorInfo ? colorInfo.text : 'text-zinc-400'}`}
                          >
                            {schedule.category}
                          </span>
                          {!schedule.isActive && (
                            <span className="text-[10px] text-zinc-500 italic">
                              (Paused)
                            </span>
                          )}
                        </div>

                        {schedule.note && (
                          <p className="text-xs text-zinc-500 mt-0.5">
                            {schedule.note}
                          </p>
                        )}

                        <div className="flex flex-wrap items-center gap-2.5 mt-2 text-[11px] text-zinc-400">
                          {nextDate && (
                            <span className="flex items-center gap-1 text-zinc-400">
                              <Clock className="w-3 h-3 text-zinc-500" />
                              Next:{' '}
                              <strong className="text-zinc-300 font-medium">
                                {nextDate.toLocaleDateString('en-US', {
                                  weekday: 'short',
                                  month: 'short',
                                  day: 'numeric',
                                })}
                              </strong>
                            </span>
                          )}
                          <span className="text-zinc-600">&bull;</span>
                          {onToggleAutoDeduct ? (
                            <button
                              type="button"
                              onClick={() => onToggleAutoDeduct(schedule.id)}
                              className={`px-2 py-0.5 rounded-md font-medium text-[10px] border transition-colors flex items-center gap-1 ${
                                schedule.autoDeduct
                                  ? 'bg-sky-500/15 text-sky-300 border-sky-500/30 hover:bg-sky-500/25'
                                  : 'bg-zinc-800 text-zinc-400 border-zinc-700 hover:text-zinc-200'
                              }`}
                              title="Click to toggle auto-deduct on the scheduled day"
                            >
                              <span>{schedule.autoDeduct ? '⚡ Auto-deduct ON' : '✋ Manual deduct'}</span>
                            </button>
                          ) : (
                            <span className="text-zinc-500">
                              {schedule.autoDeduct ? '⚡ Auto-deduct ON' : '✋ Manual deduct'}
                            </span>
                          )}
                        </div>
                      </div>
                    </div>

                    {/* Right: Amount & Actions */}
                    <div className="flex items-center justify-between sm:justify-end gap-3 pt-2 sm:pt-0 border-t sm:border-t-0 border-zinc-800/60">
                      <div className="text-right">
                        <div className="text-base sm:text-lg font-bold font-mono text-zinc-100">
                          {formatCurrency(schedule.amount, config.currencySymbol)}
                        </div>
                        <div className="text-[10px] text-zinc-500">
                          per recurrence
                        </div>
                      </div>

                      <div className="flex items-center gap-1.5">
                        <button
                          onClick={() => onDeductScheduledNow(schedule)}
                          aria-label={`Deduct ${schedule.title} now from allowance`}
                          className="px-2.5 py-1.5 rounded-xl text-xs font-semibold text-emerald-400 hover:text-emerald-300 bg-emerald-500/10 hover:bg-emerald-500/20 border border-emerald-500/20 transition-all flex items-center gap-1"
                          title="Deduct now from current allowance"
                        >
                          <CheckCircle2 className="w-3.5 h-3.5" />
                          <span className="hidden sm:inline">Deduct Now</span>
                        </button>

                        <button
                          onClick={() => onToggleActive(schedule.id)}
                          aria-label={schedule.isActive ? 'Pause schedule' : 'Resume schedule'}
                          className="p-1.5 rounded-lg text-zinc-400 hover:text-zinc-200 hover:bg-zinc-800 transition-colors"
                          title={schedule.isActive ? 'Pause schedule' : 'Resume schedule'}
                        >
                          {schedule.isActive ? (
                            <PauseCircle className="w-4 h-4" />
                          ) : (
                            <PlayCircle className="w-4 h-4 text-emerald-400" />
                          )}
                        </button>

                        <button
                          onClick={() => onDeleteSchedule(schedule.id)}
                          aria-label={`Delete scheduled expense ${schedule.title}`}
                          className="p-1.5 rounded-lg text-zinc-500 hover:text-rose-400 hover:bg-rose-500/10 transition-colors"
                          title="Delete schedule"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </div>
                    </div>
                  </div>
                </div>
              );
            })
          )}
        </div>
      )}

      {/* Tab 2: Upcoming Occurrences Timeline */}
      {activeTab === 'timeline' && (
        <div className="space-y-2.5">
          {upcomingOccurrences.length === 0 ? (
            <div className="text-center py-8 text-xs text-zinc-500">
              No upcoming occurrences found.
            </div>
          ) : (
            upcomingOccurrences.map((occ, idx) => {
              const matchedSchedule = schedules.find((s) => s.id === occ.scheduleId);
              const isToday = occ.daysAway === 0;
              const isTomorrow = occ.daysAway === 1;

              return (
                <div
                  key={`${occ.scheduleId}-${occ.dateString}-${idx}`}
                  className={`flex items-center justify-between p-3.5 rounded-xl border transition-all ${
                    isToday
                      ? 'bg-amber-500/10 border-amber-500/40 text-amber-200'
                      : isTomorrow
                      ? 'bg-sky-500/5 border-sky-500/30'
                      : 'bg-zinc-950/60 border-zinc-800/80'
                  }`}
                >
                  <div className="flex items-center gap-3">
                    <div className="text-center w-12 py-1 px-1.5 rounded-lg bg-zinc-900 border border-zinc-800 font-mono text-xs">
                      <div className="text-[10px] text-zinc-400 uppercase">
                        {DAY_NAMES[occ.date.getDay()].slice(0, 3)}
                      </div>
                      <div className="text-sm font-bold text-zinc-100">
                        {occ.date.getDate()}
                      </div>
                    </div>

                    <div>
                      <div className="flex items-center gap-2">
                        <span className="font-semibold text-zinc-200 text-sm">
                          {occ.title}
                        </span>
                        <span className="text-[10px] px-2 py-0.5 rounded bg-zinc-800 text-zinc-400 font-medium">
                          {occ.frequencyLabel}
                        </span>
                        {isToday && (
                          <span className="text-[10px] font-bold px-1.5 py-0.5 rounded bg-amber-400 text-zinc-950">
                            TODAY
                          </span>
                        )}
                        {isTomorrow && (
                          <span className="text-[10px] font-bold px-1.5 py-0.5 rounded bg-sky-400 text-zinc-950">
                            TOMORROW
                          </span>
                        )}
                      </div>
                      <div className="text-xs text-zinc-500">
                        {occ.formattedDate} &bull; {occ.category}
                      </div>
                    </div>
                  </div>

                  <div className="flex items-center gap-3">
                    <span className="font-mono font-bold text-sm text-zinc-100">
                      {formatCurrency(occ.amount, config.currencySymbol)}
                    </span>
                    {matchedSchedule && (
                      <button
                        onClick={() => onDeductScheduledNow(matchedSchedule, occ.dateString)}
                        className="px-2.5 py-1 rounded-lg text-xs font-semibold text-emerald-400 hover:text-emerald-300 bg-emerald-500/10 hover:bg-emerald-500/20 border border-emerald-500/20 transition-all"
                      >
                        Minus Now
                      </button>
                    )}
                  </div>
                </div>
              );
            })
          )}
        </div>
      )}
    </div>
  );
};
