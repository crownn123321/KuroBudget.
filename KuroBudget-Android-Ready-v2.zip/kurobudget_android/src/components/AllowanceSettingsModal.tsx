import React, { useState } from 'react';
import { X, Sliders, DollarSign, Calendar, RotateCcw, Archive } from 'lucide-react';
import { AllowanceConfig, PeriodType } from '../types/budget';
import { toISODateString } from '../utils/budgetCalculations';

interface AllowanceSettingsModalProps {
  isOpen: boolean;
  onClose: () => void;
  config: AllowanceConfig;
  onSaveConfig: (updated: AllowanceConfig) => void;
  onResetAllowance: (newAllowance?: number, newCycleName?: string) => void;
  onOpenArchives?: () => void;
}

const CURRENCIES = [
  { symbol: '₱', label: 'PHP - Philippine Peso (₱)' },
  { symbol: '$', label: 'USD / CAD / AUD ($)' },
  { symbol: '€', label: 'EUR (€)' },
  { symbol: '£', label: 'GBP (£)' },
  { symbol: '¥', label: 'JPY / CNY (¥)' },
  { symbol: '₹', label: 'INR (₹)' },
  { symbol: 'C$', label: 'CAD (C$)' },
  { symbol: 'A$', label: 'AUD (A$)' },
];

export const AllowanceSettingsModal: React.FC<AllowanceSettingsModalProps> = ({
  isOpen,
  onClose,
  config,
  onSaveConfig,
  onResetAllowance,
  onOpenArchives,
}) => {
  const [totalAllowance, setTotalAllowance] = useState(config.totalAllowance.toString());
  const [periodType, setPeriodType] = useState<PeriodType>(config.periodType);
  const [startDate, setStartDate] = useState(config.startDate);
  const [endDate, setEndDate] = useState(config.endDate);
  const [currencySymbol, setCurrencySymbol] = useState(config.currencySymbol);
  const [cycleName, setCycleName] = useState(config.cycleName || '');
  const [confirmReset, setConfirmReset] = useState(false);

  if (!isOpen) return null;

  const handlePeriodChange = (type: PeriodType) => {
    setPeriodType(type);
    const now = new Date();
    const start = new Date(now.getFullYear(), now.getMonth(), 1);

    if (type === 'monthly') {
      const end = new Date(now.getFullYear(), now.getMonth() + 1, 0);
      setStartDate(toISODateString(start));
      setEndDate(toISODateString(end));
      setCycleName(`${now.toLocaleString('default', { month: 'long' })} Allowance`);
    } else if (type === 'weekly') {
      const dayOfWeek = now.getDay();
      const weekStart = new Date(now.getFullYear(), now.getMonth(), now.getDate() - dayOfWeek);
      const weekEnd = new Date(weekStart.getFullYear(), weekStart.getMonth(), weekStart.getDate() + 6);
      setStartDate(toISODateString(weekStart));
      setEndDate(toISODateString(weekEnd));
      setCycleName('Weekly Allowance');
    } else if (type === 'biweekly') {
      const dayOfWeek = now.getDay();
      const biStart = new Date(now.getFullYear(), now.getMonth(), now.getDate() - dayOfWeek);
      const biEnd = new Date(biStart.getFullYear(), biStart.getMonth(), biStart.getDate() + 13);
      setStartDate(toISODateString(biStart));
      setEndDate(toISODateString(biEnd));
      setCycleName('Bi-Weekly Allowance');
    }
  };

  const handleSave = (e: React.FormEvent) => {
    e.preventDefault();
    const parsedAllowance = parseFloat(totalAllowance);
    if (isNaN(parsedAllowance) || parsedAllowance <= 0) return;

    onSaveConfig({
      totalAllowance: parsedAllowance,
      periodType,
      startDate,
      endDate,
      currencySymbol,
      cycleName: cycleName.trim() || undefined,
    });
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-zinc-950/80 backdrop-blur-sm animate-fade-in">
      <div className="relative w-full max-w-md rounded-3xl bg-zinc-900 border border-zinc-800 p-4 sm:p-7 shadow-2xl max-h-[90dvh] overflow-y-auto overscroll-contain">
        <button
          onClick={onClose}
          aria-label="Close dialog"
          className="absolute right-4 top-4 p-2 text-zinc-400 hover:text-zinc-100 hover:bg-zinc-800 rounded-xl transition-colors"
        >
          <X className="w-5 h-5" />
        </button>

        <div className="flex items-center gap-3 mb-5">
          <div className="w-10 h-10 rounded-xl bg-emerald-500/10 border border-emerald-500/20 flex items-center justify-center text-emerald-400">
            <Sliders className="w-5 h-5" />
          </div>
          <div>
            <h3 className="text-lg font-bold text-zinc-100">
              Allowance Settings
            </h3>
            <p className="text-xs text-zinc-400">
              Configure your starting allowance pool, cadence, and currency
            </p>
          </div>
        </div>

        <form onSubmit={handleSave} className="space-y-4">
          {/* Starting Allowance */}
          <div>
            <label className="block text-xs font-semibold uppercase tracking-wider text-zinc-300 mb-1.5">
              Total Allowance Amount
            </label>
            <div className="relative">
              <span className="absolute left-3.5 top-1/2 -translate-y-1/2 text-zinc-400 font-mono text-base">
                {currencySymbol}
              </span>
              <input
                type="number"
                step="1"
                min="1"
                required
                value={totalAllowance}
                onChange={(e) => setTotalAllowance(e.target.value)}
                className="w-full bg-zinc-950 border border-zinc-700 rounded-xl pl-9 pr-4 py-2.5 text-zinc-100 font-mono text-lg font-bold focus:outline-none focus:ring-2 focus:ring-emerald-500/50 transition-all"
              />
            </div>
          </div>

          {/* Currency */}
          <div>
            <div className="flex items-center justify-between mb-1.5">
              <label className="text-xs font-semibold uppercase tracking-wider text-zinc-300">
                Currency Symbol
              </label>
              <button
                type="button"
                onClick={() => {
                  setCurrencySymbol('₱');
                  if (parseFloat(totalAllowance) <= 2000) {
                    setTotalAllowance('25000');
                  }
                }}
                className="text-[11px] font-semibold text-emerald-400 hover:text-emerald-300 bg-emerald-500/10 px-2 py-0.5 rounded-md border border-emerald-500/20"
              >
                Set to ₱ (Philippine Peso)
              </button>
            </div>
            <select
              value={currencySymbol}
              onChange={(e) => setCurrencySymbol(e.target.value)}
              className="w-full bg-zinc-950 border border-zinc-700 rounded-xl px-3.5 py-2.5 text-sm text-zinc-200 focus:outline-none focus:ring-2 focus:ring-emerald-500/50 transition-all"
            >
              {CURRENCIES.map((c) => (
                <option key={c.symbol} value={c.symbol} className="bg-zinc-900 text-zinc-100">
                  {c.label}
                </option>
              ))}
            </select>
          </div>

          {/* Cadence Selection */}
          <div>
            <label className="block text-xs font-semibold uppercase tracking-wider text-zinc-300 mb-1.5">
              Allowance Period
            </label>
            <div className="grid grid-cols-4 gap-1.5">
              {(['weekly', 'biweekly', 'monthly', 'custom'] as PeriodType[]).map((type) => (
                <button
                  key={type}
                  type="button"
                  onClick={() => handlePeriodChange(type)}
                  className={`py-2 rounded-xl text-xs font-medium capitalize border transition-all ${
                    periodType === type
                      ? 'bg-emerald-500/15 border-emerald-400 text-emerald-300 font-semibold'
                      : 'bg-zinc-950 border-zinc-800 text-zinc-400 hover:text-zinc-200'
                  }`}
                >
                  {type}
                </button>
              ))}
            </div>
          </div>

          {/* Dates */}
          <div className="grid grid-cols-2 gap-2.5">
            <div>
              <label className="block text-[11px] font-medium text-zinc-400 mb-1">
                Start Date
              </label>
              <input
                type="date"
                required
                value={startDate}
                onChange={(e) => setStartDate(e.target.value)}
                className="w-full bg-zinc-950 border border-zinc-700 rounded-xl px-3 py-2 text-xs text-zinc-200 focus:outline-none focus:ring-2 focus:ring-emerald-500/50"
              />
            </div>
            <div>
              <label className="block text-[11px] font-medium text-zinc-400 mb-1">
                End Date (Reset)
              </label>
              <input
                type="date"
                required
                value={endDate}
                onChange={(e) => setEndDate(e.target.value)}
                className="w-full bg-zinc-950 border border-zinc-700 rounded-xl px-3 py-2 text-xs text-zinc-200 focus:outline-none focus:ring-2 focus:ring-emerald-500/50"
              />
            </div>
          </div>

          {/* Cycle Name */}
          <div>
            <label className="block text-[11px] font-medium text-zinc-400 mb-1">
              Cycle Label
            </label>
            <input
              type="text"
              placeholder="e.g. November Allowance"
              value={cycleName}
              onChange={(e) => setCycleName(e.target.value)}
              className="w-full bg-zinc-950 border border-zinc-700 rounded-xl px-3.5 py-2 text-xs text-zinc-200 placeholder-zinc-500 focus:outline-none focus:ring-2 focus:ring-emerald-500/50"
            />
          </div>

          {/* Reset & Archive Section */}
          <div className="pt-3 border-t border-zinc-800 space-y-2.5">
            {onOpenArchives && (
              <button
                type="button"
                onClick={() => {
                  onClose();
                  onOpenArchives();
                }}
                className="w-full py-2 px-3 rounded-xl text-xs font-semibold text-amber-300 hover:bg-amber-950/25 border border-amber-500/30 flex items-center justify-center gap-1.5 transition-colors"
              >
                <Archive className="w-3.5 h-3.5" />
                <span>View Past Archived Budget Reports</span>
              </button>
            )}

            {confirmReset ? (
              <div className="p-4 rounded-2xl bg-amber-500/10 border border-amber-500/30 space-y-3">
                <div className="text-xs font-bold text-amber-300 flex items-center gap-1.5">
                  <Archive className="w-3.5 h-3.5 text-amber-400" />
                  <span>Archive Current Report &amp; Reset Budget</span>
                </div>
                <p className="text-[11px] text-zinc-300 leading-relaxed">
                  The current allowance progress, circular graph stats, and all deductions will be safely preserved in <strong>Past Reports</strong>. Your allowance will reset with a fresh starting balance.
                </p>
                <div className="flex items-center justify-end gap-2 pt-1">
                  <button
                    type="button"
                    onClick={() => setConfirmReset(false)}
                    className="px-3 py-1.5 rounded-lg text-xs text-zinc-400 hover:text-zinc-200"
                  >
                    Cancel
                  </button>
                  <button
                    type="button"
                    onClick={() => {
                      onResetAllowance(parseFloat(totalAllowance) || config.totalAllowance, cycleName);
                      setConfirmReset(false);
                      onClose();
                    }}
                    className="px-3.5 py-1.5 rounded-lg text-xs font-bold bg-amber-400 text-zinc-950 hover:bg-amber-300 transition-colors shadow-sm"
                  >
                    Save to Archive &amp; Reset
                  </button>
                </div>
              </div>
            ) : (
              <button
                type="button"
                onClick={() => setConfirmReset(true)}
                className="w-full py-2 px-3 rounded-xl text-xs font-medium text-rose-400 hover:bg-rose-950/20 border border-rose-900/30 flex items-center justify-center gap-1.5 transition-colors"
              >
                <RotateCcw className="w-3.5 h-3.5" />
                <span>Reset Budget (Archive Current Report)</span>
              </button>
            )}
          </div>

          {/* Buttons */}
          <div className="pt-2 flex items-center justify-end gap-2.5">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2.5 rounded-xl text-xs font-medium text-zinc-400 hover:text-zinc-200 hover:bg-zinc-800 transition-colors"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="px-5 py-2.5 rounded-xl text-xs font-semibold text-zinc-950 bg-emerald-400 hover:bg-emerald-300 shadow-md shadow-emerald-950/40 transition-all"
            >
              Save Settings
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
