import React, { useState } from 'react';
import { formatCurrency } from '../utils/budgetCalculations';

interface BudgetCircleGaugeProps {
  totalAllowance: number;
  totalSpent: number;
  currencySymbol: string;
  size?: number; // diameter in px (e.g. 190)
  strokeWidth?: number;
}

export const BudgetCircleGauge: React.FC<BudgetCircleGaugeProps> = ({
  totalAllowance,
  totalSpent,
  currencySymbol,
  size = 190,
  strokeWidth = 14,
}) => {
  const [viewMode, setViewMode] = useState<'used' | 'remaining'>('used');

  const safeTotal = Math.max(0.01, totalAllowance);
  const usedRatio = (totalSpent / safeTotal) * 100;
  const remaining = totalAllowance - totalSpent;
  const remainingRatio = Math.max(0, 100 - usedRatio);

  const isOver = totalSpent > totalAllowance;
  const clampedUsedPercent = Math.min(100, Math.max(0, usedRatio));

  // Circle dimensions
  const center = size / 2;
  const radius = center - strokeWidth / 2 - 4;
  const circumference = 2 * Math.PI * radius;

  // Stroke offsets
  const activePercent = viewMode === 'used' ? clampedUsedPercent : remainingRatio;
  const strokeDashoffset = circumference - (activePercent / 100) * circumference;

  // Colors based on budget consumed
  let strokeColor = '#10b981'; // emerald-500
  let glowColor = 'rgba(16, 185, 129, 0.35)';
  let textColor = 'text-emerald-400';
  let badgeBg = 'bg-emerald-500/10 text-emerald-400 border-emerald-500/20';

  if (isOver) {
    strokeColor = '#f43f5e'; // rose-500
    glowColor = 'rgba(244, 63, 94, 0.45)';
    textColor = 'text-rose-400';
    badgeBg = 'bg-rose-500/10 text-rose-400 border-rose-500/20';
  } else if (usedRatio >= 85) {
    strokeColor = '#f97316'; // orange-500
    glowColor = 'rgba(249, 115, 22, 0.35)';
    textColor = 'text-orange-400';
    badgeBg = 'bg-orange-500/10 text-orange-400 border-orange-500/20';
  } else if (usedRatio >= 60) {
    strokeColor = '#f59e0b'; // amber-500
    glowColor = 'rgba(245, 158, 11, 0.35)';
    textColor = 'text-amber-400';
    badgeBg = 'bg-amber-500/10 text-amber-400 border-amber-500/20';
  }

  return (
    <div className="flex flex-col items-center justify-center">
      {/* Interactive circular gauge */}
      <button
        type="button"
        onClick={() => setViewMode((m) => (m === 'used' ? 'remaining' : 'used'))}
        className="relative group focus:outline-none transition-transform hover:scale-105 active:scale-95"
        title="Click to toggle between % Used and % Remaining"
        aria-label={`Budget circular graph: ${usedRatio.toFixed(1)}% used. Click to toggle view.`}
      >
        <svg
          width={size}
          height={size}
          className="transform -rotate-90 filter drop-shadow-md"
        >
          {/* Subtle gradient definitions */}
          <defs>
            <linearGradient id="gaugeGradient" x1="0%" y1="0%" x2="100%" y2="100%">
              <stop offset="0%" stopColor={strokeColor} stopOpacity="1" />
              <stop
                offset="100%"
                stopColor={isOver ? '#e11d48' : usedRatio >= 60 ? '#d97706' : '#059669'}
                stopOpacity="0.85"
              />
            </linearGradient>
            <filter id="gaugeGlow" x="-20%" y="-20%" width="140%" height="140%">
              <feDropShadow dx="0" dy="0" stdDeviation="4" floodColor={glowColor} />
            </filter>
          </defs>

          {/* Background track circle */}
          <circle
            cx={center}
            cy={center}
            r={radius}
            fill="transparent"
            stroke="#27272a" // zinc-800
            strokeWidth={strokeWidth}
            className="opacity-70"
          />

          {/* Secondary tick marks / segments indicator */}
          <circle
            cx={center}
            cy={center}
            r={radius}
            fill="transparent"
            stroke="#18181b" // zinc-900
            strokeWidth={strokeWidth - 4}
            strokeDasharray="2 12"
            className="opacity-60"
          />

          {/* Progressive Active Ring */}
          <circle
            cx={center}
            cy={center}
            r={radius}
            fill="transparent"
            stroke="url(#gaugeGradient)"
            strokeWidth={strokeWidth}
            strokeLinecap="round"
            strokeDasharray={circumference}
            strokeDashoffset={strokeDashoffset}
            filter="url(#gaugeGlow)"
            className="transition-all duration-700 ease-out"
          />
        </svg>

        {/* Center content inside the circle */}
        <div className="absolute inset-0 flex flex-col items-center justify-center p-3 text-center pointer-events-none">
          <span className="text-[10px] uppercase tracking-wider font-semibold text-zinc-400 flex items-center gap-1">
            <span
              className="w-1.5 h-1.5 rounded-full"
              style={{ backgroundColor: strokeColor }}
            />
            {viewMode === 'used' ? 'Budget Used' : 'Remaining'}
          </span>

          <div className="flex items-baseline justify-center gap-0.5 my-0.5">
            <span className={`text-2xl sm:text-3xl font-extrabold font-mono tracking-tight ${textColor}`}>
              {viewMode === 'used' ? usedRatio.toFixed(1) : remainingRatio.toFixed(1)}
            </span>
            <span className={`text-sm sm:text-base font-bold font-mono ${textColor}`}>%</span>
          </div>

          <div className="text-[10px] text-zinc-400 font-mono">
            {viewMode === 'used'
              ? `${formatCurrency(totalSpent, currencySymbol)} used`
              : `${formatCurrency(Math.max(0, remaining), currencySymbol)} left`}
          </div>

          <div className="text-[9px] text-zinc-500 opacity-0 group-hover:opacity-100 transition-opacity mt-0.5">
            Click to switch
          </div>
        </div>
      </button>

      {/* Helper tag below circle */}
      <div className="mt-2 text-center">
        <span
          className={`inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-[11px] font-semibold border ${badgeBg}`}
        >
          {isOver
            ? `Over Budget by ${formatCurrency(Math.abs(remaining), currencySymbol)}`
            : `${usedRatio.toFixed(0)}% used of ${formatCurrency(totalAllowance, currencySymbol)}`}
        </span>
      </div>
    </div>
  );
};
