import React, { useState, useEffect, useCallback, useRef } from 'react';
import { Capacitor } from '@capacitor/core';
import { App as CapacitorApp } from '@capacitor/app';
import {
  AllowanceConfig,
  Expense,
  ExpenseCategory,
  RecurringSchedule,
  ArchivedBudgetReport,
} from './types/budget';
import {
  loadConfig,
  saveConfig,
  loadExpenses,
  saveExpenses,
  loadSchedules,
  saveSchedules,
  loadArchivedReports,
  saveArchivedReports,
} from './utils/storage';
import {
  calculateCommitmentWithinCycle,
  toISODateString,
  formatCurrency,
  getNextOccurrence,
  DAY_NAMES,
  createArchiveSnapshot,
} from './utils/budgetCalculations';
import { Header } from './components/Header';
import { AllowanceHeroCard } from './components/AllowanceHeroCard';
import { ScheduledExpensesSection } from './components/ScheduledExpensesSection';
import { ExpensesLedger } from './components/ExpensesLedger';
import { AddExpenseModal } from './components/AddExpenseModal';
import { AddScheduledModal } from './components/AddScheduledModal';
import { AllowanceSettingsModal } from './components/AllowanceSettingsModal';
import { AnalyticsModal } from './components/AnalyticsModal';
import { InstallPhoneModal } from './components/InstallPhoneModal';
import { ArchivedReportsModal } from './components/ArchivedReportsModal';
import { CheckCircle2 } from 'lucide-react';

export default function App() {
  const [config, setConfig] = useState<AllowanceConfig>(loadConfig);
  const [expenses, setExpenses] = useState<Expense[]>(loadExpenses);
  const [schedules, setSchedules] = useState<RecurringSchedule[]>(loadSchedules);
  const [archives, setArchives] = useState<ArchivedBudgetReport[]>(loadArchivedReports);

  // Modals state
  const [isAddExpenseOpen, setIsAddExpenseOpen] = useState(false);
  const [isAddScheduledOpen, setIsAddScheduledOpen] = useState(false);
  const [isSettingsOpen, setIsSettingsOpen] = useState(false);
  const [isAnalyticsOpen, setIsAnalyticsOpen] = useState(false);
  const [isInstallOpen, setIsInstallOpen] = useState(false);
  const [isArchivesOpen, setIsArchivesOpen] = useState(false);

  const modalStateRef = useRef({
    isAddExpenseOpen,
    isAddScheduledOpen,
    isSettingsOpen,
    isAnalyticsOpen,
    isInstallOpen,
    isArchivesOpen,
  });
  modalStateRef.current = {
    isAddExpenseOpen,
    isAddScheduledOpen,
    isSettingsOpen,
    isAnalyticsOpen,
    isInstallOpen,
    isArchivesOpen,
  };

  // Android system Back closes the topmost open dialog before leaving the app.
  useEffect(() => {
    if (!Capacitor.isNativePlatform()) return;

    let disposed = false;
    let removeListener: (() => void) | undefined;

    void CapacitorApp.addListener('backButton', ({ canGoBack }) => {
      const open = modalStateRef.current;
      if (open.isArchivesOpen) setIsArchivesOpen(false);
      else if (open.isAddExpenseOpen) setIsAddExpenseOpen(false);
      else if (open.isAddScheduledOpen) setIsAddScheduledOpen(false);
      else if (open.isSettingsOpen) setIsSettingsOpen(false);
      else if (open.isAnalyticsOpen) setIsAnalyticsOpen(false);
      else if (open.isInstallOpen) setIsInstallOpen(false);
      else if (canGoBack) window.history.back();
      else void CapacitorApp.exitApp();
    }).then((handle) => {
      if (disposed) {
        void handle.remove();
      } else {
        removeListener = () => { void handle.remove(); };
      }
    }).catch((error) => {
      console.error('Unable to register Android Back handler:', error);
    });

    return () => {
      disposed = true;
      removeListener?.();
    };
  }, []);

  // Preset values for AddScheduled modal
  const [presetDayOfWeek, setPresetDayOfWeek] = useState<number>(5); // Friday default
  const [presetTitle, setPresetTitle] = useState<string>('');

  // Toast feedback state
  const [toastMessage, setToastMessage] = useState<string | null>(null);

  const showToast = useCallback((msg: string) => {
    setToastMessage(msg);
    setTimeout(() => {
      setToastMessage((current) => (current === msg ? null : current));
    }, 3200);
  }, []);

  // Save changes to localStorage
  useEffect(() => {
    saveConfig(config);
  }, [config]);

  useEffect(() => {
    saveExpenses(expenses);
  }, [expenses]);

  useEffect(() => {
    saveSchedules(schedules);
  }, [schedules]);

  useEffect(() => {
    saveArchivedReports(archives);
  }, [archives]);

  // Check for auto-deductions due today on mount
  useEffect(() => {
    const today = new Date();
    const todayStr = toISODateString(today);
    const dayOfWeek = today.getDay();
    const dayOfMonth = today.getDate();

    let newExpenses: Expense[] = [];
    let updatedSchedules = [...schedules];
    let schedulesChanged = false;

    updatedSchedules = updatedSchedules.map((schedule) => {
      if (!schedule.isActive || !schedule.autoDeduct) return schedule;

      // Check if already applied today
      if (schedule.lastAppliedDate === todayStr) return schedule;

      let isDueToday = false;
      if (schedule.frequency === 'weekly' && schedule.dayOfWeek === dayOfWeek) {
        isDueToday = true;
      } else if (schedule.frequency === 'monthly' && schedule.dayOfMonth === dayOfMonth) {
        isDueToday = true;
      } else if (schedule.frequency === 'specific_date' && schedule.specificDate === todayStr) {
        isDueToday = true;
      }

      if (isDueToday) {
        schedulesChanged = true;
        newExpenses.push({
          id: `exp-auto-${Date.now()}-${schedule.id}`,
          title: schedule.title,
          amount: schedule.amount,
          category: schedule.category,
          date: new Date().toISOString(),
          note: `Auto-deducted on schedule (${schedule.frequency === 'weekly' ? `Every ${DAY_NAMES[schedule.dayOfWeek!]}` : 'scheduled'})`,
          scheduledId: schedule.id,
        });

        return {
          ...schedule,
          lastAppliedDate: todayStr,
        };
      }

      return schedule;
    });

    if (newExpenses.length > 0) {
      setExpenses((prev) => [...newExpenses, ...prev]);
      setSchedules(updatedSchedules);
      showToast(`Auto-deducted ${newExpenses.length} scheduled expense(s) from allowance.`);
    }
  }, []); // Run on mount

  // Upcoming scheduled commitment total within the active cycle
  const upcomingCommitmentTotal = calculateCommitmentWithinCycle(schedules, config);

  // Quick minus handler
  const handleQuickDeduct = (amount: number, title: string, category: ExpenseCategory) => {
    const newExpense: Expense = {
      id: `exp-${Date.now()}`,
      title,
      amount,
      category,
      date: new Date().toISOString(),
    };
    setExpenses((prev) => [newExpense, ...prev]);
    showToast(`Deducted ${formatCurrency(amount, config.currencySymbol)} for "${title}"`);
  };

  // Add full expense from modal
  const handleAddExpense = (
    amount: number,
    title: string,
    category: ExpenseCategory,
    date?: string,
    note?: string
  ) => {
    const newExpense: Expense = {
      id: `exp-${Date.now()}`,
      title,
      amount,
      category,
      date: date || new Date().toISOString(),
      note,
    };
    setExpenses((prev) => [newExpense, ...prev]);
    showToast(`Deducted ${formatCurrency(amount, config.currencySymbol)} from allowance.`);
  };

  // Add new scheduled recurring expense
  const handleAddSchedule = (scheduleData: Omit<RecurringSchedule, 'id' | 'createdAt'>) => {
    const newSchedule: RecurringSchedule = {
      ...scheduleData,
      id: `sched-${Date.now()}`,
      createdAt: new Date().toISOString(),
    };
    setSchedules((prev) => [newSchedule, ...prev]);
    showToast(`Scheduled "${newSchedule.title}" successfully.`);
  };

  // Preset opener for Friday / Tuesday
  const handleOpenAddPreset = (dayOfWeek: number, defaultTitle?: string) => {
    setPresetDayOfWeek(dayOfWeek);
    setPresetTitle(defaultTitle || '');
    setIsAddScheduledOpen(true);
  };

  // Toggle active/pause on a scheduled expense
  const handleToggleActiveSchedule = (id: string) => {
    setSchedules((prev) =>
      prev.map((s) => (s.id === id ? { ...s, isActive: !s.isActive } : s))
    );
  };

  // Toggle auto-deduct on a scheduled expense
  const handleToggleAutoDeductSchedule = (id: string) => {
    setSchedules((prev) =>
      prev.map((s) => {
        if (s.id === id) {
          const nextState = !s.autoDeduct;
          showToast(
            nextState
              ? `Auto-deduct ON for "${s.title}"`
              : `Manual deduct set for "${s.title}"`
          );
          return { ...s, autoDeduct: nextState };
        }
        return s;
      })
    );
  };

  // Delete an archived budget report
  const handleDeleteArchive = (id: string) => {
    setArchives((prev) => prev.filter((a) => a.id !== id));
    showToast('Archived budget report removed.');
  };

  // Delete a scheduled expense
  const handleDeleteSchedule = (id: string) => {
    setSchedules((prev) => prev.filter((s) => s.id !== id));
    showToast('Scheduled expense deleted.');
  };

  // Deduct a scheduled expense right now from allowance
  const handleDeductScheduledNow = (schedule: RecurringSchedule, dateStr?: string) => {
    const todayStr = dateStr || toISODateString(new Date());
    const newExpense: Expense = {
      id: `exp-${Date.now()}-${schedule.id}`,
      title: schedule.title,
      amount: schedule.amount,
      category: schedule.category,
      date: new Date().toISOString(),
      note: `Scheduled deduction (${schedule.frequency === 'weekly' && schedule.dayOfWeek !== undefined ? `Every ${DAY_NAMES[schedule.dayOfWeek]}` : 'Scheduled'})`,
      scheduledId: schedule.id,
    };

    setExpenses((prev) => [newExpense, ...prev]);
    // Mark as applied today so it doesn't duplicate
    setSchedules((prev) =>
      prev.map((s) =>
        s.id === schedule.id ? { ...s, lastAppliedDate: todayStr } : s
      )
    );
    showToast(`Deducted ${formatCurrency(schedule.amount, config.currencySymbol)} for "${schedule.title}"`);
  };

  // Delete an expense deduction (refunds to allowance)
  const handleDeleteExpense = (id: string) => {
    const exp = expenses.find((e) => e.id === id);
    setExpenses((prev) => prev.filter((e) => e.id !== id));
    if (exp) {
      showToast(`Removed "${exp.title}" & restored ${formatCurrency(exp.amount, config.currencySymbol)} to allowance.`);
    }
  };

  // Clear all expenses
  const handleClearAllExpenses = () => {
    setExpenses([]);
    showToast('All deductions cleared. Allowance balance restored.');
  };

  // User requirement: Reset budget, archive old progress/budget report so it can be accessed when needed, and apply new allowance
  const handleResetAllowance = (newAllowance?: number, newCycleName?: string) => {
    // 1. Snapshot previous cycle if any data exists
    if (expenses.length > 0 || config.totalAllowance > 0) {
      const snapshot = createArchiveSnapshot(
        config,
        expenses,
        newCycleName
          ? `Archived prior to cycle: ${newCycleName}`
          : 'Archived budget report'
      );
      setArchives((prev) => [snapshot, ...prev]);
    }

    // 2. Clear deductions
    setExpenses([]);

    // 3. Update allowance config if new values provided
    const now = new Date();
    setConfig((prev) => ({
      ...prev,
      totalAllowance: newAllowance && newAllowance > 0 ? newAllowance : prev.totalAllowance,
      cycleName: newCycleName?.trim() || prev.cycleName,
      startDate: toISODateString(now),
    }));

    showToast('Old budget report archived to Past Reports. Allowance reset!');
  };

  // Switch or set currency symbol (supports Philippine Peso ₱)
  const handleSelectCurrency = (newSymbol: string) => {
    setConfig((prev) => {
      let newAllowance = prev.totalAllowance;
      // If switching between USD and Peso, scale starting allowance appropriately
      if (newSymbol === '₱' && prev.currencySymbol !== '₱' && prev.totalAllowance <= 2500) {
        newAllowance = Math.round(prev.totalAllowance * 50);
      } else if (newSymbol === '$' && prev.currencySymbol === '₱' && prev.totalAllowance >= 20000) {
        newAllowance = Math.round(prev.totalAllowance / 50);
      }

      return {
        ...prev,
        currencySymbol: newSymbol,
        totalAllowance: newAllowance,
      };
    });
    showToast(
      newSymbol === '₱'
        ? 'Active currency: Philippine Peso (₱)'
        : `Currency set to ${newSymbol}`
    );
  };

  return (
    <div className="min-h-screen bg-zinc-950 text-zinc-100 flex flex-col font-sans selection:bg-emerald-500/30 selection:text-emerald-200">
      {/* Toast Notification */}
      {toastMessage && (
        <div className="fixed bottom-6 right-6 z-50 flex items-center gap-2.5 px-4 py-3 rounded-2xl bg-zinc-900 border border-emerald-500/40 text-zinc-100 shadow-2xl animate-bounce-short">
          <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
          <span className="text-xs font-medium">{toastMessage}</span>
        </div>
      )}

      {/* Main Header */}
      <Header
        config={config}
        onOpenAddExpense={() => setIsAddExpenseOpen(true)}
        onOpenAddScheduled={() => {
          setPresetDayOfWeek(5); // Default to Friday
          setPresetTitle('');
          setIsAddScheduledOpen(true);
        }}
        onOpenSettings={() => setIsSettingsOpen(true)}
        onOpenAnalytics={() => setIsAnalyticsOpen(true)}
        onOpenInstall={() => setIsInstallOpen(true)}
        onOpenArchives={() => setIsArchivesOpen(true)}
        onSelectCurrency={handleSelectCurrency}
      />

      {/* Main Content Dashboard */}
      <main className="flex-1 max-w-6xl w-full mx-auto px-4 sm:px-6 py-6 sm:py-8 space-y-8">
        {/* Allowance Hero Card with Instant Minus & Circular Gauge */}
        <AllowanceHeroCard
          config={config}
          expenses={expenses}
          upcomingCommitmentTotal={upcomingCommitmentTotal}
          onQuickDeduct={handleQuickDeduct}
          onOpenSettings={() => setIsSettingsOpen(true)}
          onSelectCurrency={handleSelectCurrency}
        />

        {/* Scheduled & Recurring Expenses Section */}
        <ScheduledExpensesSection
          config={config}
          schedules={schedules}
          onOpenAddModal={() => {
            setPresetDayOfWeek(5);
            setPresetTitle('');
            setIsAddScheduledOpen(true);
          }}
          onOpenAddPreset={handleOpenAddPreset}
          onToggleActive={handleToggleActiveSchedule}
          onToggleAutoDeduct={handleToggleAutoDeductSchedule}
          onDeleteSchedule={handleDeleteSchedule}
          onDeductScheduledNow={handleDeductScheduledNow}
        />

        {/* Expenses Ledger */}
        <ExpensesLedger
          config={config}
          expenses={expenses}
          onDeleteExpense={handleDeleteExpense}
          onClearAllExpenses={handleClearAllExpenses}
        />
      </main>

      {/* Footer */}
      <footer className="border-t border-zinc-900 py-6 text-center text-xs text-zinc-500 flex flex-col sm:flex-row items-center justify-center gap-3">
        <span>KuroBudget &bull; Dark Allowance Flow &amp; Scheduled Expense Tracker</span>
        <button
          onClick={() => setIsInstallOpen(true)}
          className="text-emerald-400 hover:text-emerald-300 font-medium underline underline-offset-2 flex items-center gap-1"
        >
          <span>Install on Phone (Android phone / Android / iPhone)</span>
        </button>
      </footer>

      {/* Modals */}
      <AddExpenseModal
        isOpen={isAddExpenseOpen}
        onClose={() => setIsAddExpenseOpen(false)}
        config={config}
        onAddExpense={handleAddExpense}
      />

      <AddScheduledModal
        isOpen={isAddScheduledOpen}
        onClose={() => setIsAddScheduledOpen(false)}
        config={config}
        initialDayOfWeek={presetDayOfWeek}
        initialTitle={presetTitle}
        onAddSchedule={handleAddSchedule}
      />

      <AllowanceSettingsModal
        isOpen={isSettingsOpen}
        onClose={() => setIsSettingsOpen(false)}
        config={config}
        onSaveConfig={setConfig}
        onResetAllowance={handleResetAllowance}
        onOpenArchives={() => setIsArchivesOpen(true)}
      />

      <AnalyticsModal
        isOpen={isAnalyticsOpen}
        onClose={() => setIsAnalyticsOpen(false)}
        config={config}
        expenses={expenses}
      />

      <InstallPhoneModal
        isOpen={isInstallOpen}
        onClose={() => setIsInstallOpen(false)}
      />

      <ArchivedReportsModal
        isOpen={isArchivesOpen}
        onClose={() => setIsArchivesOpen(false)}
        archives={archives}
        onDeleteArchive={handleDeleteArchive}
      />
    </div>
  );
}
