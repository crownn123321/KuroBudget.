import { Capacitor } from '@capacitor/core';
import { Directory, Encoding, Filesystem } from '@capacitor/filesystem';
import { Share } from '@capacitor/share';

export function escapeCsvCell(value: unknown): string {
  const text = String(value ?? '');
  return `"${text.replace(/"/g, '""')}"`;
}

export async function exportCsvFile(
  filename: string,
  csvContent: string,
  title: string
): Promise<void> {
  const safeFilename = filename.replace(/[\\/:*?"<>|\u0000-\u001f]+/g, '-');
  const content = `\uFEFF${csvContent}`;

  if (Capacitor.isNativePlatform()) {
    // Share from the app cache so Android's FileProvider can expose the file
    // without broad storage permissions.
    const file = await Filesystem.writeFile({
      path: safeFilename,
      data: content,
      directory: Directory.Cache,
      encoding: Encoding.UTF8,
    });

    await Share.share({
      title,
      text: title,
      url: file.uri,
      dialogTitle: 'Export CSV',
    });
    return;
  }

  const blob = new Blob([content], { type: 'text/csv;charset=utf-8;' });
  const url = URL.createObjectURL(blob);
  const link = document.createElement('a');
  link.href = url;
  link.download = safeFilename;
  link.style.display = 'none';
  document.body.appendChild(link);
  link.click();
  link.remove();
  window.setTimeout(() => URL.revokeObjectURL(url), 1000);
}
