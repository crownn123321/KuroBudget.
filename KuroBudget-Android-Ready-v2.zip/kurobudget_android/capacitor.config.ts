import type { CapacitorConfig } from '@capacitor/cli';

const config: CapacitorConfig = {
  appId: 'com.kurobudget.allowancetracker',
  appName: 'KuroBudget',
  webDir: 'dist',
};

export default config;
